import type { VerticalNavItems } from '@/@layouts/types';

export default [
  // {
  //   title: 'sidbar.employee',
  //   to: { name: 'content-management-employee' },
  //   icon: { icon: 'uil:user-circle' },
  // },
  // {
  //   title: 'sidbar.order',
  //   to: { name: 'content-management-order' },
  //   icon: { icon: 'tabler-baby-carriage' },
  // },
  // {
  //   title: 'sidbar.driver',
  //   to: { name: 'content-management-driver' },
  //   icon: { icon: 'tabler-car' },
  // },
  // {
  //   title: 'sidbar.invoice',
  //   to: { name: 'content-management-invoice' },
  //   icon: { icon: 'mdi-currency-usd' },
  // },
  // {
  //   title: 'sidbar.evaluation',
  //   to: { name: 'content-management-evaluation' },
  //   icon: { icon: 'tabler-star' },
  // },
  // {
  //   title: 'sidbar.product',
  //   to: { name: 'content-management-product' },
  //   icon: { icon: 'uil:box' },
  // },


  // {
  //   title: 'sidbar.rating',
  //   to: { name: 'content-management-coupon' },
  //   icon: { icon: 'uil:percentage' },
  // },
  // {
  //   title: 'sidbar.user',
  //   to: { name: 'content-management-customer' },
  //   icon: { icon: 'uil:user' },
  // },
  // {
  //   title: 'sidbar.contact',
  //   to: { name: 'content-management-contactUs' },
  //   icon: { icon: 'uil:phone' },
  // },
  // {
  //   title: 'sidbar.report',
  //   to: { name: 'content-management-report' },
  //   icon: { icon: 'uil:analytics' },
  // },

] as VerticalNavItems;
