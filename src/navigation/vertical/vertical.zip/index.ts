import type { VerticalNavItems } from '@/@layouts/types'
import contentManagement from './content-management'

export default [
  {
    title: 'sidebar.home',
    to: { name: 'index' },
    icon: { icon: 'tabler-home' },
  },
 
  ...contentManagement,


] as VerticalNavItems

// https://icones.netlify.app/collection/tabler?s=store
