

const HOST_DOMAIN = 
'http://selfcare-dev.enjazaat-apps.com'

const API_URL = `${HOST_DOMAIN}/provider/api/`



export { API_URL, HOST_DOMAIN }

