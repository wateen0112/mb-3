<template>
  <div class="h-100 d-flex align-center justify-space-between">
    <!-- 👉 Footer: left content -->
    <span class="d-flex align-center gap-x-2">
      &copy;
      {{ new Date().getFullYear() }}
      <a
        href=""
        target="_blank"
        rel="noopener noreferrer"
        class="text-primary ms-1"
        >Semicolon Team</a
      >
      <span>Powered By</span>
    </span>
    <!-- 👉 Footer: right content -->
  
  </div>
</template>
