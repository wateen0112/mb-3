export enum ORDER_API{
  ORDERS='orders/',
NEW='orders/new',
READ_COUNT='orders/read-count',
UNREAD_COUNT='orders/unread-count',
ACCEPT='/accept',
CHANGE_STATUS='/change-status',
CONFIRM_PAYMENT='/confirm-payment',
SEND_PAYMENT_NOTIFICATION='/send-payment-notification',
ADD_GIFT_APPOINTMENT='add-gift-appointment',
GET_AVAILABLE_TIME_SLOT='/get-services-timeslots'
}

