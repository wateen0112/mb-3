export class LoginDto {
  email= ''
  password= ''
}




export class UserDto {
  token : string= '';
  is_active   :boolean = false;
  has_completed_profile :boolean= false;
  is_sub_account  :boolean =  false;
  permissions=[];
}
