// ? UPPER_CASE
export enum AUTH_API {
  Login = 'login',
  Vertify='verify-otp',
 ResendOtp ='resend-otp',
Logut ='logout'
}
