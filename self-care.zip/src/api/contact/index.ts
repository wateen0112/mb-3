export enum CONTACT_API {
CONTACT_US="contact-us"
}
