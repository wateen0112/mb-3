export enum WORKINGTIMES_API{
  TIMESLOTS = 'timeslots/',
  EMPLOYEES = 'timeslots/employees/',
  EMPLOYEE = 'timeslots/employee/',
 CUSTOM ='timeslots/custom/',
 CHANGE_STATUS = '/change-status',
 NORMAL='timeslots/normal/',
 CHANGE_SERVICE='timeslots/service/',
 CHANGE_EMPLOYEE='timeslots/employee/',
 SLOTS='slot/',
UPDATE='/update'
}
