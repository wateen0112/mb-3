export enum PROFILE_API{
  UPDATE='/profile/update',
  ADD_LOCATION='location',
  SHOW_PROFILE='profile'
}
