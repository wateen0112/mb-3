// ? UPPER_CASE
export enum NOTIFICATION_API {

  // ! KEY SHOULD BE THE SAME OF THE END OF API ROUTE (" => GetAll <= ")
  GetAll = '/notification/GetAll',
}
