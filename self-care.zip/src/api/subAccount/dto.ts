export class SubAccountDto {
  id: number=0;
  name: string='';
  mobile: string='';
  status?: any=null;
  is_sub_account: number=0;
  permissions: number[]=[];
}

