export enum SUB_ACCOUNTS_API {
SUB_ACCOUNT='sub-accounts/',
UPDATE='sub-accounts/',

}
