export enum CALENDAR_API {
  MY_CALENDAR='my-calendar'
}
