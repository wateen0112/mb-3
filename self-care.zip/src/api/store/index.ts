export enum Store_API{
  STORES='stores/',
CATEGORIES='categories/'
}
