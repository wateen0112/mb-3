// ? UPPER_CASE
export enum EVALUATION_API {

  // ! KEY SHOULD BE THE SAME OF THE END OF API ROUTE (" => GetAll <= ")
  GetAll = '/evaluation/GetAll',
}
