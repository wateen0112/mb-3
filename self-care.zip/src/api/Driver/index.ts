// ? UPPER_CASE
export enum DRIVER_API {

  // ! KEY SHOULD BE THE SAME OF THE END OF API ROUTE (" => GetAll <= ")
  GetAll = '/driver/GetAll',
}
