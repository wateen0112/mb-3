export enum EMPLOYEE_API{
  EMPLOYEES='employees/'
}
