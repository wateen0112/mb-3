// ? UPPER_CASE
export enum REPORT_API {

  // ! KEY SHOULD BE THE SAME OF THE END OF API ROUTE (" => GetAll <= ")
  GetAll = '/report/GetAll',
}
