export enum PERMISISONS_API{
  PERMISSIONS='permissions'
}
