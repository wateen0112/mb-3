// ? UPPER_CASE
export enum CONTACT_API {

  // ! KEY SHOULD BE THE SAME OF THE END OF API ROUTE (" => GetAll <= ")
GetAll='ContactUs/GetAll',
GetAllDriverRequests='ContactUs/GetAllDriverRequests',
  GetById='contactUs/GetById',
GetByIdDriverRequest='ContactUs/GetByIdDriverRequest',
Reply='contactUs/Reply',
ReplyDriverRequest='ContactUs/ReplyDriverRequest'
,Delete='ContactUs/Delete',
DeleteDriverRequest='ContactUs/DeleteDriverRequest',
Add='Website/ContactUs/Add',

}
