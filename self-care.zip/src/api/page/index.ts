export enum PAGE_API{
  PAGE="/page"
}
