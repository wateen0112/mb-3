export enum SERVICE_API {
  SERVICES='services/',
  LOCATIONS='services/locations/',
  EMPLOYEES='/employees',
  APPOINTMENT='/appointments'
}
