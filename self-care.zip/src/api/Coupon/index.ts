// ? UPPER_CASE
export enum COUPON_API {

  // ! KEY SHOULD BE THE SAME OF THE END OF API ROUTE (" => GetAll <= ")
  GetAll = '/coupon/GetAll',
}
