export class GetAllDto {
  // ? GetAllDto EXAMPLE 
}
