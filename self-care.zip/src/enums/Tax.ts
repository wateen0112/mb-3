export enum TaxValueType {
  Rate = 'Rate',
  Value = 'Value',

}
