import { useApi } from "@/composables";
import { PAGE_API } from "@/api/page";
export const useAboutStore = defineStore('about',()=>{
  const  {GET} = useApi()
const about = ref({title:'',content:''});
const pravicy = ref({title:'',content:''});
const terms = ref({title:'',content:''});


const getAbout = async ()=>{
try {
  const res = await GET <any>(PAGE_API.PAGE+'?slug=about')
  about.value =res.data
} catch (error) {
  throw(error)
}
}
const getPravicy = async ()=>{
  try {
    const res = await GET <any>(PAGE_API.PAGE+'?slug=privacy')
    pravicy.value =res.data
  } catch (error) {
    throw(error)
  }
}
const getTerms = async ()=>{
  try {
    const res = await GET <any>(PAGE_API.PAGE+'?slug=terms')
  terms.value = res.data;
  } catch (error) {
    throw(error)
  }
}

return {about, pravicy , terms,getAbout , getPravicy , getTerms}

})
