import {  Category, StoreDto }from '@/api/store/dto'
import { useApi } from "@/composables";
import { Store_API } from "@/api/store";
import { axiosIns } from '@/plugins/axios';
import { useI18n } from 'vue-i18n';
const {GET,POST,DELETE,PUT}  = useApi()
const logo = ref()
export const useStoresStore = defineStore('store',()=>{
  const {t} = useI18n()
const storeDto = ref<StoreDto>( new StoreDto());// for signup
const storesList = ref <StoreDto[]> ([])
const categories_ids= ref<number[]>([])
const selectedStoreId = ref(0);
const categoriesList = ref<Category[]>([])
const loading  = ref(false)
const createStore = async()=>{

  try {
   
    const res = await POST(Store_API.STORES,{...storeDto.value,logo:logo.value},{error:true ,},{
      formData:true 
    })
  
  } catch (error) {
    throw(error)
  }
}


const getStoresList = async ()=>{
  loading.value = true ; 
  try {
    const res = await GET<StoreDto[]>(Store_API.STORES);
    storesList.value=res.data.data;
    storeDto.value= storesList.value[0]
    selectedStoreId.value = storeDto.value.id
 categoriesList.value.forEach((item:Category)=>{
if(checkIfCategoryIsPublished(item.id))
categories_ids.value .push(item.id)
 })
 loading.value= false
} catch (error) {
  loading.value= false
  throw(error)
  }
} 
const getStoreById= async (id:number)=>{
  try {
    
    const res = await GET<StoreDto> (Store_API.STORES+id)
  
  storeDto.value = res.data.data;
  storeDto.value.oldLogo= storeDto.value.logoFile
  } catch (error) {
    throw(error)
  }
}
const updateStore = async(success:boolean=false)=>{
  try {
    const res = await POST(Store_API.STORES+`${
      
      storeDto.value.id}/update/`,{commercial_registeration_file:storeDto.value.cr_file,
        logo:storeDto.value.logoFile,

    categories_ids:[...categories_ids.value]
    },{success:success?t('profile.storeUpdated'):'',error:true},{formData:true});

  } catch (error) {
    throw(error)
  }
}
const getCategoriesList = async()=>{
  try {
    const res = await GET<Category[]>(Store_API.CATEGORIES);
    // categoriesList.value= res.data.categories.data;
categoriesList.value=res.data.data.categories.data;
    
  } catch (error) {
    
  }
}
const removeCategoryId = (id:number)=>{
storeDto.value.categories_ids = storeDto.value.categories_ids.filter((i:number)=>{
  return i !==id
})
}
const removeCategory = (id:number)=>{
  storeDto.value.categories = storeDto.value.categories.filter((cat:Category)=>{
    return cat.id !==id
  })
  categories_ids.value =  categories_ids.value.filter((i:number)=>{
    return i !==id
  })
  }
const checkIfCategoryIdIsFound = (id:number)=>{
return storeDto.value.categories_ids.filter((i:number)=>{
  return i ===id
}).length>0
}
const checkIfCategoryIsFound = (id:number)=>{
  const myCategories =  categories_ids.value.filter((i:number)=>{
    return i ===id
  });
  return myCategories[0]
  }
const addCategoryId =(id:number)=>{
if(checkIfCategoryIdIsFound(id)){
  removeCategoryId(id)
  
}
else {
  storeDto.value.categories_ids = [...storeDto.value.categories_ids,id]
}
}
const addCategory =(id:number)=>{
  if(checkIfCategoryIsFound(id)){
    removeCategory(id)
    
  }
  else {
    categories_ids.value .push(id)
  }
  }
watch(useStoresStore,()=>{

  
  logo.value=  storeDto.value.logo [0]

    // storeDto.value.logo = storeDto.value.logo [0]

})
const checkIfCategoryIsPublished = (id:number)=>{
let category = storeDto.value.categories.filter((cat :any)=>{

  return id ===cat.id
})[0];


if(category){
  
  return category.is_published===1;
}
return false

}
const  handleCategory= (id:any)=>{
  let category = storeDto.value.categories.filter((cat :any)=>{

    return id ===cat.id
  })[0];
  if(category){
    category.is_published= category.is_published==1 ?0:1
  }
  
}
watch(selectedStoreId,()=>{
 storeDto.value = storesList.value.filter((store:StoreDto)=>{
    return store.id===selectedStoreId.value
  })[0]??new StoreDto()
})
  return {loading, selectedStoreId,categories_ids,handleCategory,checkIfCategoryIsPublished,addCategory,removeCategory,checkIfCategoryIsFound,getCategoriesList,logo,categoriesList, checkIfCategoryIdIsFound,addCategoryId, updateStore, getStoresList,getStoreById,storesList,storeDto,createStore}
})
