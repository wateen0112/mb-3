import { TimeSlotDto, TimeSlotEmployeeDto, TimeSlotServiceDto } from "@/api/workingTime/dto"; 
import { WORKINGTIMES_API } from "@/api/workingTime";
import { useApi } from "@/composables"
import { useDateTime } from "@/composables/useDateTime";
const {GET, POST ,DELETE}  = useApi();
export const useTimeSlotsStore = defineStore('timeStore',()=>{
const customTimeSlotsList =  ref<TimeSlotDto[]>([new TimeSlotDto()])
const normalTimeSlotsList =  ref<TimeSlotDto[]>([new TimeSlotDto()])
const timeSlot = ref<TimeSlotDto>( new TimeSlotDto())
const date = ref()
const loading = ref(false)
const timeSlotsEmployeesList = ref<TimeSlotEmployeeDto[]>([])
const timeSlotsServicesList = ref<TimeSlotServiceDto[]>([])
const { reformatDate } = useDateTime();
const getTimeSlotsList = async ()=>{

try {
  const res = await GET<TimeSlotDto[]>(WORKINGTIMES_API.CUSTOM);
  customTimeSlotsList.value = res.data.data.custom_working_hours;
  normalTimeSlotsList.value = res.data.data.normal_working_hours;
} catch (error) {
  throw(error)
}
}
const normalChangeStatus = async ()=>{
  try {
    const res = await POST (WORKINGTIMES_API.NORMAL+WORKINGTIMES_API.CHANGE_STATUS , null);

  } catch (error) {
    throw(error)
  }
}
const customChaneStatus = async (id:number)=>{
  try {
    const res = await POST (WORKINGTIMES_API.CUSTOM+id+WORKINGTIMES_API.CHANGE_STATUS,null)
  } catch (error) {
    throw(error)
  }
}
const getShiftCaldendarServices = async (payload:any)=>{
try {
  const res  = await GET<TimeSlotServiceDto[]>(WORKINGTIMES_API.TIMESLOTS,payload);
timeSlotsServicesList.value = res.data.data.services

} catch (error) {
  throw(error)
}
}
const getShiftCaldendarEmployees = async (payload:any)=>{
  try {
    const res = await GET <TimeSlotEmployeeDto[]>(WORKINGTIMES_API.EMPLOYEES, payload);
    timeSlotsEmployeesList.value = res.data.data
  } catch (error) {
    throw(error)
  } 

}
const timeslotsChangeStatus =async (id:number,serviceIndex:number,timeSlotIndex:number) =>{
  try {
  const status = !  timeSlotsServicesList.value[serviceIndex].service.timeslots[timeSlotIndex].is_active
  const res= await  POST (WORKINGTIMES_API.TIMESLOTS+WORKINGTIMES_API.SLOTS+id+WORKINGTIMES_API.CHANGE_STATUS,{status:status, date:reformatDate(date.value)})

  timeSlotsServicesList.value[serviceIndex].service.timeslots[timeSlotIndex].is_active=status
} catch (error) {
 throw(error) 
}
}
const employeesTimeslotsChangeStatus =async (id:number,employeeIndex:number,shiftIndex:number) =>{
  try {
  const status =     timeSlotsEmployeesList.value[employeeIndex].shifts[shiftIndex].shift_status===0?1:0
  const res= await  POST (WORKINGTIMES_API.EMPLOYEE+WORKINGTIMES_API.SLOTS+id+WORKINGTIMES_API.CHANGE_STATUS,{status:status, date:reformatDate(date.value)})

  timeSlotsEmployeesList.value[employeeIndex].shifts[shiftIndex].shift_status=status
} catch (error) {
 throw(error) 
}
}
const employeeChangeStatus = async (id:number, index:number)=>{
try {
  const status = ! timeSlotsEmployeesList.value[index].is_active;

  const res = await  POST (WORKINGTIMES_API.EMPLOYEE+id+WORKINGTIMES_API.CHANGE_STATUS,{status:status,date:reformatDate(date.value)})
  timeSlotsEmployeesList.value[index].is_active= status
} catch (error) {
  throw(error)
}
}
//
const serviceChangeStatus =async (id:number,index:number) =>{
  try {
 
    const status =!timeSlotsServicesList.value[index].is_active;
    const res= await  POST (WORKINGTIMES_API.CHANGE_SERVICE+id+WORKINGTIMES_API.CHANGE_STATUS,{status:status, date:reformatDate(date.value)})
  
  
 timeSlotsServicesList.value[index].is_active=status
  } catch (error) {
   throw(error) 
  }
  }
  
const updateNormalWorkTime = async ()=>{
  try {
    const res = await POST (WORKINGTIMES_API.NORMAL+timeSlot.value.id+WORKINGTIMES_API.UPDATE,timeSlot.value,{success:true})
  
  } catch (error) {
    throw(error)
  }
}
const updateCustomWorkTime = async ()=>{
  try {
    const res = await POST (WORKINGTIMES_API.CUSTOM+timeSlot.value.id+WORKINGTIMES_API.UPDATE,timeSlot.value,{success:true})
  } catch (error) {
    throw(error)
  }
}
return {loading,date,updateCustomWorkTime,updateNormalWorkTime,employeesTimeslotsChangeStatus,employeeChangeStatus,serviceChangeStatus,timeslotsChangeStatus,getShiftCaldendarEmployees,getShiftCaldendarServices,customChaneStatus,getTimeSlotsList,normalChangeStatus,timeSlot,customTimeSlotsList,normalTimeSlotsList,timeSlotsEmployeesList,timeSlotsServicesList}
})
