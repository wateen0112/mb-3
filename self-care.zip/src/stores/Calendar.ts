import { CALENDAR_API } from "@/api/calendar";
import { useApi } from "@/composables";
import { useDateTime } from "@/composables/useDateTime";
export const useCalnedarStore =defineStore('calendar',()=>{
  const  {GET,POST,DELETE} = useApi()
  const {reformatDate} = useDateTime()

//states  . . .
const appointmentList  = ref([]);
const date = ref('')
const page = ref (0);

//meethods and functions 
const getAppointmentList = async ()=>{
  try {
    const res = await GET (CALENDAR_API.MY_CALENDAR,{day:reformatDate(date.value),page:page.value});
    appointmentList.value = res.data.data; 

  } catch (error) {
    throw(error);

  }
}
watch (date,()=>{
 getAppointmentList(); 
})
  return {
appointmentList , getAppointmentList
 ,date }
})
