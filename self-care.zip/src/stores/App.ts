import type { PageMeta } from '@/types/app/PageMeta'

export const useAppStore = defineStore('App', () => {
  const inputLang = ref('')
  const sidebarOpend =  ref(false)
  const modalOpened =  ref(false)
  const PageMeta = ref<PageMeta>({
    title: '',
    icon: '',
    breadCrumb: [],
    
  })

  const isLoading = ref(false)

  function SetPageMeta(meta: PageMeta) {
    PageMeta.value = { ...meta }
  }

  const startupCalls = () =>
    Promise.all([
      // settingStore.GetAllAreas(),
      // settingStore.GetAllCities(),
      // settingStore.GetAllLabels(),
      // settingStore.GetCitiesWithArea(),
      // settingStore.GetAllShopCategories(),
      // notificationStore.GetUnRead(),
    ])
const openSidebar =()=>{

  document.querySelector('.wrapper')?.classList.remove('hidden')
  sidebarOpend.value= true ; 
}
const closeSidebar =()=>{
  document.querySelector('.wrapper')?.classList.add('hidden')

  sidebarOpend.value= false ; 
}
const openModal =()=>{

  document.querySelector('.wrapper')?.classList.remove('hidden')
  modalOpened .value= true ; 
}
const closeModal =()=>{
  document.querySelector('.wrapper')?.classList.add('hidden')

  modalOpened .value= false ; 
}
  return {closeModal, openModal,modalOpened, closeSidebar,openSidebar,sidebarOpend,PageMeta, SetPageMeta, isLoading, startupCalls, inputLang }
})
