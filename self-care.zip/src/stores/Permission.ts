import { PERMISISONS_API } from "@/api/permission";
import { PermissionDto } from "@/api/permission/dto";
import { useApi } from "@/composables";
const {GET} = useApi()
export const usePermissionStore =defineStore('permission',()=>{
const permissionsList = ref<PermissionDto[]>([])
const persmissionsIds = ref<number[]>([])
const permissiontsLoading = ref(false) 
  const getPermissions  = async ()=>{
    try {
      permissiontsLoading.value= true
      const res =await GET<PermissionDto[]>(PERMISISONS_API.PERMISSIONS);
      permissionsList.value= res.data.data.permissions.data
      permissiontsLoading.value=false
      
    } catch (error) {
      permissiontsLoading.value=false
      throw(error)
    }
  }
  const checkIfPermissionIsFound = (id:number)=>{
return  persmissionsIds.value.filter((permission:number)=>{
  return permission===id
}).length>0
  }
  const removePermission = (id:number)=>{
    persmissionsIds.value =  persmissionsIds.value.filter((permission:number)=>{
  return permission!==id
})
  }

  const addPermission =(id:number)=>{
if(checkIfPermissionIsFound(id)){
removePermission(id);
}
else {
  persmissionsIds.value = [...persmissionsIds.value, id]
}
  }
return {permissiontsLoading, permissionsList ,persmissionsIds , getPermissions , addPermission , checkIfPermissionIsFound }
})
