import { FINANCE_API } from "@/api/finance";
import { FinaceDto } from "@/api/finance/dto";
import { useApi } from "@/composables";
const  {POST} = useApi()
export const useFinaceStore = defineStore('finance',()=>{
const finance = ref<FinaceDto>(new FinaceDto());
const startDate = ref('');
const endDate = ref('');
const isLoading  = ref(false)
const getFinance=async (filter:any) =>{
  try {
    isLoading.value = true ; 
    const res = await POST(FINANCE_API.FINANCE,{...filter})
  finance.value = res?.data.data;
isLoading.value = false;
  } catch (
    err
  ) {
    throw(err)
  }
}



  return {
finance , getFinance,startDate , endDate,isLoading
  }
})
