import { SERVICE_API } from "@/api/service";
import { AddAppointmentDto, MainServiceDto, TimeSlotDto } from "@/api/service/dto";
import { useApi } from "@/composables";
import { useDateTime } from "@/composables/useDateTime";

const  {GET,POST,PUT,DELETE}= useApi();
export const useServiceStore = defineStore('service',()=>{
  const {toValidDate} = useDateTime()
  const servicesList = ref<MainServiceDto[]>([]);
  const servicesIds = ref<number[]>([]);
  const timeSlotsList = ref<TimeSlotDto[]>([])
  const total = ref(0); 
  const AllPages= ref(0)
  const perPage = ref(15)
  const page = ref(1);
  const appointMentDto = ref <AddAppointmentDto>(new AddAppointmentDto); 
  const serviceDto = ref<MainServiceDto>(new MainServiceDto());
 //loading
  const isLoading = ref(false)
  //router 
  const router = useRouter()
  //employees   . .. 

  //get services list  .. . 
const getServicesList = async ()=>{
  isLoading.value = true ; 
  try {
    const res = await GET<MainServiceDto[]> (SERVICE_API.SERVICES+`?page=${page.value}`,)
  servicesList.value = res.data.data;
  AllPages.value = res.data.pagination.last_page;
  total.value  =res.data.pagination.total;
  perPage.value  =res.data.pagination.per_page;
  isLoading.value= false
  } catch (error) {
    isLoading.value= false
    throw(error)
  }
}
//get service by id  ...  
const getServiceById = async (id:string)=>{
  isLoading.value = true ; 
  try {
    const res = await GET<MainServiceDto> (SERVICE_API.SERVICES+`${id}`)
  serviceDto.value = res.data.data;
  serviceDto.value.imagePath=serviceDto.value.image
  serviceDto.value.offer_start_date=toValidDate(serviceDto.value.offer_start_date)
  serviceDto.value.offer_end_date=toValidDate(serviceDto.value.offer_end_date)

  isLoading.value= false
  } catch (error) {
    isLoading.value= false
    throw(error)
  }
}
//foramting date  .. . 
const reformatDate = (dateString:string)=>{

// Parse the date string into a Date object
var dateObj = new Date(dateString);

// Get the day, month, and year
var day = dateObj.getDate();
var month = dateObj.getMonth() + 1; // Add 1 because getMonth() returns 0-based index
var year = dateObj.getFullYear();

// Combine the day, month, and year into a new date string in dd-mm-yyyy format
var newDateString = day + "-" + month + "-" + year;
return newDateString

}
//getting services for employees by time slots 
const getServicesByEmployeeAndTimeSlot =async (empId:number,serviceId:number,index:number)=>{
isLoading.value=true
  try {
  const res = await  GET<MainServiceDto[]>(SERVICE_API.SERVICES+`${serviceId}/${empId}/timeslots?day=${reformatDate(appointMentDto.value.date)}`)
  appointMentDto.value.timeSlots[index] = res.data.data
  isLoading.value=false
} catch (error) {
  
  isLoading.value=false
  throw(error)
}
}
//getting List services for employees 


  //getting service employees  . . . 
  const getServiceEmployees =async (serviceId:number,index:number)=>{
    try {
      const res = await GET(SERVICE_API.SERVICES+`${serviceId}`+SERVICE_API.EMPLOYEES)
  appointMentDto.value.employees[index] = res.data.data.employees
  
    } catch (error) {
  throw(error)    
    }
  }
  //create service for provider  .. . 
const createService  = async ()=>{

  isLoading.value= true
  try {
    const obj = {zizi:'zizi'};
    const res = await POST(SERVICE_API.SERVICES,{
      
      ...serviceDto.value
          ,title_en:serviceDto.value.title.en
          ,title_ar:serviceDto.value.title.ar,
          gender:serviceDto.value.gender,
          has_offer:serviceDto.value.has_offer?"1":"0",
          categories_ids:serviceDto.value.categories_ids,
          image:serviceDto.value.image
    },{success:true , error:true},{formData:true});
    isLoading.value=false
    serviceDto.value= new MainServiceDto()
  router.go(-1)
  } catch (error) {
    isLoading.value=false
    throw(error)
  }

}
  //update service  . . .
  const updateService =async ()=>{
    isLoading.value=true
      try {
        if( typeof serviceDto.value.image==='string'){
          delete serviceDto.value.image
          const res = await  POST(SERVICE_API.SERVICES+`${serviceDto.value.id}/update`,{
            ...serviceDto.value
          ,title_en:serviceDto.value.title.en
          ,title_ar:serviceDto.value.title.ar,
       
          gender:serviceDto.value.for_gender_type,
          categories_ids:serviceDto.value.categories,
          has_offer:serviceDto.value.has_offer?"1":"0",
       
          },{success:true , error:true},{formData:false})
        }
        else{
          const res = await  POST(SERVICE_API.SERVICES+`${serviceDto.value.id}/update`,{
            ...serviceDto.value
          ,title_en:serviceDto.value.title.en
          ,title_ar:serviceDto.value.title.ar,
          gender:serviceDto.value.for_gender_type,
          has_offer:serviceDto.value.has_offer?"1":"0",
          categories_ids:serviceDto.value.categories,
       
          },{success:false , error:true},{formData:true})
          delete serviceDto.value.image
          const res2 = await  POST(SERVICE_API.SERVICES+`${serviceDto.value.id}/update`,{
            ...serviceDto.value
          ,title_en:serviceDto.value.title.en
          ,title_ar:serviceDto.value.title.ar,
       
          gender:serviceDto.value.for_gender_type,
          categories_ids:serviceDto.value.categories,
          has_offer:serviceDto.value.has_offer?"1":"0",
       
          },{success:true , error:true},{formData:false})
        }

      isLoading.value=false;
    serviceDto.value= new MainServiceDto();

router.go(-1);
    } catch (error) {
      
      isLoading.value=false
      throw(error)
    }
    }
    //get serivce active loctions  .. . 
    const getServiceActiveLocation =async ()=>{
      isLoading.value=true
        try {
        const res = await  GET<MainServiceDto[]>(SERVICE_API.LOCATIONS)
      servicesList.value = res.data.data
        isLoading.value=false
      } catch (error) {
        
        isLoading.value=false
        throw(error)
      }
      }

      //delete services ... 
      const deleteService = async (id:number)=>{
isLoading.value=true
        try {
  const res = await DELETE(SERVICE_API.SERVICES+`${id}`,{})
  isLoading.value=false
servicesList.value=servicesList.value.filter((service:MainServiceDto)=>{
  return service.id !==id
})
} catch (error) {
  isLoading.value=false
  throw(error)
}
      }


      const removeService = (id:number)=>{
servicesIds.value = servicesIds.value.filter((serviceId:number)=>{
  return  serviceId!== id 
})
      }
      const checkIfServiceIsFound = (id:number)=>{
return  servicesIds.value.filter((serviceId:number)=>{
  return id ==serviceId
}).length>0
      }
      const addService  = (id:number)=>{
if(checkIfServiceIsFound(id)){
  removeService(id)

}
else {
  servicesIds.value =[...servicesIds.value , id]
}
      }
      const checkIfTimeSlotIsFound =(id:number ,index:number )=>{
return  appointMentDto.value.timeSlots_ext_ids[index].filter((item:number)=>{
  return item===id
}).length>0
      }
      const removeAppointmentTimeSlot = (id:number,index:number)=>{
        appointMentDto.value.timeSlots_ext_ids[index]= appointMentDto.value.timeslot_ids.filter((item:number)=>{
          return item!==id
        })
      }
      const addAppointmentTimeSlot =(id:number,index:number)=>{
if (checkIfTimeSlotIsFound(id,index)){
removeAppointmentTimeSlot(id,index)
}
else {
appointMentDto.value.timeSlots_ext_ids[index]= [...appointMentDto.value.timeslot_ids,id]
}
      }
      watch(page,()=>{
        getServicesList();
      })
      
      
  return {servicesList,page,serviceDto,isLoading,getServicesList,getServiceById
  ,getServicesByEmployeeAndTimeSlot
,checkIfTimeSlotIsFound,
addAppointmentTimeSlot
  ,createService,
  updateService
  ,getServiceActiveLocation
  ,checkIfServiceIsFound,
  addService,
  servicesIds,
  deleteService,
  getServiceEmployees,
  appointMentDto,
  perPage,
  
  total,
  AllPages
  }
})
