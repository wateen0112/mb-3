import { SUB_ACCOUNTS_API } from "@/api/subAccount";
import {  SubAccountDto } from "@/api/subAccount/dto"
import { useApi, usePagination } from "@/composables";
import { useAppStore } from "./App";
import { usePermissionStore } from "./Permission";

const {GET,POST,PUT,DELETE}= useApi();

export const useSubAccountStore = defineStore('sub-account',()=>{
const subAccountDto = ref <SubAccountDto>(new SubAccountDto());
const permissionsStore = usePermissionStore();
const {permissionsList ,permissiontsLoading, persmissionsIds}=storeToRefs(permissionsStore)
const subAccountsList = ref<SubAccountDto[]> ([]);
const getPermissions= ()=>{
  permissionsStore.getPermissions()
}
const router = useRouter()
//pagination  ....
const AllPages = ref(0);
const isLoading = ref(false)
const page=ref(1)
const total = ref(0);

const perPage = ref(15)
const getSubAccountsList = async()=>{
  try {
    isLoading.value= true
    const res = await GET<SubAccountDto[]>(SUB_ACCOUNTS_API.SUB_ACCOUNT+`?page=${page.value}`);
    subAccountsList.value = res.data.data;
    AllPages.value = res.data.pagination.last_page
    
  // total.value  =res.data.paginaton.total;
  // perPage.value  =res.data.paginaton.per_page;
    isLoading.value= false
    
  } catch (error) {
    throw(error);
  }}

//   const getSubAccountById = async(id:number)=>{
  
// try {
//   subAccountDto.value = subAccountsList.value.filter((item:SubAccountDto)=>{
//     return item.id===id
//   })[0]
// } catch (error) {
//   page.value=page.value+1
// }



//   }
    const updateSubAccount =  async()=>{
      
isLoading.value= true
      try {
        const res = await PUT(SUB_ACCOUNTS_API.UPDATE+`${subAccountDto.value.id}`,{...subAccountDto.value,
        
          permissions_ids:persmissionsIds.value
        },{success:true , error:true})
        
isLoading.value= false
subAccountDto.value = new SubAccountDto()
router.go(-1)
      } catch (error) {
        isLoading.value= false
        throw(error)
        

      }
    }

const deleteSubAccount =  async (id:number)=>{

  try {
    isLoading.value = true
    const res = await  DELETE(SUB_ACCOUNTS_API.SUB_ACCOUNT+`${id}`,{error:true, success:true})
  
  subAccountsList.value = subAccountsList.value.filter((subAccount:SubAccountDto)=>{
    return subAccount.id!==id
  });

  useAppStore().closeModal();
  isLoading.value=false;
  } catch (error) {
    
  
  }
}

  const createSubAccount =async ()=>{
    isLoading.value=true
    try {
      const res = await POST (SUB_ACCOUNTS_API.SUB_ACCOUNT , {...subAccountDto.value,
      
      permissions_ids:subAccountDto.value.permissions
      },{error:true, success:true});
    subAccountsList.value= [...subAccountsList.value,subAccountDto.value]
  isLoading.value=false ; 
  subAccountDto.value = new SubAccountDto()
  router.go(-1)
  } catch (error) {
    isLoading.value= false
      throw(error)
    }
  }

 //pagination watching  . .. 
 watch(page,()=>{
  getSubAccountsList();
 })

return {perPage,total,permissiontsLoading,permissionsList,getPermissions,isLoading,subAccountDto , subAccountsList , getSubAccountsList ,updateSubAccount, deleteSubAccount,createSubAccount,AllPages,page ,persmissionsIds}


})
