import { defineStore } from 'pinia';
import { useAuth } from '@/@core/composable/useAuth';
import { AUTH_API } from '@/api/Auth/index';
import { useToast } from 'vue-toastification';
import { useApi } from '@/composables';
import { API_URL } from '~config';
import axios from 'axios';
import { UserDto } from '@/api/Auth/AuthDto';
import router from '@/router';
const toast = useToast();

const phone = ref('');
const otp = ref()
const emailAuth = ref({
  email:'',
  password:''
})

export const useAuthorization = defineStore('AuthorizationStore', () => {
  const { SetUserData } = useAuth();
  const { POST,GET } = useApi();
  const authDto = ref({
    email: '',
    code: '',
    newPassword: '',
  });
//to delete
  const userDto = ref <UserDto>(new UserDto())
const resendOtp= async ()=>{
try {
  const res = await POST(AUTH_API.ResendOtp,{mobile:phone.value},{error:true})
} catch (error) {
  throw (error)
}
}
const getUserData = ()=>{
  
    userDto.value  = JSON.parse(localStorage.getItem(`user-data`))
}


const logout = async ()=>{
  try {
    const res = await POST (AUTH_API.Logut,{});
    localStorage.removeItem('user-data');
    router.push('/login')
  } catch (error) {
    
  }
}
  return {getUserData,logout,resendOtp,userDto,otp,emailAuth , phone, authDto, };
});
