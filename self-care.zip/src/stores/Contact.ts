import { CONTACT_API } from "@/api/contact"
import { useApi } from "@/composables"
const  {GET , POST , DELETE}= useApi()
export const useContactStore = defineStore('contact',()=>{
  const router = useRouter()
const sendContact = async(types:string[] , message:string)=>{
try {
  const res   = await GET(CONTACT_API.CONTACT_US, {  types:types, message:message},{success:true , error:true});
router.go(-1)
  
} catch (error) {
  throw(error)
}

}


  return  {sendContact}
})
