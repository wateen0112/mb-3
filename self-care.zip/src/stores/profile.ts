import { PROFILE_API } from "@/api/profile"
import {  LocationDto, ProfileDto } from "@/api/profile/dto"
import { useApi } from "@/composables"
import UserProfileVue from "@/layouts/components/UserProfile.vue"
import { useAuthorization } from "./Auth"
import { axiosIns } from "@/plugins/axios"
import { useAuth } from "@/composables"
import { useI18n } from "vue-i18n"
const router = useRouter()
const {userDto}= storeToRefs(useAuthorization())
const {DELETE,GET,POST} = useApi()
export const useProfileStore= defineStore('profile', ()=>{
  const {t}= useI18n()
  const profileDto = ref<ProfileDto>(new ProfileDto()) // for signup pages  . .
  //for show profile pages 
const locationDto = ref<LocationDto>(new LocationDto())  
const updateProfile = async (success:boolean=false)=>{
  try {
    const res = await POST(PROFILE_API.UPDATE , {...profileDto.value },{ success:success?t('profile.updated'):'', error:true},{formData:true} ) 

  } catch (error) {
    throw(error)
  }
}
const showProfile= async()=>{
  try {
    const res = await GET<ProfileDto>(PROFILE_API.SHOW_PROFILE)
    profileDto.value = res.data.data
    profileDto.value.oldImage = profileDto.value.image;
   
  } catch (error) {
    throw(error)
  }
}
const addLocation  = async ()=>{
  try {
    const res =  await POST(PROFILE_API.ADD_LOCATION,locationDto.value,{error:true})
 
  } catch (error) {
    throw(error)
  }
}
  return  {profileDto,updateProfile,locationDto,addLocation,showProfile }
})
