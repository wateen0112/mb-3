import { EmployeeDto } from "@/api/employee/dto";
import { useApi } from "@/composables";
import  {EMPLOYEE_API}from '@/api/employee';
import  {useServiceStore } from  '@/stores/Service'
import { usePermissionStore } from "./Permission";
const {GET,POST,PUT,DELETE} = useApi()
export const useEmployeeStore = defineStore('employee',()=>{
const employeesList = ref<EmployeeDto[]>([]);
const employeeDto   = ref<EmployeeDto>(new EmployeeDto());
//permissions store   and services store . . .
const serviceStore = useServiceStore(); 
const location  = ref([])
const permissionsStore = usePermissionStore();
const  {servicesList , servicesIds} =storeToRefs(serviceStore)
const  {permissionsList,persmissionsIds,permissiontsLoading}= storeToRefs(permissionsStore)
const getPermissionsAndServices = ()=>{
  permissionsStore.getPermissions();
  serviceStore.getServicesList()
}
//loading . . .
const isLoading= ref(false)
//router  . . .
const router  = useRouter()
// paginations  . . . 
const page = ref(1);
const AllPages = ref(0)
const perPage = ref(15)
const total  = ref(0)
//get employees list  . . . 
const getEmployeesList = async()=>{
  isLoading.value=true
  try {
    const res = await GET<EmployeeDto[]>(EMPLOYEE_API.EMPLOYEES+`?page=${page.value}`)
    employeesList.value = res.data.data
    AllPages.value = res.data.pagination.last_page;
    total.value  =res.data.pagination.total
    perPage.value  =res.data.pagination.per_page
    isLoading.value=false
  } catch (error) {
    isLoading.value=false
    throw(error)
  }
} 

//getting emoloyee details  . .. 
const getEmployeeById = (id:number)=>{
  employeeDto.value = employeesList.value.filter((emp:EmployeeDto)=>{
    return emp.id ===id
  })[0];
servicesIds.value= employeeDto.value.services
}
// create employee . . 
const createEmployee = async()=>{
  isLoading.value=true
  try {
    const res = await POST(EMPLOYEE_API.EMPLOYEES,{...employeeDto.value,
      permissions_ids:persmissionsIds.value,
    name_en:employeeDto.value.name.en,
    name_ar:employeeDto.value.name.ar,
   
  },{success:true , error:true})
    
  employeeDto.value = new EmployeeDto()
    isLoading.value=false
    router.go(-1)
  } catch (error) {
    isLoading.value=false
    throw(error)
  }
} 
//update employee   . . 
const updateEmployee = async()=>{
  isLoading.value=true
  try {
    const res = await PUT(EMPLOYEE_API.EMPLOYEES+`${employeeDto.value.id}`,{...employeeDto.value,
    permissions_ids:persmissionsIds.value,
    name_en:employeeDto.value.name.en,
    name_ar:employeeDto.value.name.ar
    },{success:true , error:true})
        
  employeeDto.value = new EmployeeDto()
    isLoading.value=false
    router.go(-1)
  } catch (error) {
    isLoading.value=false
    throw(error)
  }
} 
//delete employee . . 
const deleteEmployee = async(id:number)=>{
  isLoading.value=true
  try {
    const res = await DELETE (EMPLOYEE_API.EMPLOYEES+`${id}`,null)
  
    isLoading.value=false
 employeesList.value = employeesList.value.filter((item:EmployeeDto)=>{
  return item.id!==id
 })
  } catch (error) {
    isLoading.value=false
    throw(error)
  }
} 
//wathcing paginaitons  . ..  
watch(page,()=>{
  getEmployeesList();
})

//watching location  .. 
watch(location,()=>{
  let atHome = location.value.filter((item:string)=>{
    return item ==='home'
  }).length>0
  let atStore =location.value.filter((item:string)=>{
    return item ==='store'
  }).length>0
employeeDto.value.location[0].home=atHome
employeeDto.value.location[1].store=atStore
})
return {perPage,location,total, servicesIds, servicesList,permissiontsLoading,getPermissionsAndServices,persmissionsIds,permissionsList,page,AllPages, employeeDto , employeesList , isLoading,createEmployee , updateEmployee, deleteEmployee, getEmployeesList,getEmployeeById}
})
