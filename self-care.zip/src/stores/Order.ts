import { useApi } from "@/composables"
import { OREDER_STATUS } from "@/enums/OrderStatus"
import  {ORDER_API} from '@/api/order'
import { ChangeOrderStatusDto,OrderDto } from "@/api/order/dto"
import { MainServiceDto, TimeSlotDto } from "@/api/service/dto"
import { useDateTime } from "@/composables/useDateTime"
export const useOrderStore = defineStore('order',()=>{
  const {GET,POST,DELETE,PUT} = useApi()
  const ordersList = ref<OrderDto[]>([]);
  const unreadCount = ref(0)
  const isRequestedOrders = ref(false)
  const page = ref(0);
  const total = ref(0);
const allPages = ref(0)
const seconds =ref<String|number>(0);
const minutes = ref<String|number>(0);
  const confirm = ref(false) //discare chaing when updating order
const order = ref<OrderDto>(new OrderDto())
const ordersUnreadCount = ref(0);
const servicesToBeAdded = ref<MainServiceDto[]>([])
const {reformatDate} = useDateTime()
const orderOldPrice = ref(0)
const ordersReadCount = ref(0);
const isLoading = ref(false)
const editMode = ref(false)
const timslotsList = ref<TimeSlotDto[]>([])
const changeOrderDto = ref<ChangeOrderStatusDto>(new ChangeOrderStatusDto())
const startTimer = () => {
  order.value.waiting_time= order.value.waiting_time*60;

  setInterval(() => {
    if (--  order.value.waiting_time >= 0) {
      minutes.value = Math.floor(  order.value.waiting_time / 60)
        .toString()
        .padStart(2, "0");
      seconds.value = (  order.value.waiting_time % 60).toString().padStart(2, "0");
    }
  }, 1000);
}; 
const getOrdersList = async(status:OREDER_STATUS|string=OREDER_STATUS.ALL)=>{
    isRequestedOrders.value = false
    isLoading.value= true;
    try {
      const res = await GET<OrderDto[]>(ORDER_API.ORDERS+`?page=${page.value}`,{status:status},{error:true})
      ordersList.value= res.data.data;
      total.value = res.pagination.total; 
      allPages.value = res.data.pagination.last_page;
      isLoading.value= false;
} catch (error) {
  isLoading.value= false;
  throw(error)
}
  }

  const getOrderById =async(id:number)=>{
    try {
      const res = await GET<OrderDto[]>(ORDER_API.ORDERS+`${id}`);
      order.value= res.data.data;
     
      orderOldPrice.value=order.value.total_price
if(order.value.is_gifted){
  startTimer();
}
    } catch (error) {
      throw(error)
    }
  }
  const getRequestedOrders =   async ()=>{
    isRequestedOrders.value =true
    isLoading.value = true;
    try {
    
      const res = await GET<OrderDto[]>(ORDER_API.NEW);
      ordersList.value = res.data.data;
      isLoading.value=false
    } catch (error) {
      isLoading.value=false
 throw(error)     
    }
  }
  const getReadCount = async()=>{
    try {
      const res = await GET(ORDER_API.READ_COUNT);
  
      ordersReadCount.value = res.data.count;
    } catch (error) {
      throw(error)
    }
  }
  const getUnreadCount = async()=>{
    try {
      const res = await GET<number>(ORDER_API.UNREAD_COUNT);
      unreadCount.value = res.data.data.count;

    } catch (error) {
      throw(error)
    }
  }
const acceptOrder = async (id:number)=>{
  try {
    const res = await GET (ORDER_API.ORDERS+id+ORDER_API.ACCEPT,{error:true})
  } catch (error) {
    throw(error)
  }
}
const changeStatus = async()=>{
  try {
    const res  = await POST(ORDER_API.ORDERS+order.value.order_id+ ORDER_API.CHANGE_STATUS,{...changeOrderDto.value

    //there is more settings here  . . . .

    },{success:true , error:true})
    order.value.order_status=changeOrderDto.value.status
  } catch (error) {
    throw(error)
  }
}
const confirmPayment = async (id:number)=>{
try {
  const res = await POST(ORDER_API.ORDERS+id+ORDER_API.CONFIRM_PAYMENT,null)
  //there is more settings here  . . .. . but we are wating for payment done 
} catch (error) {
  throw(error)
}
}
const sendPaymentNotification = async (id:number)=>{
  try {
    const res = await POST(ORDER_API.ORDERS+id+ORDER_API.SEND_PAYMENT_NOTIFICATION,{})
    //there is more settings here  . . .. . but we are wating for payment done 
  } catch (error) {
    throw(error)
  }
  }
  const getAvailabletimeslot = async(date:string)=>{
    try {
      const res = await GET(ORDER_API.ORDERS+order.value.order_id+ORDER_API.GET_AVAILABLE_TIME_SLOT+`?date=${reformatDate(date)}`)
      timslotsList.value = res.data.data;
    } catch (error) {
      
    }
  }
  const updateOrder = async ()=>{
    try {
      const res = await PUT (ORDER_API.ORDERS,order.value);
    } catch (error) {
      throw(error)
    }
  }
watch(page,()=>{
if(isRequestedOrders.value){
getRequestedOrders();

}
else{
  getOrdersList()
}
})


  return{
    minutes,seconds,
    allPages,total, page , isLoading,getReadCount,updateOrder,getUnreadCount,unreadCount,orderOldPrice,confirm,servicesToBeAdded,editMode,changeOrderDto, changeStatus,sendPaymentNotification,confirmPayment,timslotsList,getAvailabletimeslot,getOrdersList,order,getRequestedOrders,ordersList,getOrderById}
})
