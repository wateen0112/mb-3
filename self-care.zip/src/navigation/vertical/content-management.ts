import type { VerticalNavItems } from '@/@layouts/types';

export default [
  // {
  //   title: 'sidebar.home',
  //   to: { path: '/' },
  //   icon: { icon: 'tabler:home' },
  // },
  {
    title: 'sidebar.profile',
    to: { name: 'home-profile' },
    icon: { icon: 'tabler:user' },
  },
  {
    title: 'sidebar.workingTime',
    to: { name: 'home-workingTime' },
    icon: { icon: 'tabler:clock' },
  },
  {
    title: 'sidebar.myCalendar',
    to: { name: 'home-myCalendar' },
    icon: { icon: 'tabler:calendar' },
  },
  {
    title: 'sidebar.myServices',
    to: { name: 'home-myServices' },
    icon: { icon: 'tabler:accessible' },
  },
  {
    title: 'sidebar.myEmployees',
    to: { name: 'home-myEmployees' },
    icon: { icon: 'tabler:users' },
  },
  {
    title: 'sidebar.subAccount',
    to: { name: 'home-subAccount' },
    icon: { icon: 'tabler:user-plus' },
  },
  {
    title: 'sidebar.contactUs',
    to: { name: 'home-contactUs' },
    icon: { icon: 'tabler:phone-call' },
  },
  {
    title: 'sidebar.termsAndConditions',
    to: { name: 'home-terms' },
    icon: { icon: 'tabler:border-all' },
  },
  {
    title: 'sidebar.privacy',
    to: { name: 'home-privacy' },
    icon: { icon: 'tabler:shield' },
  },
  {
    title: 'sidebar.about',
    to: { name: 'home-about' },
    icon: { icon: 'tabler:info-circle' },
  },
  {
    title: 'sidebar.logout',
    to: { path: 'logout' },
    icon: { icon: 'tabler:logout' },
  },

] as VerticalNavItems;
