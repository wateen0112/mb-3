import type { VerticalNavItems } from '@/@layouts/types'
import contentManagement from './content-management'

export default [

  ...contentManagement,


] as VerticalNavItems

// https://icones.netlify.app/collection/tabler?s=store
