<script setup lang="ts">
import img1 from '@/assets/images/svg/1.svg'
</script>
<template>
  <div class="flex justify-center items-center flex-col pt-[100px]">

    <div class="w-[340px] h-[340px] overflow-hidden relative">
    
      <img class="absolute top-0 left-0  w-full h-full object-cover" :src="img1" alt="">
    </div>
    <h2 class="text-primary font-normal capitalize">self care notification</h2>
    <p  class=" mt-5 text-center w-[50%]  min-w-[340px]">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam, corporis? At, libero odio repellat aliquid facilis fugiat reiciendis dolor laboriosam sunt? Culpa eos omnis totam reiciendis minus illo iste animi?</p>   
    </div>
</template>
