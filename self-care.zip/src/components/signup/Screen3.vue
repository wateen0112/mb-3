<script setup lang="ts">
import Step1 from '@/pages/signup/steps/Step1.vue';

</script>
<template>
  <div class="lg:px-32">
    <Step1/>
 </div>
</template>
