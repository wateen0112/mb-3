<script setup lang="ts">
const isActive = ref(false);
const props = defineProps({
  add: {
    type: Boolean,
    required: false,
    default: false,
  },
  icon: {
    type: String,
    required: false,
  },
  activeIcon: {
    type: String,
    required: false,
  },
  content: {
    type: String,
    required: true,
  },
  value: {
    type: String,
    required: false,
  },
});
const emit = defineEmits(["serviceEvent"]);
const clickEvent = () => {
  if (!props.add) {
    emit("serviceEvent");
    isActive.value = !isActive.value;
  }
};
</script>
<template>
  <div
    @click="clickEvent"
    :class="{ ' border-none bg-[#ff9e4356]': isActive }"
    class="prevent-select capitalize cursor-pointer border-solid border-[3px] w-[110px] h-[110px] flex justify-center items-center flex-col gap-3 rounded-lg border-gray-400"
  >
    <img
      v-if="icon && !add"
      class="h-[34px]"
      :src="isActive ? activeIcon : icon"
      alt=""
    />
    <VIcon
      size="30"
      v-if="add"
      class="p-2 rounded-full bg-gray-600 text-white"
      icon="tabler:plus"
    />
    <p class="text-sm" v-if="add === true">{{ content }}</p>
    <p class="text-sm" v-else :class="{ 'text-primary': isActive }">
      {{ content }}
    </p>
  </div>
</template>
<style>
/*
prevent text selection  . . . 
*/
.prevent-select {
  -webkit-user-select: none; /* Safari */
  -ms-user-select: none; /* IE 10 and IE 11 */
  user-select: none; /* Standard syntax */
}
</style>
