<script setup lang="ts">
import { stringLiteral } from "@babel/types";
import { useAppStore } from "@/stores/App";
import { useI18n } from "vue-i18n";
import { useLayouts } from "@core/composable/useLayout"
import { useEmployeeStore } from "@/stores/Employee";
import { useServiceStore } from "@/stores/Service";
import { useFile } from "@/composables";
import { EmployeeDto } from "@/api/employee/dto";
import { useDateTime } from "@/composables/useDateTime";
import { MainServiceDto } from "@/api/service/dto";
const { locale } = useI18n();
const store = useServiceStore();
const { appointMentDto, servicesList } = storeToRefs(store);
const appStore = useAppStore();
const { sidebarOpend } = storeToRefs(appStore);
const { isAppRtl } = useLayouts();
const { getFileUrl } = useFile();
const employeeStore = useEmployeeStore();
const { employeesList } = storeToRefs(employeeStore);
const props = defineProps({
  type: {
    type: String,
    default: "accepted",
  },
  index: {
    type: Number,
    default: 0,
  },
});

document.querySelector(".layout-overlay ")?.addEventListener("click", () => {
  sidebarOpend.value = false;
});
const selectedEmployees = ref<EmployeeDto[]>([]);
const selctedServices = ref<MainServiceDto[]>([]);
const { showDayName, getClock } = useDateTime();
onMounted(() => {
  appointMentDto.value.service_ids.forEach((id: number) => {
    const serviceItem =
      servicesList.value.filter((service: MainServiceDto) => {
        return service.id === id;
      }) ?? new MainServiceDto();
    selctedServices.value.push(serviceItem);
  });
  appointMentDto.value.employee_ids.forEach((id: number) => {
    const employeeItem =
      employeesList.value.filter((emp: EmployeeDto) => {
        return emp.id === id;
      }) ?? new MainServiceDto();
    selectedEmployees.value.push(employeeItem);
  });
});
</script>
<template>
  <div class="flex justify-between flex-row items-center w-full z-50">
    <VBtn @click="appStore.closeSidebar()" variant="text">
      <VIcon v-if="!isAppRtl" size="40">mdi-chevron-left</VIcon>
      <VIcon v-else size="40">mdi-chevron-right</VIcon>
    </VBtn>
    <div class="flex flex-row justify-center items-center gap-2">
      <h2 class="text-primary">#1346</h2>
      <VBtn variant="text" icon="tabler:edit" />
    </div>
  </div>
  <div
    class="lg:px-5 grid grid-cols-1 gap-4 mt-4"
    :class="!isAppRtl ? 'lg:pl-20' : 'lg:pr-20'"
  >
    <div
      class="flex justify-between items-center sidebar mb-4"
      :class="{ 'flex-row': locale === 'AR' }"
    >
      <h2>{{ appointMentDto.customer_name }}</h2>
      <VChip variant="elevated" :rounded="false" color="primary">walk in</VChip>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-normal text-gray-400">Service location</h3>
      <div>
        <VIcon
          color="primary"
          size="30"
          :icon="appointMentDto.atStore ? 'mdi-store' : 'mdi-home'"
        />
        <VText class="text-on-surface">{{
          appointMentDto.atStore ? "ar store " : "at home"
        }}</VText>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Date</h3>
      <div>
        <VText class="text-on-surface text-lg">{{
          showDayName(appointMentDto.date)
        }}</VText>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Time</h3>
      <div>
        <VText class="text-on-surface text-lg">{{ getClock(appointMentDto.date) }}</VText>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Phone</h3>
      <div>
        <VText class="text-on-surface text-lg"
          >+{{ appointMentDto.customer_phone }}</VText
        >
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Employee</h3>
      <div>
        <VText class="text-on-surface text-lg"
          >{{
            locale === "en"
              ? appointMentDto.employees[0][0].name__ml.en
              : appointMentDto.employees[0][0].name__ml.ar
          }}
        </VText>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Status</h3>
      <div><VText class="text-on-surface text-lg"></VText></div>
    </div>
    <VDivider />
    <div class="grid grid-cols-1 px-3 gap-3">
      <VText class="text-on-surface">Services</VText>
      <div class="flex flex-row gap-3" v-for="(service, index) in selctedServices">
        <img
          class="w-[80px] h-[80px] object-cover rounded-lg shadow-lg"
          :src="getFileUrl(service.image ?? '')"
          alt=""
        />{}
        <div class="flex justify-between flex-row w-full">
          <div class="flex flex-col justify-center gap-3">
            <VText class="text-primary">{{
              locale === "en" ? service.title.en : service.title.ar
            }}</VText>
            <VText> employee :{{ selectedEmployees[index] }}</VText>
          </div>
          <div class="flex flex-col justify-end pb-3">
            <!-- <VText>{{service.+$t('myOrders.sar')}}</VText> -->
          </div>
        </div>
        {{ selctedServices }}
      </div>
    </div>
    <VDivider />
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-on-surface text-xl mb-2">Payment Details</h3>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Payment Price</h3>
      <div><VText class="text-on-surface text-lg"> $120.00</VText></div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">Payment Status</h3>
      <div><VText class="text-on-surface text-lg">Paid</VText></div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-normal text-on-serface">Total Amount</h3>
      <div><VText class="text-on-surface text-lg">$120.00</VText></div>
    </div>
    <div class="flex justify-center mt-2 items-center">
      <VBtn
        class="capitalize"
        height="50"
        @click="appStore.closeSidebar"
        color="primary "
        width="300px"
      >
        confirm appointment
      </VBtn>
    </div>
  </div>
</template>
<style>
.sidebar .v-chip {
  border-radius: 8px !important;
}
/* ===== Scrollbar CSS ===== */
/* Firefox */
.sidebar {
  scrollbar-width: auto;
  scrollbar-color: #ff9f43 #ffffff;
}

/* Chrome, Edge, and Safari */
.sidebar::-webkit-scrollbar {
  display: none;
}
</style>
