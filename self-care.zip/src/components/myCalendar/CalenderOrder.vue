<script setup lang="ts">
import Massage from "@/assets/images/svg/massage-active.svg";
import { useAppStore } from "@/stores/App";
const appStore = useAppStore();

const props = defineProps(["order", "walk-in"]);
</script>
<template>
  <VCard
    @click="appStore.openSidebar"
    class="px-3 py-2 h-[120px] flex flex-col gap-0 relative"
  >
    <div
      class="absolute top-0 right-0 px-4 py-1 bg-primary text-white font-semibold rounded-bl-xl opacity-70"
    >
      walk in
    </div>

    <h2 class="mt-5 font-semibold">John Smith</h2>

    <div class="mt-5 px-3 flex justify-start items-center gap-2">
      <div class="flex justify-start items-center gap-2">
        <img class="h-[26px]" :src="Massage" alt="" />

        <span class="">massage</span>
      </div>
      <div class="flex justify-start items-center gap-4">
        <VIcon color="primary">tabler:clock</VIcon>

        <span class="">10:00 Am</span>
      </div>
    </div>
  </VCard>
</template>
