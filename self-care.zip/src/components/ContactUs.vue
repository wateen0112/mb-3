<script setup lang="ts">
import Contact from "@/assets/images/svg/contact-us.svg";
import Web from "@/assets/images/svg/web.svg";
import Whatsapp from "@/assets/images/svg/whatsapp.svg";
import Gmail from "@/assets/images/svg/gmail.svg";
import { useContactStore } from "@/stores/Contact";
import { useI18n } from "vue-i18n";
import { requiredValidator } from "@validators";
import { off } from "process";
const myForm = ref(null);
const { t } = useI18n();
const store = useContactStore();
const types = ref(["news"]);
const message = ref("");
const submit = () => {
  myForm.value?.validate().then((valid: any) => {
    if (valid.valid) {
      store.sendContact(types.value, message.value);
    }
  });
};
</script>
<template>
  <VForm
    ref="myForm"
    class="grid capitalize pt-40 grid-cols-1 lg:px-0 px-5 gap-8 lg:grid-cols-2"
  >
    <div class="flex flex-col gap-3 px-10">
      <p>{{ t("contactUs.howWeCanContact") }}</p>
      <div>
        <VCheckbox
          value="news"
          :multiple="true"
          v-model="types"
          :label="t('contactUs.news')"
        />
        <VCheckbox
          value="lnquiry"
          :multiple="true"
          v-model="types"
          :label="t('contactUs.lnquiry')"
        />
        <VCheckbox
          value="suggestions"
          :multiple="true"
          v-model="types"
          :label="t('contactUs.suggestions')"
        />
      </div>
      <p class="text-xl">{{ $t("contactUs.message") }}</p>
      <div class="">
        <VTextarea
          :rules="[requiredValidator]"
          v-model="message"
          :no-resize="true"
          placeholder="type here your message"
        />
      </div>
      <div class="grid grid-cols-10 gap-5">
        <VBtn class="col-span-8" height="46" @click="submit()">{{
          $t("contactUs.message")
        }}</VBtn>
        <VBtn class="col-span-2" height="46" variant="outlined">{{
          $t("contactUs.call")
        }}</VBtn>
      </div>
    </div>
    <!-- second column-->
    <div class="flex flex-col justify-between items-center">
      <div class="overflow-hidden w-full">
        <img :src="Contact" class="object-cover w-full" alt="" />
      </div>
      <div class="flex justify-center items-center gap-5">
        <a href=""><img width="60" :src="Web" alt="" /></a>
        <a href=""><img width="60" :src="Whatsapp" alt="" /></a>
        <a href=""><img width="60" :src="Gmail" alt="" /></a>
      </div>
    </div>
  </VForm>
</template>
