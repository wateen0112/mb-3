<template>
  <div class="loading z-40"></div>
</template>
<style>
.loading {
  display: inline-block;
  width: 80px;
  height: 80px;
  z-index: 999999 !important;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -100%);
}

.loading:after {
  content: " ";

  display: block;
  width: 80px;
  height: 80px;
  margin: 4px;
  border-radius: 50%;
  z-index: 99999999999999999;
  border: 4px solid #ff9e59;
  border-color: #ff9e59 transparent #ff9e59 transparent;
  animation: loading 1.2s linear infinite;
}

@keyframes loading {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>
