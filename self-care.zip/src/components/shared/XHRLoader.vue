<template>
  <div class="fixed z-[2500] w-[350px] bottom-16 left-10">
    <VCard>
      <VCardTitle class="my-2">
        يرجى الانتظار ...
      </VCardTitle>
      <VProgressLinear indeterminate color="primary" />
    </VCard>
  </div>
</template>
