<template>
  <div class="custom-file-input" :class="class">
    <label class="button bg-primary" :class="class">
      <i class="material-icons icon"
        ><VIcon class="" size="22">{{ icon }}</VIcon></i
      >

      <input type="file" class="hidden" @change="handleFileChange" ref="fileInput" />
    </label>
  </div>
</template>

<script setup lang="ts">
const fileInput = ref();
const props = defineProps({
  class: {
    type: String,
    default: "bg-primary w-[50px] h-[50px] rounded-full",
  },
  modelValue: {
    type: File,
    default: null,
    required: true,
  },
  label: {
    type: String,
    default: "Choose File",
  },
  icon: {
    type: String,
    default: "mdi-plus",
  },
  color: {
    type: String,
    default: "primary",
  },
});
const emit = defineEmits(["update:modelValue"]);
function handleFileChange() {
  const file = fileInput.value.files[0];
  emit("update:modelValue", file);
}
</script>

<style>
.custom-file-input .button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 30px;
  min-width: 30px !important;
  padding: 0 16px;
  font-size: 16px;
  font-weight: bold;
  color: #fff;

  border: none;

  cursor: pointer;
}

.custom-file-input .icon {
  font-size: 24px;
}

.custom-file-input .hidden {
  display: none;
}
</style>
