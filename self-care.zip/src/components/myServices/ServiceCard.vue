<script setup lang="ts">
import { useLayouts } from "@core/composable/useLayout"
import { MainServiceDto } from "@/api/service/dto";
import { useFile } from "@/composables";
import { useI18n } from "vue-i18n";

const { locale } = useI18n();
const router = useRouter();

const { getFileUrl } = useFile();
const props = defineProps({
  service: {
    type: MainServiceDto,
    default: new MainServiceDto(),
  },
});
const { isAppRtl } = useLayouts();
</script>
<template>
<div class="">
    <router-link :to="`myservices/${service.id}`" class="lg:ml-40">
      <VCard
        class="shadow-md grid px-5 grid-cols-6 pt-5 items-center min-w-[340px] lg:w-[380px] h-[100px]"
      >
        <div class="col-span-5 flex justify-start items-center gap-5">
          <img :src="getFileUrl(service.image ?? '')" alt="" />
          <span class="text-black text-xl">{{
            locale === "ar" ? service.title.ar : service.title.en
          }}</span>
        </div>

        <div class="col-span-1 flex justify-end">
          <VIcon color="gray-400">
            {{ isAppRtl ? "mdi-chevron-left" : "mdi-chevron-right" }}
          </VIcon>
        </div>
      </VCard>
    </router-link>
  </div>
</template>
