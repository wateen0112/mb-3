<script setup lang="ts">
import Logo from "@/assets/images/svg/about.svg";
import  {useAboutStore} from '@/stores/About';
const store = useAboutStore();
const  {about }= storeToRefs(store);
onMounted(()=>{
  store.getAbout()
})
</script>
<template>
  <div class="w-full flex justify-center items-center flex-col">
    <img :src="Logo" class="mt-28" />
    <div class="mt-8 lg:px-14">
      <div class="px-5">
        <p class="font-bold">
        {{ about.title }}
        </p>
     
        <p class="mt-8">
       {{about.content}}
        </p>
      </div>
    </div>
  </div>
</template>
<style>
ul {
  padding: 0px 15px;
  list-style: disc;
}
</style>
