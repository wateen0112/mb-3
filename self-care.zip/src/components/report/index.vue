<template>
  <div>Add report</div>
</template>
