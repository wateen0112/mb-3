<template>
  <div>Add product</div>
</template>
