<script setup lang="ts">
import { useLayouts } from "@core/composable/useLayout"

import { useSubAccountStore } from "@/stores/SubAccount";
const store = useSubAccountStore();
const router = useRouter();
const { subAccountDto, persmissionsIds } = storeToRefs(store);
const props = defineProps(["action", "user"]);
const { isAppRtl } = useLayouts();
const clickEventHandler = () => {
  subAccountDto.value = props.user;
  persmissionsIds.value = subAccountDto.value.permissions;
  router.push(`subaccount/${props.user.id}`);
};
</script>
<template>
  <div
    @click="clickEventHandler"
    class="justify-start gap-5 flex items-center lg:min-w-[460px] min-w-[320px]"
  >
    <VCard class="shadow-md h-[80px] flex min-w-full items-center px-5">
      <div class="flex justify-between items-center w-full">
        <h3>{{ user.name }}</h3>

        <VBtn
          variant="text"
          color="on-surface"
          :icon="isAppRtl ? 'mdi-chevron-left' : 'mdi-chevron-right'"
        />
      </div>
    </VCard>
  </div>
</template>
