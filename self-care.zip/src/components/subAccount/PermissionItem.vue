<script setup lang="ts">
import { PermissionDto } from "@/api/permission/dto";
import { usePermissionStore } from "@/stores/Permission";
import { useI18n } from "vue-i18n";
const store = usePermissionStore();
const props = defineProps({
  permission: {
    type: PermissionDto,
    default: new PermissionDto(),
  },
});
const { locale } = useI18n();
const active = ref(store.checkIfPermissionIsFound(props.permission.id));

const clickEvnt = () => {
  active.value = !active.value;
  store.addPermission(props.permission.id);
};
</script>
<template>
  <VBtn
    class="capitalize rounded-full"
    @click="clickEvnt"
    variant="tonal"
    :color="active ? 'primary' : 'gray-400'"
    >{{
      locale === "en" ? permission?.title__ml.en ?? permission : permission?.title__ml.en
    }}</VBtn
  >
</template>
