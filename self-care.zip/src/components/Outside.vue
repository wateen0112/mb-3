<script setup lang="ts">
import { useI18n } from "vue-i18n";
const underline = "underline";
const props = defineProps(["active"]);
const { t } = useI18n();
</script>
<template>
  <div>
    <nav class="bg-primary w-full h-[50px] fixed flex justify-center items-center">
      <div class="text-white">
        <RouterLink to="/" :class="{ underline: active === 'home' }"
          ><span class="text-white mx-2">{{ $t("sidebar.home") }}</span></RouterLink
        >

        <RouterLink to="/terms"
          ><span :class="{ underline: active === 'terms' }" class="text-white mx-2">{{
            $t("sidebar.termsAndConditions")
          }}</span></RouterLink
        >

        <RouterLink to="/pravicy"
          ><span :class="{ underline: active === 'pravicy' }" class="text-white mx-2">{{
            $t("sidebar.privacy")
          }}</span></RouterLink
        >

        <RouterLink to="/about"
          ><span class="text-white mx-2" :class="{ underline: active === 'about' }">{{
            $t("sidebar.about")
          }}</span></RouterLink
        >

        <RouterLink to="/contact"
          ><span class="text-white mx-2" :class="{ underline: active === 'contact' }">{{
            $t("sidebar.contactUs")
          }}</span></RouterLink
        >
      </div>
    </nav>
    <slot name="body">
      <div></div>
    </slot>
  </div>
</template>
