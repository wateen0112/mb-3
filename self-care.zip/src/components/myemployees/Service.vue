<script setup lang="ts">
import { MainServiceDto } from "@/api/service/dto";
import { useFile } from "@/composables";
import { useServiceStore } from "@/stores/Service";
import { useI18n } from "vue-i18n";
const store = useServiceStore();
const { locale } = useI18n();
const { getFileUrl } = useFile();
const props = defineProps({
  service: {
    type: MainServiceDto,
    default: new MainServiceDto(),
  },
});
const active = ref(store.checkIfServiceIsFound(props.service.id));

const clickEvnt = () => {
  active.value = !active.value;
  store.addService(props.service.id);
};
</script>
<template>
  <VBtn
    class="capitalize rounded-full"
    @click="clickEvnt"
    variant="tonal"
    :color="active ? 'primary' : 'gray-400'"
  >
    <!-- <img
      :src="getFileUrl(service.image ?? '')"
      class="w-[30px] h-[30px] mx-3 object-cover border-none"
      alt=""
    /> -->
    {{ locale === "ar" ? service.title.ar : service.title.en }}</VBtn
  >
</template>
