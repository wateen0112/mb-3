<script setup lang="ts">
import { useLayouts } from "@core/composable/useLayout"
import { config } from "@/@layouts/config";
import { useEmployeeStore } from "@/stores/Employee";
import { useI18n } from "vue-i18n";
const store = useEmployeeStore();
const { t, locale } = useI18n();
const router = useRouter();
const { employeeDto, persmissionsIds } = storeToRefs(store);
const props = defineProps(["action", "user"]);
// const { isAppRtl } = useLayouts();
const isAppRtl = computed({
    get() {
      return config.app.isRtl.value
    },
    set(value: typeof config.app.isRtl.value) {
      config.app.isRtl.value = value
      localStorage.setItem(`${config.app.title}-isRtl`, value.toString())
      document.documentElement.setAttribute('dir', config.app.isRtl.value?'rtl':'ltr')
    },
  })
const clickEventHandler = () => {
  employeeDto.value = props.user;
  persmissionsIds.value = employeeDto.value.permissions;
  router.push(`myemployees/${props.user.id}`);
};
</script>
<template>
  <div @click="clickEventHandler" class="justify-start gap-5 flex items-center">
    <VCard
      class="shadow-md h-[80px] flex items-center px-5 min-w-[320px] lg:min-w-[460px]"
    >
      <div class="flex justify-between items-center w-full">
        <h3>{{ locale == "ar" ? user.name.ar : user.name.en }}</h3>

        <VBtn
          variant="text"
          color="on-surface"
          :icon="isAppRtl ? 'mdi-chevron-left' : 'mdi-chevron-right'"
        />
      </div>
    </VCard>
  </div>
</template>
