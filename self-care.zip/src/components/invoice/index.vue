<template>
  <div>Add invoice</div>
</template>
