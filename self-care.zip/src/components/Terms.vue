<script setup lang="ts">
import Terms from "@/assets/images/svg/terms.svg";
import { useAboutStore } from "@/stores/About";
const store = useAboutStore();
const { terms } = storeToRefs(store);
onMounted(() => {
  store.getTerms();
});
</script>
<template>
  <div class="flex gap-5 flex-col justify-center items-center lg:px-20">
    <img :src="Terms" alt="" />
    <p>
      {{ terms.title }}
    </p>

    <p>
      {{ terms.content }}
    </p>
  </div>
</template>
