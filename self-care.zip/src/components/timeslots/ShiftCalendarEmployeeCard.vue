<script setup lang="ts">
import { useTimeSlotsStore } from "@/stores/WorkingTimes";
import Switch from "@/components/shared/Switch.vue";
import { useI18n } from "vue-i18n";
const store = useTimeSlotsStore();
const isOpend = ref(false);
const { locale } = useI18n();
const props = defineProps(["item", "index"]);
// watch(props.item, () => {
//   store.employeeChangeStatus(props.item.id, props.index);
// });
</script>
<template>
  <VCard class="px-5 mt-5 min-h-[56px]">
    <div class="cursor-pointer flex justify-between items-center">
      <p class="flex justify-center items-center gap-2 mt-4 h-full">
        <span>{{ locale === "en" ? item.name.en : item.name.ar }}</span>
        <VBtn
          @click="isOpend = !isOpend"
          variant="text"
          v-if="item.is_active"
          :icon="isOpend ? 'mdi-chevron-up' : 'mdi-chevron-down'"
          color="gray-400"
        ></VBtn>
      </p>

      <Switch
        color="accent"
        v-model="item.is_active"
        @change="store.employeeChangeStatus(props.item.id, props.index)"
      />
    </div>
    <div v-if="isOpend && item.is_active">
      <div
        v-for="(i, ii) in item.shifts"
        :key="i.id"
        class="times-container flex justify-start flex-col"
      >
        <div class="flex w-fu justify-between items-center h-[56px]">
          <div class="flex justify-start items-center] gap-3">
            <img class="h-[20px]" :src="i.icon" alt="" /> <span>{{ i.title }}</span>

            <VChip variant="elevated" class="rounded-md" color="success">{{
              i.shift_from_time
            }}</VChip>
            <p>{{ locale === "en" ? i.service.title__ml.en : i.service.title__ml.ar }}</p>
          </div>

          <Switch
            :checked="i.shift_status === 1"
            @change="store.employeesTimeslotsChangeStatus(i.id, index, ii)"
            v-model="i.shift_status"
          />
        </div>
      </div>
    </div>
  </VCard>
</template>
