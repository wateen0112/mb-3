<script setup lang="ts">
import { ShiftCalendarServiceItemDto, TimeSlotServiceDto } from "@/api/workingTime/dto";
import Switch from "@/components/shared/Switch.vue";
import { useTimeSlotsStore } from "@/stores/WorkingTimes";
import { useI18n } from "vue-i18n";
const isOpend = ref(false);
const { locale } = useI18n();
const store = useTimeSlotsStore();
const props = defineProps(["item", "index"]);
const { loading } = storeToRefs(store);
</script>
<template>
  <VCard class="px-5 mt-5 min-h-[56px]">
    <div class="cursor-pointer flex justify-between items-center">
      <p class="flex justify-center items-center gap-2 mt-4 h-full">
        <span>{{ item.service.title__ml.en }}</span>
        <!-- {{ item }} -->
        <VBtn
          v-if="item.is_active"
          @click="isOpend = !isOpend"
          variant="text"
          :icon="isOpend ? 'mdi-chevron-up' : 'mdi-chevron-down'"
          color="gray-400"
        ></VBtn>
      </p>

      <Switch
      
        @change="store.serviceChangeStatus(item.service.id, index)"
        color="accent"
        v-model="item.is_active"
      />
    </div>

    <div v-if="isOpend && item.is_active">
      <div
        v-for="(i, ii) in item.service.timeslots"
        :key="i.id"
        class="times-container flex justify-start flex-col"
      >
        <div class="flex w-fu justify-between items-center h-[56px]">
          <VChip
            variant="elevated"
            class="rounded-md"
            :color="i.is_active ? 'success' : 'error'"
            ><span class="text-xl">{{ i.from_time }}</span>
          </VChip>

          <Switch
            color="accent"
            v-model="i.is_active"
            @click="store.timeslotsChangeStatus(i.id, index, ii)"
          />
        </div>
      </div>
    </div>
  </VCard>
</template>
