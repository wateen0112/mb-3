<script setup lang="ts">
import OrderCard from "./OrderCard.vue";
import { useOrderStore } from "@/stores/Order";
import Loading from "@/components/shared/Loading.vue";
import { useI18n } from "vue-i18n";
const props = defineProps(["title"]);
const store = useOrderStore();
const { t } = useI18n();
const { ordersList, isLoading, allPages, total, page } = storeToRefs(store);

//jst for testing  . . . .
const types = ["accepted", "running", "complited", "no-show", "gifts", "canceled"];
</script>
<template>
  <div class="orders-container min-h-[560px]">
    <div class="h-[600px] overflow-y-scroll">
      <h2 class="mt-2 lg:px-32">{{ $t(`myOrders.${title}`) }}</h2>
      <div v-if="isLoading">
        <Loading />
      </div>
      <div v-else>
        <div v-if="ordersList.length === 0">
          <h4 class="capitalize lg:px-32 mt-10 font-normal">
            {{ $t("myCalendar.noDataAvailable") }}
          </h4>
        </div>
        <div>
          <div
            class="grid grid-cols-1 lg:grid-cols-2 lg:gap-x-20 gap-y-8 w-full lg:px-32 py-5"
          >
            <OrderCard v-for="order in ordersList" :order="order" />
          </div>
        </div>
      </div>
    </div>
    <div class="mt-10" v-if="total > 15">
      <VPagination :length="allPages" :total-visible="6" v-model="page"> </VPagination>
    </div>
  </div>
</template>
<style>
.orders-container ::-webkit-scrollbar {
  display: none;
}
</style>
