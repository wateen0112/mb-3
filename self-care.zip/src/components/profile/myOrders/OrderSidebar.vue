<script setup lang="ts">
import ServiceOffer from "@/assets/images/svg/service-offer.svg";
import { useAppStore } from "@/stores/App";

import { useOrderStore } from "@/stores/Order";
import { useI18n } from "vue-i18n";
import { useServiceStore } from "@/stores/Service";
import { useLayouts } from "@core/composable/useLayout"
import { useDateTime } from "@/composables/useDateTime";
import { title } from "process";
import { useFile } from "@/composables";
import { MainServiceDto, Service } from "@/api/service/dto";
const { locale } = useI18n();
const appStore = useAppStore();
const { sidebarOpend } = storeToRefs(appStore);
const { isAppRtl } = useLayouts();
const { showDayName, getClock } = useDateTime();
const store = useOrderStore();
const { order, orderOldPrice, editMode, servicesToBeAdded, confirm } = storeToRefs(store);
const { getFileUrl } = useFile();

const offersList = [
  {
    title: "Percentage",
    value: "percentage",
    icon: "mdi-percent",
  },
  {
    title: "Amount",
    value: "amount",
    icon: "mdi-cash",
  },
];
const offerType = ref("percentage");
const props = defineProps({
  order: {
    type: String,
    default: "accepted",
  },
});
document.querySelector(".layout-overlay ")?.addEventListener("click", () => {
  sidebarOpend.value = false;
});
const deleteServiceFromServicesToBeAdded = (id: number) => {
  const price = parseInt(
    servicesToBeAdded.value.filter((service: MainServiceDto) => {
      return service.id === id;
    })[0].location[0].male_price ??
      servicesToBeAdded.value.filter((service: MainServiceDto) => {
        return service.id === id;
      })[0].location[0].fimale_price
  );
  order.value.total_price = order.value.total_price - price;
  servicesToBeAdded.value = servicesToBeAdded.value.filter((service: MainServiceDto) => {
    return service.id !== id;
  });
};
const cancelEvt = () => {
  if (editMode.value && servicesToBeAdded.value.length > 0) {
    confirm.value = true;

    appStore.openModal();
    editMode.value = false;
    appStore.closeSidebar();
  } else {
    appStore.closeSidebar();
  }
};
watch(store, () => {
  order.value.total_price = orderOldPrice.value;
  servicesToBeAdded.value.forEach((service: MainServiceDto) => {
    if (service.offer >= 0) {
      if (service.offer_type === "percentage") {
        const newCost = service.location[0].male_price * 0.01 * (100 - service.offer);
        order.value.total_price += newCost;

        console.log("new cost", order.value.total_price);
      } else if (service.offer_type === "amount") {
        const newCost = service.location[0].male_price - service.offer;
        if (newCost > 0) {
          order.value.total_price += newCost;
        }
      }
    }
  });
});
</script>
<template>
  <div class="flex justify-between flex-row items-center w-full z-50">
    <VBtn @click="cancelEvt()" variant="text">
      <VIcon v-if="!isAppRtl" size="40">mdi-chevron-left</VIcon>
      <VIcon v-else size="40">mdi-chevron-right</VIcon>
    </VBtn>
    <div class="flex flex-row justify-center items-center gap-2">
      <h2 class="text-primary">#{{ order.order_number }}</h2>
      <VBtn @click="editMode = true" variant="text" icon="tabler:edit" />
    </div>
  </div>
  <div
    class="lg:px-5 grid grid-cols-1 gap-4 mt-4"
    :class="!isAppRtl ? 'lg:pl-20' : 'lg:pr-20'"
  >
    <div
      class="flex justify-between items-center sidebar mb-4"
      :class="{ 'flex-row': locale === 'AR' }"
    >
      <h2>{{ order.customer_name }}</h2>
      <VChip
        variant="elevated"
        :rounded="false"
        v-if="order.order_status === 'accepted'"
        color="success"
        >{{ $t("myOrders.accepted") }}</VChip
      >
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'running'"
        color="info "
        >{{ $t("myOrders.running") }}</VChip
      >
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'complited'"
        color="warning"
        >{{ $t("myOrders.complited") }}</VChip
      >
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'no_show'"
        color="on-surface"
        >{{ $t("myOrders.no_show") }}</VChip
      >
      <VChip variant="elevated" v-else-if="order.order_status === 'gifts'" color="#c4f">{{
        $t("myOrders.gifts")
      }}</VChip>
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'canceled'"
        color="error "
        >{{ $t("myOrder.canceled") }}</VChip
      >
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-normal text-gray-400">{{ $t("myOrders.serviceLocation") }}</h3>
      <div class="flex gap-x-3">
        <VIcon
          color="primary"
          size="30"
          :icon="order.order_location === 'store' ? 'mdi-store' : 'mdi-home'"
        />
        <p class="text-on-surface">
          {{
            order.order_location === "store"
              ? $t("myOrders.atStore")
              : $t("myOrders.atHome")
          }}
        </p>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.date") }}</h3>
      <div>
        <p class="text-on-surface text-lg">{{ showDayName(order.created_at) }}</p>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.time") }}</h3>
      <div>
        <p class="text-on-surface text-lg">{{ getClock(order.created_at) }}</p>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.phone") }}</h3>
      <div>
        <p class="text-on-surface text-lg">{{ order.customer_mobile }}</p>
      </div>
    </div>

    <!--gifted person . . . -->
    <div v-if="order.is_gifted">
      <div class="flex justify-between flex-row mb-4 items-center">
        <h3 class="font-light text-gray-400">{{ $t("myOrders.giftedPerson") }}</h3>
        <div>
          <p class="text-on-surface text-lg">{{ order.gifted_person?.name }}</p>
        </div>
      </div>
      <div class="flex justify-between flex-row items-center">
        <h3 class="font-light text-gray-400">{{ $t("myOrders.phone") }}</h3>
        <div>
          <p class="text-on-surface text-lg">{{ order.gifted_person?.phone }}</p>
        </div>
      </div>
    </div>
    <!-- gifted person ends  .. . . -->
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.employee") }}</h3>
      <div>
        <p class="text-on-surface text-lg">
          {{
            locale === "en"
              ? order.services[0].related_employee.name__ml.en
              : order.services[0].related_employee.name__ml.ar
          }}
        </p>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.status") }}</h3>
      <div>
        <p class="text-on-surface text-lg">{{ order.order_status }}</p>
      </div>
    </div>
    <VDivider />
    <div class="grid grid-cols-1 px-3 gap-3">
      <p class="text-on-surface">{{ $t("myOrders.services") }}</p>
      <div v-for="service in order.services">
        <div class="flex flex-row gap-3" v-if="service.related_service !== null">
          <img
            class="w-[80px] h-[80px] object-cover rounded-lg shadow-lg"
            :src="getFileUrl(service.related_service?.image_path ?? '')"
            alt=""
          />
          <div class="flex justify-between flex-row w-full">
            <div class="flex flex-col justify-center gap-3">
              <p class="text-primary">
                {{
                  locale === "en"
                    ? service.related_service.title__ml.en
                    : service.related_service.title__ml.ar
                }}
              </p>
              <p>Employee : {{ service.related_employee }}</p>
            </div>
            <div class="flex flex-col justify-end pb-3">
              <p>{{ service.service_price }} {{ $t("myOrders.sar") }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="flex flex-col relative" v-for="service in servicesToBeAdded">
        <VBtn
          @click="deleteServiceFromServicesToBeAdded(service.id)"
          class="absolute right-[-20px]"
          variant="text"
          ><VIcon>mdi-close</VIcon></VBtn
        >
        <div class="flex flex-row gap-3">
          <img
            class="w-[80px] h-[80px] object-cover rounded-lg shadow-lg"
            :src="getFileUrl(service.image ?? '')"
            alt=""
          />
          <div class="flex justify-between flex-row w-full">
            <div class="flex flex-col justify-center gap-3">
              <p class="text-primary">
                {{ locale === "en" ? service.title.en : service.title.ar }}
              </p>
            </div>
            <div class="flex flex-col justify-end pb-3">
              <p>{{ service.location[0].male_price }} {{ $t("myOrders.sar") }}</p>
            </div>
          </div>
        </div>
        <div class="flex justify-between items-center">
          <!-- column 1 -->
          <div class="capitalize flex justify-center items-center gap-5">
            <div class="mt-8">
              <img class="w-[30px]" :src="ServiceOffer" alt="" />
            </div>
            <h3 class="mt-5">{{ $t("myOrders.discount") }}</h3>
          </div>
          <!-- column 2-->
          <div class="flex mt-5 flex-row justify-center items-center">
            <VTextField class="w-[40px]" v-model="service.offer" variant="underlined" />

            <VSelect
              value="percentage"
              :prepend-icon="
                service.offer_type === 'percentage' ? 'mdi-percent' : 'mdi-cash'
              "
              :items="offersList"
              item-title="title"
              item-value="value"
              v-model="service.offer_type"
              variant="text"
            />
          </div>
        </div>
      </div>

      <!-- edit order  .. add new service-->
      <div v-if="editMode" class="w-full flex justify-center items-center mt-5">
        <VBtn
          @click="
            () => {
              useServiceStore()
                .getServicesList()
                .then(() => {
                  editMode = true;
                  appStore.closeSidebar();
                  appStore.openModal();
                });
            }
          "
          width="200"
          class="capitalize"
          variant="outlined"
        >
          {{ $t("myOrders.addService") }}</VBtn
        >
      </div>

      <!-- edit edned-->
    </div>
    <VDivider />
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-on-surface text-xl mb-2">
        {{ $t("myOrders.paymentDetails") }}
      </h3>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.paymentPrice") }}</h3>
      <div><p class="text-on-surface text-lg">$120.00</p></div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-light text-gray-400">{{ $t("myOrders.paymentStatus") }}</h3>
      <div>
        <p class="text-on-surface text-lg">{{ order.payment_status }}</p>
      </div>
    </div>
    <div class="flex justify-between flex-row items-center">
      <h3 class="font-normal text-on-serface">To{{ $t("myOrders.totalAmount") }}</h3>
      <div>
        <p class="text-on-surface text-lg">{{ Math.ceil(order.total_price) }} SAR</p>
      </div>
    </div>

    <!-- if order type is running  , , , -->
    <div v-if="order.order_status === 'running'">
      <div class="flex justify-center mt-2 items-center">
        <VBtn
          class="capitalize"
          @click="
            store.confirmPayment(order.order_id).then(() => {
              appStore.closeSidebar();
            })
          "
          color="primary "
          width="300px"
        >
          {{ $t("myOrders.confirmPayment") }}</VBtn
        >
      </div>
      <div class="flex justify-center mt-2 items-center">
        <VBtn
          class="capitalize"
          @click="
            store.sendPaymentNotification(order.order_id).then(() => {
              appStore.closeSidebar();
            })
          "
          variant="outlined"
          color="primary "
          width="300px"
        >
          {{ $t("myOrders.sendPaymentNotification") }}</VBtn
        >
      </div>
      <div class="flex justify-center items-center">
        <VBtn
          class="capitalize"
          @click="
            () => {
              appStore.closeSidebar();
              appStore.openModal();
            }
          "
          variant="text"
          color="primary "
          width="300px"
        >
          no show</VBtn
        >
      </div>
    </div>
    <!-- if order type is running  , , , -->

    <!-- if the order status is runnnig and edit mode is activated-->
    <div class="flex justify-center mt-2 items-center">
      <VBtn
        class="capitalize"
        @click="
          () => {
            appStore.closeSidebar();
            store.updateOrder();
          }
        "
        color="primary "
        width="300px"
      >
        {{ $t("myOrders.sendToClient") }}</VBtn
      >
    </div>
    <div class="flex justify-center mt-2 items-center">
      <VBtn @click="cancelEvt()" variant="outlined" color="primary " width="300px">
        {{ $t("myOrders.cancel") }}</VBtn
      >
    </div>
  </div>
</template>
<style scoped>
.sidebar .v-chip {
  border-radius: 8px !important;
}
/* ===== Scrollbar CSS ===== */
/* Firefox */
.sidebar {
  scrollbar-width: auto;
  scrollbar-color: #ff9f43 #ffffff;
}

/* Chrome, Edge, and Safari */
.sidebar::-webkit-scrollbar {
  display: none;
}
</style>
