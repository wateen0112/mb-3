<script setup lang="ts">
import { useLayouts } from "@core/composable/useLayout"
import { useAppStore } from "@/stores/App";
import { useOrderStore } from "@/stores/Order";
import { useDateTime } from "@/composables/useDateTime";
import { OrderDto } from "@/api/order/dto";
import { useI18n } from "vue-i18n";
const appStore = useAppStore();
const { showDayName, getClock } = useDateTime();
const store = useOrderStore();
const { isAppRtl } = useLayouts();
const { t } = useI18n();
// we ,ust update data here when getting api

const props = defineProps({
  order: {
    type: OrderDto,
    default: new OrderDto(),
  },
});
const sideBarEvent = () => {
  store.getOrderById(props.order.order_id).then(() => {
    appStore.openSidebar();
  });
};
</script>
<template>
  <VCard
    class="capitalize rounded-2xl shadow-lg grid grid-cols-1 gap-2 p-5 py-2 min-h-[160px]"
  >
    <div class="flex justify-between items-center mt-1 order capitalize">
      <h2 class="font-extrabold">#{{ order.order_number }}</h2>
      <VChip
        variant="elevated"
        :rounded="false"
        v-if="order.order_status === 'accepted'"
        color="success"
        >{{ $t("myOrders.accepted") }}</VChip
      >
      <VChip variant="elevated" v-else-if="order.order_status === 'running'" color="info "
        >running</VChip
      >
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'complited'"
        color="primary"
        >{{ $t("myOrders.complited") }}</VChip
      >
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'no_show'"
        color="black"
        >{{ $t("myOrders.no_show") }}</VChip
      >
      <VChip variant="elevated" v-else-if="order.order_status === 'gifts'" color="#c4f">{{
        $t("myOrders.gifts")
      }}</VChip>
      <VChip
        variant="elevated"
        v-else-if="order.order_status === 'canceled'"
        color="error "
        >{{ $t("myOrders.canceled") }}</VChip
      >
    </div>
    <div class="flex justify-between flex-row items-center">
      <p>{{ order.customer_name }}</p>
      <VBtn
        @click="sideBarEvent()"
        variant="text"
        color="on-surface"
        :icon="isAppRtl ? 'mdi-chevron-left' : 'mdi-chevron-right'"
      />
    </div>
    <div class="grid grid-cols-3 gap-x-10">
      <div class="flex justify-center items-center flex-row gap-1">
        <VIcon color="primary" icon="tabler:calendar" />
        <span class="text-sm"> {{ showDayName(order.created_at.split("T")[0]) }}</span>
      </div>
      <div class="flex justify-center flex-row items-center gap-1">
        <VIcon color="primary" icon="tabler:clock" />
        <span class="text-sm"> {{ getClock(order.created_at) }}</span>
      </div>
      <div class="flex justify-center flex-row items-center gap-1">
        <VIcon color="primary" icon="tabler:map-pin" />
        <span class="text-sm"> {{ order.services[0].service_location }}</span>
      </div>
    </div>
  </VCard>
</template>
<style>
.order .v-chip {
  border-radius: 8px !important;
}
</style>
