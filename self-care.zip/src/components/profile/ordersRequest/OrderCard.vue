<script setup lang="ts">
import { useLayouts } from "@core/composable/useLayout"
import { OrderDto } from "@/api/order/dto";
import { useFile } from "@/composables";
import { useI18n } from "vue-i18n";

import { useOrderStore } from "@/stores/Order";
const store = useOrderStore();
const seconds = ref("00");
const { getFileUrl } = useFile();
const emit = defineEmits(["details"]);
const { t, locale } = useI18n();
const timer = ref(0);
const startTimer = (duration: number) => {
  timer.value = duration;

  setInterval(() => {
    if (--timer.value >= 0) {
      minutes.value = Math.floor(timer.value / 60)
        .toString()
        .padStart(2, "0");
      seconds.value = (timer.value % 60).toString().padStart(2, "0");
    }
  }, 1000);
};

const { isAppRtl } = useLayouts();
// we ,ust update data here when getting api

const props = defineProps({
  order: {
    type: OrderDto,
    default: {},
  },
});
const minutes = ref<number | string>(props.order.waiting_time);

onMounted(() => {
  // if (props.order.is_gifted) {
  //   startTimer(props.order.waiting_time * 60 ?? 300);
  // }
});
</script>
<template>
  <VCard
    @click="
      () => {
        store.getOrderById(order.order_id).then(() => {});
        $emit('details');
      }
    "
    class="rounded-2xl shadow-lg grid grid-cols-1 gap-2 p-5 py-2 min-h-[160px]"
  >
    <div class="flex justify-between items-center mt-1 order capitalize">
      <h2 class="font-extrabold">#{{ order.order_number }}</h2>

      <VChip variant="elevated" color="#c4f">gift</VChip>
    </div>
    <div class="flex justify-between flex-row items-center">
      <p>{{ order.customer_name }}</p>
      <VBtn
        @click="$emit('details', order.order_id)"
        variant="text"
        color="on-surface"
        :icon="isAppRtl ? 'mdi-chevron-left' : 'mdi-chevron-right'"
      />
    </div>
    <div class="flex justify-start items-center gap-x-10">
      <div class="flex justify-center flex-row gap-1">
        <VIcon class="mb-[10px]" color="primary" :icon="'mdi-gift'" />
      </div>

      <div class="flex justify-center flex-row gap-1" v-for="service in order.services">
        <img
          v-if="service.related_service !== null"
          class="w-[30px] h-[30px] object-cover rounded-lg shadow-lg"
          :src="getFileUrl(service.related_service.image_path ?? '')"
          alt=""
        />
        <p class="text-primary font-semibold" v-if="service.related_service !== null">
          {{
            locale === "ar"
              ? service.related_service.title__ml.ar
              : service.related_service.title__ml.en
          }}
        </p>
      </div>
      <div class="flex justify-center flex-row gap-1">
        <VIcon class="mb-[10px]" color="primary" :icon="'mdi-timer'" />
        <p class="text-primary" v-if="order.is_gifted">{{ minutes + ":" + seconds }}</p>
      </div>
    </div>
  </VCard>
</template>
<style>
.order .v-chip {
  border-radius: 8px !important;
}
</style>
