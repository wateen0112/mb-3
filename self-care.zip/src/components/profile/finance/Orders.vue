<script setup lang="ts">
import BtnTab from "@/components/shared/BtnTab.vue";
import OrdersByType from "@/components/profile/finance/OrdersByType.vue";
import { useI18n } from "vue-i18n";
import { useFinaceStore } from "@/stores/Finance";
const store = useFinaceStore();

// import CustomDatePicker from "@/components/shared/CustomDatePicker.vue";
const tab = ref("0");
const { t } = useI18n();

const props = defineProps({
  isCustom: {
    type: Boolean,
    default: false,
  },
  obj: {
    type: Object,
    default: {},
  },
});
</script>
<template>
  <div class="flex items-center justify-start flex-col w-full">
    <!-- tab btns  . .  .-->
    <div class="grid lg:grid-cols-3 grid-cols-1 gap-10">
      <div></div>
      <div class="flex w-full justify-center items-center gap-3">
        <BtnTab
          @click="
            store.getFinance({
              ...obj,
              payment: 'cash',
            })
          "
          v-model="tab"
          value="0"
          :content="$t('finance.all')"
        />
        <BtnTab
          @click="
            store.getFinance({
              ...obj,
            })
          "
          v-model="tab"
          value="1"
          :content="$t('finance.cash')"
        />
        <BtnTab
          @click="
            store.getFinance({
              ...obj,
              payment: 'online',
            })
          "
          v-model="tab"
          value="2"
          :content="$t('finance.online')"
        />
      </div>
      <div>
        <div v-if="isCustom"></div>
      </div>
    </div>
    <!--window items-->
    <div class="w-full">
      <VWindow v-model="tab" class="w-full">
        <VWindowItem value="0"><OrdersByType /></VWindowItem>
        <VWindowItem value="1"><OrdersByType /></VWindowItem>
        <VWindowItem value="2"><OrdersByType /></VWindowItem>
      </VWindow>
    </div>
  </div>
</template>
