<script setup lang="ts">
import { useI18n } from "vue-i18n";
import Order from "./Order.vue";
import { useFinaceStore } from "@/stores/Finance";
const store = useFinaceStore();
const { finance, isLoading } = storeToRefs(store);
const { t } = useI18n();
</script>
<template>
  <div class="pt-8 w-full capitalize">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-x-10">
      <div class="lg:col-span-2" v-if="isLoading">
        {{ $t("workingTimes.loading") }}
      </div>
      <div class="lg:col-span-2" v-else>
        <div v-if="finance.orders.length === 0">
          <p>{{ $t("myCalendar.noDataAvailable") }}</p>
        </div>
        <div v-else class="col-span-2 grid grid-cols-1 lg:grid-cols-2 gap-y-4 gap-x-10">
          <Order v-for="order in finance.orders" :order="order" />
        </div>
      </div>

      <div class="border-left flex justify-end gap-10 pl-10 pt-3">
        <div class="flex flex-col justify-start items-center w-full gap-4">
          <div class="flex justify-between items-center w-full">
            <p class="">{{ $t("finance.totalAmount") }}</p>
            <h3>{{ finance.total + $t("myOrders.sar") }}</h3>
          </div>
          <div class="flex justify-between items-center w-full">
            <p class="">{{ $t("finance.vat") }}</p>
            <h3>{{ finance.vat + $t("myOrders.sar") }}</h3>
          </div>
          <div class="flex justify-between items-center w-full">
            <p class="">{{ $t("finance.scCut") }}</p>
            <h3>{{ finance.selfcare_cut + $t("myOrders.sar") }}</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.border-left {
  border-left: 1px solid #ccc;
}
</style>
