<script setup lang="ts">
import { OrderDto } from "@/api/order/dto";
import { useDateTime } from "@/composables/useDateTime";
import { useAppStore } from "@/stores/App";
import { useI18n } from "vue-i18n";
const { t, locale } = useI18n();
const appStore = useAppStore();
const { showDayName } = useDateTime();
const props = defineProps({
  order: {
    type: OrderDto,
    default: new OrderDto(),
  },
});
</script>
<template>
  <VCard class="px-3 cursor-pointer py-2 h-[120px] flex flex-col gap-0 relative">
    <div
      class="absolute top-0 px-4 py-1 bg-primary text-white font-semibold rounded-bl-xl opacity-70"
    >
      {{ $t("finance.walkIn") }}
    </div>

    <p>
      {{
        locale === "en"
          ? order.services[0].related_service.title__ml.en
          : order.services[0].related_service.title__ml.ar
      }}
    </p>
    <div class="flex justify-between flex-row items-center">
      <p>
        <span
          ><VIcon color="primary" icon="mdi-calendar" />{{
            showDayName(order.created_at)
          }}</span
        >
      </p>
      <h2>{{ order.total_price }}</h2>
    </div>
    <p>
      <span><VIcon color="primary" icon="mdi-compass" /></span>
      {{ $t(`orders.${order.order_status}`) }}
    </p>
  </VCard>
</template>
