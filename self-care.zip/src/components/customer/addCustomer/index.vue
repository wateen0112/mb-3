<script setup lang="ts">
import { useI18n } from 'vue-i18n';
import {useCustomersStore} from '@/stores/Customer'

import * as yup from 'yup';
import FileUploader from '@/components/shared/FileUploader.vue';
import {Field, Form , ErrorMessage} from 'vee-validate';
import{storeSetting} from '@/stores/Setting'

const settingStore = storeSetting();
const {countries} = storeToRefs(settingStore);

const emit = defineEmits(['dialog'])
const store = useCustomersStore();
const {companyCustomer,privateCustomer,error} = storeToRefs(store)
const {t}= useI18n()
const loading = ref(false )
const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
const privateForm = ref<InstanceType<typeof Form> | null>(null);
const companyForm = ref<InstanceType<typeof Form> | null>(null);



const privateSchema = computed(()=>{
  return yup.object({
    fname:yup.string().required(t('customers.required.firstName')),
    lname:yup.string().required(t('customers.required.lastName')),
    email:yup.string().email(t('customers.required.invalidEmail')).required(t('customers.required.email')),
    phone:yup.string().matches(phoneRegExp,t('customers.required.invalidPhone')).required(t('customers.required.phone')),
    imageFile:yup.string().required(t('customers.required.file')),
    password:yup.string().required(t('customers.required.password')).min(4,t('customers.minPasswordLength')).max(14,t('customers.maxPasswordLength')),
    coc:yup.string().required(t('customers.required.coc')),
    vat:yup.string().required(t('customers.required.vat')),
    iban:yup.string().required(t('customers.required.iban')),
  
  })
})
const compnySchama = computed(()=>{
  return yup.object({
    name:yup.string().required(t('customers.required.companyName')),
    postalCode:yup.string().required(t('customers.required.postalCode')),
    street:yup.string().required(t('customers.required.street')),
    country:yup.string().required(t('singup.required.country')),
    locality:yup.string().required(t('customers.required.locality')),
    phone:yup.string().matches(phoneRegExp,t('customers.required.invalidePhone')).required(t('customers.required.phone')),
    fname:yup.string().required(t('customers.required.firstName')),
    lname:yup.string().required(t('customers.required.lastName')),
    email:yup.string().email(t('customers.required.invalidEmail')).required(t('customers.required.email')),
    password:yup.string().required(t('customers.required.password')).min(4,t('customers.minPasswordLength')).max(14,t('customers.maxPasswordLength')),
    coc:yup.string().required(t('customers.required.coc')),
    vat:yup.string().required(t('customers.required.vat')),
    iban:yup.string().required(t('customers.required.iban')),
  })
})

const props = defineProps({
  dialogType:{
    type:Number,
    default:1
  },

})

onMounted(()=>{
  settingStore.GetAllCountry();
})
function submitPrivate  (){
  privateForm.value?.validate().then((valid:any)=>{
    if (valid.valid){
      loading.value=true
      store.addPrivate().then(()=>{
      
        if(!error.value){
        emit('dialog')
      }
      }).catch(()=>{
        error.value = true
      })
    
    }
  })
}
function submitCompany  (){
  companyForm.value?.validate().then((valid:any)=>{
    if (valid.valid){
      loading.value=true
      store.addCompany().then(()=>{
   
       if(!error.value)
       {
        emit('dialog')
       }
      })
           loading.value = false;
    }
  })
}
</script>
<template>
<div class="lg:px-6">
<p class="font-semibold">{{$t('customers.enterData')}}</p>
  <!-- private or person dialog-->
  <div v-if="dialogType==1">
    <!-- main content form-->
    <Form ref="privateForm" class="pb-5 lg:grid lg:grid-cols-2  flex flex-col flex-nowrap  grid-cols-1 w-full gap-3" :validation-schema="privateSchema">
<!-- column1 -->
<div  class="flex flex-col gap-3  mb-5 ">    

              
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-3  lg:gap-10">
    <div> 
      <Field name="fname" v-slot="{field}"   >
      <div>
        <VTextField v-model="privateCustomer.firstName" v-bind="field"   prepend-inner-icon="mdi-account" :label="$t('customers.firstName')" variant="outlined"></VTextField>
      <ErrorMessage  class="text-red-600 text-xs"  name="fname" v-slot="{message}"></ErrorMessage>
      </div>
      
      </Field>
      
          </div>
          <div> 
            <Field  v-model="privateCustomer.lastName"  name="lname" v-slot="{field}">
              <div>
            <VTextField   v-bind="field"   prepend-inner-icon="mdi-account" :label="$t('customers.lastName')" variant="outlined"></VTextField>
          
            <ErrorMessage  class="text-red-600 text-xs"  name="lname" v-slot="{message}"></ErrorMessage>
          </div>  
          </Field>
      
          
          </div>
        
  </div>
  <div >
    <Field name="password" v-slot="{field}">
      <div>
    
    <VTextField  v-model="privateCustomer.password" v-bind="field"   type="password"  prepend-inner-icon="mdi-lock" :label="$t('customers.password')" variant="outlined"></VTextField>
  
      
    <ErrorMessage  class="text-red-600 text-xs"  name="password" v-slot="{message}"></ErrorMessage>
  </div>  
  
  </Field>

  
  </div>
  <div >
    <Field name="imageFile" v-slot="{field}" v-model="privateCustomer.ImageFile" >
      <div>
    
    <FileUploader  type="file" v-bind="field"  prepend-icon="" v-model="privateCustomer.ImageFile"   prepend-inner-icon="mdi-link" :label="$t('customers.imageFile')" variant="outlined"></FileUploader>
  
      
    <ErrorMessage  class="text-red-600 text-xs"  name="password" v-slot="{message}"></ErrorMessage>
  </div>  
  
  </Field>

  
  </div>
  <VCardTitle class="text-xl  text-center text-[#14AD98]">{{$t('customers.paymentInformation')}}</VCardTitle>
      
  <div > 
    
    <Field name="iban" v-slot="{field}">
      <div>
    <VTextField v-model="privateCustomer.iban"   v-bind="field"  :label="$t('customers.iban')" variant="outlined"></VTextField>
  
      
    <ErrorMessage  class="text-red-600 text-xs"  name="iban" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>

  </div>

            
     
     
    </div>

     <!-- column2 -->
     <div  class="grid grid-cols-1   gap-3 ">
      <div >
        <Field name="email" v-slot="{field}">
          <div> 
         <VTextField  v-model="privateCustomer.email" v-bind="field" prepend-inner-icon="mdi-email" :label="$t('customers.email')" variant="outlined"></VTextField>
            
         <ErrorMessage  class="text-red-600 text-xs"  name="email" v-slot="{message}"></ErrorMessage>
        </div>  
        </Field>
    
        
        </div>
        <div >
          <Field name="phone" v-slot="{field}">
            <div> 
           <VTextField   v-model="privateCustomer.phoneNumber" v-bind="field" prepend-inner-icon="mdi-phone" :label="$t('customers.phoneNumber')" variant="outlined"></VTextField>
              
           <ErrorMessage  class="text-red-600 text-xs"  name="email" v-slot="{message}"></ErrorMessage>
          </div>  
          </Field>
      
          
          </div>
    
          <VCardTitle class="text-xl  text-center text-[#14AD98]">{{$t('customers.personalInformation')}}</VCardTitle>
          <div >
            
            
            <Field name="coc" v-slot="{field}">
              <div>
            <VTextField v-model="privateCustomer.coc"   v-bind="field"  :label="$t('customers.cocNumber')" variant="outlined"></VTextField>
              
            <ErrorMessage  class="text-red-600 text-xs"  name="coc" v-slot="{message}"></ErrorMessage>
          </div>  
          </Field>
        
          </div>
          <div >
            
            <Field name="vat" v-slot="{field}">
              <div>
            <VTextField  v-bind="field"  v-model="privateCustomer.vat"  :label="$t('customers.vatNumber')" variant="outlined"></VTextField>
              
            <ErrorMessage  class="text-red-600 text-xs"  name="vat" v-slot="{message}"></ErrorMessage>
          </div>  
          </Field>
        
          </div>
</div>
<div class=" col-span-2 gap-5 flex w-full sticky bottom-0  justify-center mt-5"> <VBtn  class="w-[100px] lg:w-[160px]"  color="primary"  @click="submitPrivate()"><span class="text-xl capitalize">{{$t('customers.add')}}</span></VBtn>

  <VBtn @click="$emit('dialog')" class="w-[100px] lg:w-[160px]"  color="#14AD98"><span class="text-xl text-white capitalize">{{$t('contactUs.dialog.cancel')}}</span></VBtn>
</div>
    </Form>
</div>
<!-- company dialog -->
<div v-else-if="dialogType===2">
  <Form  ref="companyForm"  class="lg:grid  flex flex-col flex-nowrap   lg:grid-cols-2 grid-cols-1 w-full gap-8"  :validation-schema="compnySchama" >
<!--col 1-->
<div class="flex flex-col gap-5">
  <div  class="w-full">
      
    <Field name="name" v-slot="{field}">
      <div>
    <VTextField v-model="companyCustomer.name"  v-bind="field" :label="$t('customers.companyName')" variant="outlined"></VTextField>
   
    <ErrorMessage  class="text-red-600 text-xs"  name="name" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>

  </div>
   <div  class="w-full"> 
    
    <Field name="postalCode" v-slot="{field}">
      <div>
    <VTextField   v-model="companyCustomer.postalCode"  v-bind="field" :label="$t('customers.postalCode')" variant="outlined"></VTextField>
    <ErrorMessage  class="text-red-600 text-xs"  name="postalCode" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>
  </div>
   <div  class="w-full">
    
    
    <Field name="street" v-slot="{field}">
      <div>
    <VTextField v-bind="field"  v-model="companyCustomer.street" :label="$t('customers.street')" variant="outlined"></VTextField>
    <ErrorMessage  class="text-red-600 text-xs"  name="street" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>
  </div>
   <div  class="w-full">
    <Field name="country" v-slot="{field}"  >
      <div>
    <VSelect  v-bind="field"  v-model="companyCustomer.countryId" :items="countries" item-title="name" item-value="id" :label="$t('customers.country')" variant="outlined"></VSelect>
  
    <ErrorMessage  class="text-red-600 text-xs"  name="country" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>
  </div>
   <div  class="w-full"> 
    
    <Field name="locality" v-slot="{field}">
      <div>
    <VTextField  v-model="companyCustomer.locality" v-bind="field"  :label="$t('customers.locality')" variant="outlined"></VTextField>
    <ErrorMessage  class="text-red-600 text-xs"  name="locality" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>
  </div>
   <div  class="w-full"> 
    <Field name="phone" v-slot="{field}">
      <div>
    <VTextField v-bind="field"   v-model="companyCustomer.phoneNumber" type="number" :label="$t('customers.companyPhoneNumber')" variant="outlined"></VTextField>
    <ErrorMessage  class="text-red-600 text-xs"  name="phone" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>
  </div>
  <div  class="w-full"> 
    <Field name="imageFile" v-slot="{field}">
      <div>
    <FileUploader v-bind="field"   v-model="companyCustomer.ImageFile" :label="$t('customers.imageFile')" variant="outlined"></FileUploader>
    <ErrorMessage  class="text-red-600 text-xs"  name="phone" v-slot="{message}"></ErrorMessage>
  </div>  
  </Field>
  </div>
  <VCardTitle  class="text-xl  text-center text-[#14AD98]">{{$t('customers.paymentInformation')}}</VCardTitle>
    
  <div  class="w-full">  
   <Field name="iban" v-slot="{field}">
     <div>
   <VTextField  v-model="companyCustomer.iban" v-bind="field"  :label="$t('customers.iban')" variant="outlined"></VTextField>
 
   <ErrorMessage  class="text-red-600 text-xs"  name="iban" v-slot="{message}"></ErrorMessage>
 </div>  
 </Field>
 </div>
</div>
<!--col 2-->
   <div class="flex flex-col flex-nowrap gap-5">
    <div  class="grid grid-cols-2 gap-5  w-full">
      
      <div>  <Field name="fname" v-slot="{field}">
       <div> <VTextField   v-model="companyCustomer.firstName" v-bind="field"  prepend-inner-icon="mdi-account" :label="$t('customers.firstName')" variant="outlined"></VTextField>
         <ErrorMessage  class="text-red-600 text-xs"  name="fname" v-slot="{message}"></ErrorMessage>
       </div>  
       </Field>
       </div>
      <div>    <Field name="lname" v-slot="{field}">
       <div><VTextField   v-model="companyCustomer.lastName" v-bind="field"  prepend-inner-icon="mdi-account" :label="$t('customers.lastName')" variant="outlined"></VTextField>
         <ErrorMessage  class="text-red-600 text-xs"  name="lname" v-slot="{message}"></ErrorMessage>
       </div>  
       </Field>
       </div>
    </div>
    <div  class="w-full">  <Field name="email" v-slot="{field}">
     <div>  <VTextField v-bind="field"  v-model="companyCustomer.email"  prepend-inner-icon="mdi-email" :label="$t('customers.email')" variant="outlined"></VTextField>
     
       <ErrorMessage  class="text-red-600 text-xs"  name="email" v-slot="{message}"></ErrorMessage>
     </div>  
     </Field>
     </div>
    <div  class="w-full">  
     
     <Field name="password" v-slot="{field}">
       <div>
     <VTextField  v-model="companyCustomer.password" v-bind="field"  type="password"  prepend-inner-icon="mdi-lock" :label="$t('customers.password')" variant="outlined"></VTextField>
   
     <ErrorMessage  class="text-red-600 text-xs"  name="password" v-slot="{message}"></ErrorMessage>
   </div>  
   </Field>
   </div>
     <VCardTitle  class="text-xl  text-center text-[#14AD98]">{{$t('customers.personalInformation')}}</VCardTitle>
    <div  class="w-full"> 
     
     
     <Field name="coc" v-slot="{field}">
       <div>
     <VTextField v-bind="field"  v-model="companyCustomer.coc" :label="$t('customers.cocNumber')" variant="outlined"></VTextField>
     <ErrorMessage  class="text-red-600 text-xs"  name="coc" v-slot="{message}"></ErrorMessage>
   </div>  
   </Field>
   </div>
    <div  class="w-full"> 
     
     <Field name="vat" v-slot="{field}">
       <div>
     <VTextField    v-model="companyCustomer.vat" v-bind="field"  :label="$t('customers.vatNumber')" variant="outlined"></VTextField>
   
     <ErrorMessage  class="text-red-600 text-xs"  name="vat" v-slot="{message}"></ErrorMessage>
   </div>  
   </Field>
   </div>
  
 
 
  
  </div>
  <div class=" col-span-2 gap-5 flex w-full sticky bottom-0  justify-center mt-5"> <VBtn :loading="loading"  class="w-[100px] lg:w-[160px]"   @click="submitCompany" color="primary"><span class="text-xl capitalize">{{$t('customers.add')}}</span></VBtn>

    <VBtn @click="$emit('dialog')"  class="w-[100px] lg:w-[160px]"  color="#14AD98"><span class="text-xl text-white capitalize">{{$t('contactUs.dialog.cancel')}}</span></VBtn>
  </div>
</Form>
</div>
</div>
</template>
