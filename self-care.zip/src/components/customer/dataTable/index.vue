<script setup lang="ts">
import { FilterDto } from '@/api/Customer/CustomerDto';
import  {useCustomersStore} from '@/stores/Customer'
import { filter } from '@ucast/mongo2js';
import { useI18n } from 'vue-i18n';
const {t,locale} =useI18n()
const router  = useRouter()
const store = useCustomersStore();
const {isPrivate,pagination,privateList,filters,companyList} = storeToRefs(store);

//headers . . . .. . 
const headers = ref([t('customers.customerName'),t('customers.phoneNumber'),


t('customers.ordersCount')
,
t('customers.lastOrderDate'),t('customers.lastOrderStatus'),t('customers.customerDetails')]
)
const emit = defineEmits (['dialog'])
//onMounted... 
onMounted(()=>{
  filters.value = new FilterDto()
if(props.tableType===1){

  store.getAllPrivate()
}
else  if  (props.tableType===2){
  store.getAllCompany()
}
})
watch(filters, ()=>{
  if(props.tableType===1){
  store.getAllPrivate()
}
else  if  (props.tableType===2){
  store.getAllCompany()
}
})
//we will get data based on table type
//functions  . .. 
const getDetalis =  (id:string)=>{

emit('dialog')

}

const props = defineProps({
  tableType:{
    type:Number,
    default:1
  }
})
function tableEvent(id:string){
isPrivate.value = props.tableType===1
localStorage.setItem('isPrivate',isPrivate.value)
router.push(`customer/${id}`)

}
const idsToBeDeleted = ref<string[]>([])
function addItemToDelete(id:string|never){
  let arr = idsToBeDeleted.value.filter((item:any)=>
 {

  
  return item ==id}
  )
  if(arr.length>0){
    idsToBeDeleted.value= idsToBeDeleted.value.filter((item:any)=>
 item!=id
  )
  }
  else {
    idsToBeDeleted.value =[...idsToBeDeleted.value ,id ]
  }

  
}
function unselectCheckBoxs (){
  const checkBoxs = document.querySelectorAll('input[type="checkbox"]');
console.log(checkBoxs);
checkBoxs.forEach((check:any)=>{
if(check.checked){  
  check.click()
}
})
}
function deleteMultiItems(){
if(idsToBeDeleted.value.length>0){
  store.deleteCustomers(idsToBeDeleted.value).then(()=>{
    unselectCheckBoxs()
  })
}
}
//wtching locale to change header content based on selected language . .  
watch(locale,()=>{
  headers .value= [t('customers.customerName'),t('customers.phoneNumber'),
t('customers.ordersCount')
,
t('customers.lastOrderDate'),t('customers.lastOrderStatus'),t('customers.details')]

})
watch(filters, ()=>{
  if(props.tableType===1){
    store.getAllPrivate()
  }
  else{
    store.getAllCompany()
  }
})
</script>
<template>
  <div>
   <div >
    <VTable>
      <thead>
        <tr>

          <th class="max-w-[40px]"><VBtn   @click="deleteMultiItems" variant="text"><VIcon size="24" color="error">mdi-delete</VIcon></VBtn></th>
          <th  class="capitalize text-center" v-for="(header, index) in headers">{{header}}</th>
        </tr>
     
      </thead>
      <tbody>
        <tr v-if="tableType===1" v-for="(item , index) in privateList.customers">
          <td><VCheckbox @change="addItemToDelete(item.id)"></VCheckbox></td>
          <td class="text-center">{{item.fullName}}</td>
          <td class="text-center">{{item.phoneNumber}}</td>
         
          <td class="text-center">{{item.ordersCount}}</td>
          <td class="text-center">
         
            {{item.lastOrder?.dateCreated.split('T')[0]??'-'}}</td>
          
          <td class="text-center">
          <VChip v-if="item.lastOrder?.orderStage ==='UnHandled'" color="info">  {{ $t('customers.notDealed')}}</VChip>
          <VChip  v-else-if="item.lastOrder?.orderStage.includes('Canceld')" color="error">  {{ $t('customers.canceled')}}</VChip>
          <VChip  v-else-if="item.lastOrder?.orderStage ==='AcceptedByDriver'"  color="warning">  {{ $t('customers.acceptedByDriver')}}</VChip>
          <VChip v-else-if="item.lastOrder?.orderStage ==='Delivered'" color="success">  {{ $t('customers.delivered')}}</VChip>
          <VChip v-else-if="item.lastOrder?.orderStage ==='PickedUp'" color="primary">  {{ $t('customers.onWay')}}</VChip>
          <VChip v-else-if="item.lastOrder?.orderStage ==='WatingDriver'" color="">  {{ $t('customers.waitDriver')}}</VChip>
        
          <VChip v-else color=""> -</VChip>
           
          </td>
          

          
    <td class="text-center"><VBtn icon="tabler:dots-vertical" size="40" @click="tableEvent(item.id)"></VBtn></td>

    
        </tr>
        <tr  v-if="tableType===2" v-for="(item , index) in companyList.customers">
          <td><VCheckbox @change="addItemToDelete(item.id)"></VCheckbox></td>
          <td class="text-center">{{item.companyName}}</td>
          <td class="text-center">{{item.phoneNumber}}</td>
          <td class="text-center">{{item.ordersCount}}</td>
          <td class="text-center">
         
            {{item.lastOrder?.dateCreated.split('T')[0]??'-'}}</td>
          
          <td class="text-center">
                   
            <td class="text-center">
              <VChip v-if="item.lastOrder?.orderStage ==='UnHandled'" color="info">  {{ $t('customers.notDealed')}}</VChip>
              <VChip  v-else-if="item.lastOrder?.orderStage.includes('Canceld')" color="error">  {{ $t('customers.canceled')}}</VChip>
              <VChip  v-else-if="item.lastOrder?.orderStage ==='AcceptedByDriver'"  color="warning">  {{ $t('customers.acceptedByDriver')}}</VChip>
              <VChip v-else-if="item.lastOrder?.orderStage ==='Delivered'" color="success">  {{ $t('customers.delivered')}}</VChip>
              <VChip v-else-if="item.lastOrder?.orderStage ==='PickedUp'" color="primary">  {{ $t('customers.onWay')}}</VChip>
              <VChip v-else-if="item.lastOrder?.orderStage ==='WatingDriver'" color="">  {{ $t('customers.waitDriver')}}</VChip>
            
              <VChip v-else color=""> -</VChip>
               
              </td>
          </td>
          
        
          
    <td class="text-center"><VBtn icon="tabler:dots-vertical" size="40"  @click="tableEvent(item.id )"></VBtn></td>

    
        </tr>
      </tbody>
     </VTable>
     <div class="mt-10">
      <VPagination
      :total-visible="10"
      v-model="filters.pageIndex"
      :length="pagination.totalPages"
      @update:model-value="tableType===1?store.getAllPrivate():store.getAllCompany()"
     
  
      />
    </div>
   </div>
  
  </div>
</template>

