<script setup lang="ts">
import Pravicy from "@/assets/images/svg/pravicy.svg";
import { useAboutStore } from "@/stores/About";
const store = useAboutStore();
const { pravicy } = storeToRefs(store);
onMounted(() => {
  store.getPravicy();
});
</script>
<template>
  <div class="flex gap-5 flex-col justify-center items-center lg:px-20">
    <img :src="Pravicy" alt="" class="mt-5" />
    <p>
      {{ pravicy.title }}
    </p>

    <p>
      {{ pravicy.content }}
    </p>
  </div>
</template>
