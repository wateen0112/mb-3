<template>
    <svg fill="#ffffff" width="25" height="25" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path
            d="M3,20V12a1,1,0,0,1,2,0v5.585L17.586,5H12a1,1,0,0,1,0-2h8a1,1,0,0,1,1,1v8a1,1,0,0,1-2,0V6.414L6.414,19H12a1,1,0,0,1,0,2H4A1,1,0,0,1,3,20Z" />
    </svg>
</template>