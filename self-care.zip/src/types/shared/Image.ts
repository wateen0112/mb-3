export interface Image {
  defaultFile: File | null
  otherFiles: (File | null)[]
}
