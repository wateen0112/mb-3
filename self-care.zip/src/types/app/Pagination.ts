export interface Pagination {
  pageSize: number
  pageIndex: number
  totalPages?: number
  totalCount?: number

}
