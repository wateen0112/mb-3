<script setup lang="ts">
import Loading from "@/components/shared/Loading.vue";
import Page from "@/components/Page.vue";
import ServiceCard from "@/components/myServices/ServiceCard.vue";
import Service from "@/assets/images/svg/service.svg";
import { useServiceStore } from "@/stores/Service";
import { useAppStore } from "@/stores/App";
import { useScreen } from "@/composables/useScreen";
import { useI18n } from "vue-i18n";
const appStore = useAppStore();
const { screenSize } = useScreen();
const { t } = useI18n();
const store = useServiceStore();
const { servicesList, total, page, AllPages, perPage, isLoading } = storeToRefs(store);
const noServices = ref(false);
const deleteMode = ref(false);
const serviceToBeDeleted = ref(0);
onMounted(() => {
  store.getServicesList();
});
</script>
<template>
  <Page>
    <template #action-button v-if="!noServices && !deleteMode">
      <RouterLink v-if="screenSize === 'sm'" to="myservices/new">
        <VBtn variant="text" :disable="deleteMode" class="capitalize" height="46"> </VBtn>
        <VIcon size="30">mdi-plus</VIcon></RouterLink
      >
      <RouterLink v-else to="myservices/new">
        <VBtn :disable="deleteMode" class="capitalize" height="46">
          {{ $t("myServices.addService") }}
        </VBtn></RouterLink
      >
    </template>
    <template #modal>
      <div class="max-w-[340px]">
        <p class="my-5 mb-10 text-xl text-center text-black">
          {{ $t("myServices.confirmDelete") }}
        </p>
        <div class="p-5 flex justify-center items-center flex-col gap-3">
          <VBtn
            @click="
              () => {
                store.deleteService(serviceToBeDeleted);
                appStore.closeModal();
                deleteMode = false;
              }
            "
            width="320"
            height="46"
          >
            {{ $t("myServices.delete") }}
          </VBtn>
          <VBtn width="320" height="46" variant="outlined">
            {{ $t("myServices.cancel") }}
          </VBtn>
        </div>
      </div>
    </template>
    <template #body>
      <div
        class="capitalize lg:px-20 pt-20 min-h-[500px] gap-10 w-full h-full flex flex-col justify-start items-center"
      >
        <div v-if="servicesList.length === 0 && !Loading">
          <p class="font-normal text-[24px] lg:text-[28px]">
            {{ $t("myServices.addFirstSerice") }}
          </p>

          <div class="overflow-hidden w-auto min-w-[360px]">
            <img :src="Service" alt="" />
          </div>
          <div class="flex justify-center items-center">
            <router-link to="myServices/new">
              <VBtn class="capitalize lg:px-14 mt-4" height="50">
                {{ $t("myServices.addService") }}
              </VBtn></router-link
            >
          </div>
        </div>
        <div v-else class="grid grid-cols-1 lg:grid-cols-3 lg:pt-10">
          <div v-if="isLoading">
            <Loading />
          </div>
          <div
            v-else
            class="lg:col-span-2 col-span-1 lg:gap-x-20 gap-y-5 grid grid-cols-1 lg:grid-cols-2"
          >
            <div
              class="flex justify-between items-center gap-2"
              v-for="service in servicesList"
            >
              <VCheckbox
                v-model="serviceToBeDeleted"
                v-if="deleteMode"
                :value="service.id"
                :multiple="false"
                class="mt-5 mr-10"
              />
              <ServiceCard :service="service" />
            </div>
          </div>
          <div class="pt-5 fixed bottom-5 left-0 w-full flex justify-center items-center">
            <VPagination
              v-if="total > perPage"
              v-model="page"
              :total-visible="15"
              :length="AllPages"
            />
          </div>
        </div>
        <div
          v-if="deleteMode"
          @click="
            () => {
              if (servicesList.length > 0) {
                appStore.openModal();
              }
            }
          "
          class="flex justify-center items-center"
        >
          <VBtn class="capitalize lg:px-14 mt-4" height="50">
            {{ $t("myServices.confirm") }}
          </VBtn>
        </div>
        <div class="w-full flex justify-end absolute bottom-5 items-center">
          <VBtn
            @click="deleteMode = !deleteMode"
            class="capitalize font-semibold"
            color="error"
            variant="text"
          >
            {{ deleteMode ? "Cancel" : " delete services" }}
          </VBtn>
        </div>
        <!-- final div-->
      </div>
    </template>
  </Page>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
