<script setup lang="ts">
import Page from "@/components/Page.vue";
import Salon from "@/assets/images/svg/salon-active.svg";
import Offer from "@/assets/images/svg/offer.svg";
import { useServiceStore } from "@/stores/Service";
import FileBtn from "@/components/shared/FileBtn.vue";
import { useI18n } from "vue-i18n";
import { requiredValidator } from "@validators";

import { useStoresStore } from "@/stores/Store";
import { useFile } from "@/composables";
const { getFileUrl } = useFile();
const myForm = ref(null);
const store = useServiceStore();
const availableServices = ref<number[]>([]);
const { categoriesList } = storeToRefs(useStoresStore());
const route = useRoute();
const editImage = ref(false);
const id = route.params["id"];
const { serviceDto } = storeToRefs(store);

const { t, locale } = useI18n();
const errors = ref<Record<string, string | undefined>>({
  title__en: undefined,
  title__ar: undefined,
  description__en: undefined,
  description__ar: undefined,
  m_duration: undefined,
  home_male_price: undefined,
  home_female_price: undefined,
  stpre_male_price: undefined,
  stpre_female_price: undefined,
});
function previewProfileImage(event: any, id: string) {
  const input = event.target;

  if (input.files && input.files[0]) {
    const reader = new FileReader();

    reader.onload = function (e) {
      const previewImg = document.getElementById(id) as HTMLImageElement;
      if (previewImg && e.target?.result) {
        previewImg.style.display = "block";
        previewImg.src = e.target.result.toString();
        editImage.value = true;
      }
    };

    reader.readAsDataURL(input.files[0]);
  }
}
const checkItemIsFound = (item: number) =>
  serviceDto.value.categories_ids.filter((i) => i == item).length > 0;

const addItem = (item: number) => {
  if (serviceDto.value.categories_ids) {
    serviceDto.value.categories_ids = checkItemIsFound(item)
      ? serviceDto.value.categories_ids.filter((i) => {
          return i !== item;
        })
      : [...serviceDto.value.categories_ids, item];
  }
};
const checkItemIsFound2 = (item: number) =>
  serviceDto.value.categories.filter((i) => i == item).length > 0;

const addItem2 = (item: number) => {
  if (serviceDto.value.categories) {
    serviceDto.value.categories = checkItemIsFound2(item)
      ? serviceDto.value.categories.filter((i) => {
          return i !== item;
        })
      : [...serviceDto.value.categories, item];
  }
};
onMounted(() => {
  useStoresStore().getCategoriesList();
  if (id !== "new") {
    store.getServiceById(id.toString());
  }
});
const submit = () => {
  console.log(id);
  myForm.value?.validate().then((v) => {
    if (v.valid) {
      if (id === "new") {
        store.createService();
      } else {
        store.updateService();
      }
    }
  });
};
onUnmounted(() => {
  editImage.value = false;
});
</script>
<template>
  <Page>
    <template #body>
      <VForm ref="myForm" class="lg:px-20 pt-20 capitalize">
        <div class="grid lg:grid-cols-3 gap-8">
          <div class="col-span-1 flex flex-col">
            <p class="text-xl">{{ $t("myServices.customerGender") }}</p>
            <div v-if="id === 'new'" class="flex justify-start items-center gap-5 mt-5">
              <VBtn
                :variant="serviceDto.gender === 'male' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="serviceDto.gender = 'male'"
                >Male</VBtn
              >
              <VBtn
                :variant="serviceDto.gender === 'female' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="serviceDto.gender = 'female'"
                >female</VBtn
              >
              <VBtn
                :variant="serviceDto.gender === 'both' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="serviceDto.gender = 'both'"
                >both</VBtn
              >
            </div>
            <div v-else class="flex justify-start items-center gap-5 mt-5">
              <VBtn
                :variant="serviceDto.for_gender_type === 'male' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="serviceDto.for_gender_type = 'male'"
                >Male</VBtn
              >
              <VBtn
                :variant="serviceDto.for_gender_type === 'female' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="serviceDto.for_gender_type = 'female'"
                >female</VBtn
              >
              <VBtn
                :variant="serviceDto.for_gender_type === 'both' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="serviceDto.for_gender_type = 'both'"
                >both</VBtn
              >
            </div>
          </div>
          <div class="col-span-2 flex flex-col">
            <p class="text-xl">{{ $t("myServices.availableServices") }}</p>
            <div
              v-if="serviceDto.categories.length > 0"
              class="flex flex-wrap justify-start items-center gap-5 mt-5"
            >
              <VBtn
                v-for="item in categoriesList"
                @click="addItem2(item.id)"
                :variant="checkItemIsFound2(item.id) ? 'tonal' : 'outlined'"
                class="flex justify-between items-center rounded-full capitalize"
              >
                <div
                  class="w-full flex justify-center h-[28px] gap-8 items-center flex-row"
                >
                  <span class="text-[14px]"
                    >{{ locale === "en" ? item.title__ml.en : item.title__ml.ar }}
                  </span>
                  <img class="mx-0 h-[24px]" :src="getFileUrl(item.icon_path)" alt="" />
                </div>
              </VBtn>
            </div>
            <div v-else class="flex flex-wrap justify-start items-center gap-5 mt-5">
              <VBtn
                v-for="item in categoriesList"
                @click="addItem(item.id)"
                :variant="checkItemIsFound(item.id) ? 'tonal' : 'outlined'"
                class="flex justify-between items-center rounded-full capitalize"
              >
                <div
                  class="w-full flex justify-center h-[28px] gap-8 items-center flex-row"
                >
                  <span class="text-[14px]"
                    >{{ locale === "en" ? item.title__ml.en : item.title__ml.ar }}
                  </span>
                  <img class="mx-0 h-[24px]" :src="getFileUrl(item.icon_path)" alt="" />
                </div>
              </VBtn>
            </div>
          </div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-10 mt-5">
          <div class="cols-span-3 lg:col-span-2">
            <p>{{ $t("myServices.serviceNameEn") }}</p>
            <VTextField
              :rules="[requiredValidator]"
              :error-messages="errors.title__en"
              v-model="serviceDto.title.en"
              class="w-full"
            />
          </div>
          <div class="col-span-2">
            <p>{{ $t("myServices.serviceNameAr") }}</p>
            <VTextField
              :error-messages="errors.title__ar"
              v-model="serviceDto.title.ar"
              class="w-full"
            />
          </div>
          <div class="lg:col-span-1 block">
            <p>{{ $t("myServices.serviceDuration") }}</p>
            <div class="flex justify-between items-center gap-8 flex-row">
              <VTextField
                :rules="[requiredValidator]"
                :label="$t('myServices.hrs')"
                v-model="serviceDto.duration_in_houres"
              />
              <VTextField
                :rules="[requiredValidator]"
                :label="$t('myServices.mins')"
                :error-messages="errors.m_duration"
                v-model="serviceDto.duration_in_minutes"
              />
            </div>
          </div>
          <div class="col-span-3 block">
            <p>{{ $t("myServices.serviceDescriptionEn") }}</p>
            <VTextarea
              :rules="[requiredValidator]"
              :error-messages="errors.description__en"
              v-model="serviceDto.description.en"
              :no-resize="true"
            />
          </div>
          <div class="col-span-3 block">
            <p>{{ $t("myServices.serviceDescriptionAr") }}</p>
            <VTextarea
              :error-messages="errors.description__ar"
              v-model="serviceDto.description.ar"
              :no-resize="true"
            />
          </div>
          <div class="col-span-3">
            <p>{{ $t("myServices.serviceLocationAndPrice") }}</p>
            <div class="flex justify-start gap-10">
              <VBtn
                @click="serviceDto.location[0].home = !serviceDto.location[0].home"
                :variant="serviceDto.location[0].home ? 'tonal' : 'outlined'"
                class="rounded-full"
              >
                <div class="flex justify-start capitalize items-center">
                  <VIcon icon="mdi-home" color="primary" />
                  {{ $t("myServices.atHome") }}
                </div>
              </VBtn>

              <VBtn
                @click="serviceDto.location[1].store = !serviceDto.location[1].store"
                :variant="serviceDto.location[1].store ? 'tonal' : 'outlined'"
                class="rounded-full"
              >
                <div class="flex justify-start capitalize items-center">
                  <VIcon icon="mdi-store" color="primary" />
                  {{ $t("myServices.atStore") }}
                </div>
              </VBtn>
            </div>
          </div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-5 gap-8 my-5">
          <div class="flex justify-between items-center lg:grid lg:grid-cols-2 w-full">
            <label for=""> {{ $t("myServices.malePrice") }}</label>

            <VTextField
              :rules="[requiredValidator]"
              :error-messages="errors.home_male_price"
              v-model="serviceDto.location[0].male_price"
              class="max-w-[80px]"
              append-inner-icon="mdi-dollar"
            />
          </div>
          <div class="flex justify-between items-center lg:grid lg:grid-cols-2 w-full">
            <label for=""> {{ $t("myServices.malePrice") }}</label>

            <VTextField
              :rules="[requiredValidator]"
              :error-messages="errors.store_male_price"
              v-model="serviceDto.location[1].male_price"
              class="max-w-[80px]"
              append-inner-icon="mdi-dollar"
            />
          </div>

          <div class="flex justify-between items-center lg:grid lg:grid-cols-2 w-full">
            <label for=""> {{ $t("myServices.femalePrice") }}</label>

            <VTextField
              :rules="[requiredValidator]"
              :error-messages="errors.home_female_price"
              v-model="serviceDto.location[0].female_price"
              class="max-w-[80px]"
              append-inner-icon="mdi-dollar"
            />
          </div>

          <div class="flex justify-between items-center lg:grid lg:grid-cols-2 w-full">
            <label for=""> {{ $t("myServices.femalePrice") }}</label>

            <VTextField
              :rules="[requiredValidator]"
              :error-messages="errors.store_female_price"
              v-model="serviceDto.location[1].female_price"
              class="max-w-[80px]"
              append-inner-icon="mdi-dollar"
            />
          </div>
        </div>

        <!-- offer    . . . . -->
        <div>
          <VCheckbox v-model="serviceDto.has_offer">
            <template #label>
              <img class="w-[30px]" :src="Offer" alt="" />
              <span> {{ $t("myServices.offer") }}</span>
            </template>
          </VCheckbox>
          <div
            class="grid lg:grid-cols-4 gap-10 my-5 grid-cols-1"
            v-if="serviceDto.has_offer"
          >
            <div>
              <p>{{ $t("myServices.startDate") }}</p>
              <AppDateTimePicker v-model="serviceDto.offer_start_date" />
            </div>
            <div>
              <p>{{ $t("myServices.endDate") }}</p>
              <AppDateTimePicker v-model="serviceDto.offer_end_date" />
            </div>
          </div>
        </div>
        <div class="flex justify-center items-center w-full">
          <img
            class="w-[300px] h-[300px] object-cover"
            id="prev"
            v-if="serviceDto.image !== ''"
            :src="getFileUrl(serviceDto.imagePath ?? '')"
            alt=""
          />
        </div>
        <div class="flex justify-center my-5 mt-8 gap-10 items-center w-full">
          <div class="max-w-[70px]">
            <VBtn
              @click="submit"
              width="50"
              height="50"
              class="flex justify-center items-center"
            >
              <VIcon size="32">mdi-plus</VIcon>
            </VBtn>
            <p class="text-center text-md uppercase font-semibold mt-1">
              {{
                id === "new"
                  ? $t("myServices.addService")
                  : $t("myServices.updateService")
              }}
            </p>
          </div>

          <div class="max-w-[70px]">
            <FileBtn
              @change="
                (e:any) => {
                  previewProfileImage(e, 'prev');
                }
              "
              icon="tabler:camera"
              v-model="serviceDto.image"
            />
            <p class="capitalize text-center text-md uppercase font-semibold mt-1">
              {{
                editImage || id !== "new"
                  ? $t("myServices.editImage")
                  : $t("myServices.addImage")
              }}
            </p>
          </div>
        </div>
        <!-- last div-->
      </VForm>
    </template>
  </Page>
</template>
<style></style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
