<script setup lang="ts">
import { useLayouts } from "@core/composable/useLayout"
import Page from "@/components/Page.vue";
import OrderCard from "@/components/profile/ordersRequest/OrderCard.vue";
import { useFile } from "@/composables";
import { useAppStore } from "@/stores/App";
import { useOrderStore } from "@/stores/Order";
import Loading from "@/components/shared/Loading.vue";
import { useI18n } from "vue-i18n";
const { t, locale } = useI18n();
let timer = ref(0);

const store = useOrderStore();
const showOrderDetails = ref(false);
const appStore = useAppStore();
const date = ref();
const {
  ordersList,
  order,
  isLoading,
  allPages,
  minutes,
  seconds,
  page,
  total,
} = storeToRefs(store);
const { isAppRtl } = useLayouts();
const { getFileUrl } = useFile();
const send = () => {
  appStore.closeModal();
};
const getDetails = (id: number) => {
  // clearInterval(timer.value);
  // console.log("selected store id  :", id);

  store
    .getOrderById(id)
    .then(() => {
      // startTimer(order.value.waiting_time * 60);
      // showOrderDetails.value = true;
    })
    .catch(() => {});
};
onMounted(() => {
  store
    .getRequestedOrders()
    .then(() => {})
    .catch(() => {});
  store.getReadCount();
});
watch(date, () => {
  store.getAvailabletimeslot(date.value);
});
</script>
<template>
  <Page>
    <template #sidebar>
      <div class="capitalize flex flex-col justify-between items-center h-full">
        <div>
          <div class="w-full flex justify-start gap-5 flex-row flex-nowrap items-center">
            <VBtn
              @click="appStore.closeSidebar()"
              variant="text"
              size="40"
              float
              color="primary"
            >
              <VIcon size="40"> mdi-chevron-left </VIcon>
            </VBtn>
            <h2 class="font-semibold text-[24px]">
              select date time to accept the order
            </h2>
          </div>
          <div class="flex justify-center flex-col items-center mt-8">
            <AppDateTimePicker
              v-model="date"
              :model-value="new Date().toJSON().slice(0, 10)"
              label="Inline"
              multiple
              :config="{ inline: true }"
              class="calendar-date-picker w-full"
            />
          </div>
        </div>
        <VBtn class="capitalize w-80" height="46">confirm</VBtn>
      </div>
    </template>

    <template #modal>
      <div class="w-[380px] p-3">
        <h2 class="font-normal text-center">Are you sure want to reject this order ?</h2>
        <VTextarea :no-resize="true" />
        <div class="flex px-14 justify-center items-center w-full mt-5">
          <VBtn class="w-full" @click="send">Send</VBtn>
        </div>
      </div>
    </template>
    <template #body>
      <div class="mt-[140px]" v-if="isLoading">
        <Loading />
      </div>
      <div v-else>
        <div
          v-if="ordersList.length === 0"
          class="mt-[140px] w-full h-full flex justify-center items-center"
        >
          <h1 class="capitalize font-normal">
            {{ $t("myCalendar.noDataAvailable") }}
          </h1>
        </div>
        <div v-else>
          <div class="order-requets grid grid-cols-1 lg:grid-cols-2">
            <div class="px-8 mt-3">
              <div
                class="mt-5 grid gird-cols-1 gap-5 lg:px-20 lg:max-h-[600px] overflow-y-scroll py-5"
              >
                <OrderCard
                  @details="
                    () => {
                      showOrderDetails = true;
                    }
                  "
                  :timer="timer"
                  :order="item"
                  v-for="item in ordersList"
                  type="gifts"
                />
              </div>
            </div>
            <div
              class="w-full lg:min-h-[70vh] flex justify-center lg:justify-end pt-10 mt-3"
              :class="isAppRtl ? 'border-right' : 'border-left'"
            >
              <VCard
                v-if="showOrderDetails"
                class="rounded-2xl shadow-2xl min-w-[400px] h-full w-[70%] p-3"
              >
                <div
                  class="lg:px-4 flex justify-between items-center py-4"
                  :class="isAppRtl ? 'lg:pl-5' : 'lg:pr-5'"
                >
                  <VBtn
                    @click="showOrderDetails = false"
                    icon="mdi-close "
                    float
                    size="40"
                  />
                  <h2 class="text-[20px] text-primary">#1234</h2>
                </div>
                <div
                  class="grid grid-cols-1 gap-4 pt-1 capitalize"
                  :class="isAppRtl ? 'lg:pr-14 lg:pl-8' : 'lg:pl-14 lg:pr-8'"
                >
                  <div class="flex justify-between items-center">
                    <h2 class="font-normal">{{ order.customer_name }}</h2>
                    <VChip
                      v-if="order.is_gifted"
                      lass="rounded-sm"
                      variant="elevated"
                      color="#c4f"
                      ><span class="px-4 py-2"> gift </span></VChip
                    >
                  </div>

                  <div class="flex justify-between flex-row items-center">
                    <h3 class="font-light text-gray-400">Service location</h3>
                    <div>
                      <VIcon
                        color="primary"
                        size="24"
                        class="mx-2"
                        :icon="
                          order.order_location === 'store' ? 'mdi-store' : 'mdi-home'
                        "
                      />
                      <VText class="text-on-surface">{{ order.order_location }}</VText>
                    </div>
                  </div>
                  <div class="flex justify-between flex-row items-center">
                    <h3 class="font-light text-gray-400">gander</h3>
                    <div>
                      <VText class="text-on-surface">{{
                        order.gifted_person.gander
                      }}</VText>
                    </div>
                  </div>
                  <div class="flex justify-between flex-row items-center">
                    <h3 class="font-light text-gray-400">employee</h3>
                    <div>
                      <VText class="text-on-surface">{{ order.employee }}</VText>
                    </div>
                  </div>
                  <div class="flex flex-col gap-4" v-if="order.is_gifted">
                    <div class="flex justify-between flex-row items-center">
                      <h3 class="font-light text-gray-400">gifted name</h3>
                      <div>
                        <VText class="text-on-surface">{{
                          order.gifted_person.name
                        }}</VText>
                      </div>
                    </div>
                    <div class="flex justify-between flex-row items-center">
                      <h3 class="font-light text-gray-400">gifted phone</h3>
                      <div>
                        <VText class="text-on-surface">{{
                          order.gifted_person.phone
                        }}</VText>
                      </div>
                    </div>
                    <div class="flex justify-between flex-row items-center">
                      <h3 class="font-light text-gray-400">gifted location</h3>
                      <div>
                        <VText class="text-on-surface">{{
                          order.gifted_person.location
                        }}</VText>
                      </div>
                    </div>
                  </div>
                  <div class="flex justify-between flex-row items-center">
                    <h3 class="font-light text-gray-400">total ammount</h3>
                    <div>
                      <VText class="text-on-surface"
                        >{{ Math.floor(order.total_price)
                        }}<span class="uppercase"> sar</span></VText
                      >
                    </div>
                  </div>
                  <VDivider />
                  <div class="flex flex-row gap-3" v-for="service in order.services">
                    <img
                      class="w-[60px] h-[60px] object-cover rounded-lg shadow-lg"
                      :src="getFileUrl(service.related_service.image_path ?? '')"
                      alt=""
                    />
                    <div class="flex justify-between flex-row-reverse w-full">
                      <div class="flex flex-col justify-center gap-2">
                        <VText>{{ service.service_price }} SAR</VText>
                      </div>
                      <div class="flex flex-col justify-end pb-3">
                        <VText class="text-primary font-semibold">{{
                          service.service_location
                        }}</VText>
                        <VText class="">{{
                          locale === "ar"
                            ? service.related_service.title__ml.ar
                            : service.related_service.title__ml.en
                        }}</VText>
                      </div>
                    </div>
                  </div>
                  <div class="mt-5 flex justify-between flex-row items-center">
                    <h3 class="font-light text-gray-400">payment method</h3>
                    <div>
                      <VText class="text-on-surface">
                        {{ order.payment_method.slug }}
                      </VText>
                    </div>
                  </div>
                  <div class="grid grid-cols-5 gap-4">
                    <div class="col-span-4 grid grid-cols-1 gap-4">
                      <VBtn @click="appStore.openSidebar()" class="capitalize">
                        Accept</VBtn
                      >
                      <VBtn
                        class="capitalize"
                        variant="outlined"
                        @click="appStore.openModal()"
                      >
                        reject</VBtn
                      >
                    </div>
                    <div class="lg:col-span-1 pt-2">
                      <span
                        class="border-orange-500 border-solid p-2 border-[1px] rounded-md py-3"
                      >
                        {{ minutes }}:{{ seconds }}</span
                      >
                    </div>
                  </div>
                </div>
              </VCard>
            </div>
            <div></div>
          </div>
        </div>
        <div class="mt-10" v-if="total > 15">
          <VPagination :length="allPages" :total-visible="6" v-model="page">
          </VPagination>
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.order-requets ::-webkit-scrollbar {
  display: none !important;
}
.border-right {
  border-right: 1px solid rgba(128, 128, 128, 0.226);
}
.border-left {
  border-left: 1px solid rgba(128, 128, 128, 0.226);
}
.v-input--horizontal {
  display: none !important;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
