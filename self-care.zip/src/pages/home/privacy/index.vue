<script setup lang="ts">
import Pravicy from "@/components/Pravicy.vue";
import Page from "@/components/Page.vue";
</script>
<template>
  <Page>
    <template #body>
      <Pravicy />
    </template>
  </Page>
</template>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: false
</route>
