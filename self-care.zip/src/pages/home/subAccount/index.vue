<script setup lang="ts">
import Page from "@/components/Page.vue";
import subAccount from "@/components/subAccount/subAccount.vue";
import { useSubAccountStore } from "@/stores/SubAccount";
import { useAppStore } from "@/stores/App";
import { useI18n } from "vue-i18n";
import { useScreen } from "@/composables/useScreen";
const appStore = useAppStore();
const store = useSubAccountStore();
const { t } = useI18n();
const { screenSize } = useScreen();
const idsToDelete = ref(null);
const deleteItems = ref(false);
const { subAccountsList, total, perPage, page, AllPages, isLoading } = storeToRefs(store);

onMounted(() => {
  store.getSubAccountsList();
});
</script>
<template>
  <Page>
    <template #action-button>
      <VBtn
        :variant="screenSize === 'sm' ? 'text' : 'elevated'"
        v-if="deleteItems"
        @click="appStore.openModal()"
        class="capitalize"
      >
        <VIcon size="30" v-if="screenSize === 'sm'"> mdi-delete </VIcon>
        <div v-else>
          {{ $t("subAccounts.deleteAccount") }}
        </div>
      </VBtn>

      <router-link v-else to="subaccount/new"
        ><VBtn :variant="screenSize === 'sm' ? 'text' : 'elevated'" class="capitalize">
          <VIcon size="30" v-if="screenSize === 'sm'"> mdi-plus </VIcon>
          <div v-else>
            {{ $t("subAccounts.addNewAccount") }}
          </div>
        </VBtn></router-link
      >
    </template>
    <template #modal>
      <div class="p-3 max-w-[400px] flex flex-col gap-8">
        <div class="px-5">
          <p class="text-xl text-center">
            {{ $t("subAccounts.confirmDelete") }}
          </p>
        </div>
        <div class="flex flex-col justify-center items-center gap-5 my-3 w-full">
          <VBtn
            :loading="isLoading"
            @click="store.deleteSubAccount(idsToDelete)"
            class="capitalize"
            width="350"
            height="46"
          >
            {{ $t("subAccounts.delete") }}
          </VBtn>
          <VBtn
            @click="appStore.closeModal()"
            variant="outlined"
            class="capitalize"
            width="350"
            height="46"
          >
            {{ $t("subAccounts.cancel") }}
          </VBtn>
        </div>
      </div>
    </template>

    <template #body>
      <div class="overflow-hidden pt-10 sub-accounts px-5">
        <div
          class="lg:px-20 max-h-[560px] pt-20 pb-2 gap-y-8 overflow-y-scroll grid lg:grid-cols-5 gap-x-8 grid-cols-1"
        >
          <div v-if="isLoading">
            <p>{{ $t("subAccounts.loading") }}</p>
          </div>
          <div
            v-else
            class="col-span-2 flex justify-center gap-8 items-center"
            v-for="item in subAccountsList"
          >
            <VCheckbox
              v-if="deleteItems"
              :value="item.id"
              :multiple="false"
              v-model="idsToDelete"
            />
            <subAccount :user="item" />
          </div>
        </div>
        <div @click="deleteItems = !deleteItems" class="absolute bottom-5 right-10">
          <VBtn variant="text"
            ><span class="z-40 text-md capitalize text-error"
              >{{
                deleteItems ? $t("subAccounts.cancel") : $t("subAccounts.deleteAccount")
              }}
            </span></VBtn
          >
        </div>
        <div class="pt-5 fixed bottom-5 left-0 w-full flex justify-center items-center">
          <VPagination v-model="page" :total-visible="6" :length="AllPages" />
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.sub-accounts ::-webkit-scrollbar {
  display: none !important;
}
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
