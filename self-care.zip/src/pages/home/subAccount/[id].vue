<script setup lang="ts">
import Page from "@/components/Page.vue";
import Permission from "@/components/subAccount/PermissionItem.vue";
import { requiredValidator, regexValidator } from "@validators";
import { useSubAccountStore } from "@/stores/SubAccount";
import Loading from "@/components/shared/Loading.vue";
import { useI18n } from "vue-i18n";
const store = useSubAccountStore();
const { subAccountDto, permissiontsLoading, permissionsList, isLoading } = storeToRefs(
  store
);

const router = useRouter();
const ksaRegex = /^((\+|00)966)?(5)([0-9]{8})$/;
const props = defineProps(["id"]);
const myForm = ref(null);
const { t } = useI18n();
const errors = ref<Record<string, string | undefined>>({
  mobile: undefined,
  name: undefined,
});
const submit = () => {
  myForm.value.validate().then((valid: any) => {
    if (valid.valid) {
      if (props.id === "new") {
        store.createSubAccount();
      } else {
        store.updateSubAccount();
      }
    }
  });
};
onMounted(() => {
  if (props.id !== "new") {
    if (subAccountDto.value.id === 0) {
      router.go(-1);
    }
  }
  store.getPermissions();
});
</script>
<template>
  <Page>
    <template #action-button>
      <div>
        <VBtn :loading="isLoading" @click="submit" class="capitalize"
          >{{ id === "new" ? $t("subAccounts.addNewAccount") : $t("subAccounts.save") }}
        </VBtn>
      </div>
    </template>
    <template #body>
      <div class="pt-20 lg:px-20 capitalize">
        <VForm ref="myForm" class="flex flex-col gap-5">
          <div class="px-5">
            <p>{{ $t("subAccounts.employeeName") }}</p>
            <VTextField
              :rules="[requiredValidator]"
              :error-messages="errors.name"
              v-model="subAccountDto.name"
              class="w-[400px]"
              placeholder="name"
            />
          </div>
          <div class="px-5">
            <p>{{ $t("subAccounts.phone") }}</p>
            <VTextField
              :rules="[requiredValidator, regexValidator(subAccountDto.mobile, ksaRegex)]"
              :error-messages="errors.mobile"
              v-model="subAccountDto.mobile"
              class="w-[400px]"
              placeholder="+966 - "
            />
          </div>
        </VForm>
        <div class="px-5">
          <p class="my-10">{{ $t("subAccounts.permissionsList") }}</p>
          <div v-if="permissiontsLoading" class="flex w-full min-h-[400px]">
            <Loading />
          </div>
          <div
            v-else
            class="flex justify-start flex-wrap lg:flex-row flex-col lg:items-center gap-8"
          >
            <Permission
              @permisstion-evt=""
              v-for="permission in permissionsList"
              :permission="permission"
            />
          </div>
        </div>

        <!-- <div class="mt-20 flex justify-center items-center"></div> -->
      </div>
    </template>
  </Page>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
