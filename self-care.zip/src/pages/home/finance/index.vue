<script setup lang="ts">
import Page from "@/components/Page.vue";
import Orders from "@/components/profile/finance/Orders.vue";
import BtnTab from "@/components/shared/BtnTab.vue";
import { useDateTime } from "@/composables/useDateTime";
import { useAppStore } from "@/stores/App";
import { useFinaceStore } from "@/stores/Finance";
import { useI18n } from "vue-i18n";
const appStore = useAppStore();
const date = ref();
const { t } = useI18n();
const store = useFinaceStore();
const mainTab = ref("0");
const { reformatDate } = useDateTime();
const events = ref([
  {
    name: "Event 1",
    start: "2022-04-01",
    timed: false,
  },
  {
    name: "Event 2",
    start: "2022-04-05",
    end: "2022-04-07",
  },
  {
    name: "Event 3",
    start: "2022-04-09T08:00:00",
    end: "2022-04-09T10:00:00",
    timed: true,
  },
]);
const { startDate, endDate } = storeToRefs(store);
onMounted(() => {
  store.getFinance({ date: "today" });
});

const confirm = () => {
  store
    .getFinance({
      from_date: reformatDate(startDate.value),
      to_date: reformatDate(endDate.value),
    })
    .then(() => {
      appStore.closeSidebar();
    });
};
</script>
<template>
  <Page :inner="true" sidebar-width="40%">
    <template #sidebar>
      <div class="flex gap-10 flex-wrap">
        <div>
          <p class="capitalize">start date</p>
          <AppDateTimePicker
            v-model="startDate"
            label="Inline"
            multiple
            :config="{ inline: true }"
            class="calendar-date-picker w-full"
          />
        </div>
        <div class="capitalize">
          <p>end date</p>
          <AppDateTimePicker
            v-model="endDate"
            label="Inline"
            multiple
            :config="{ inline: true }"
            class="calendar-date-picker w-full"
          />
        </div>
        <div class="mt-10 flex justify-center items-center w-full">
          <VBtn class="capitalize" @click="confirm()"> confirm </VBtn>
        </div>
      </div>
    </template>
    <template #body>
      <div class="pt-12 w-full capitalize">
        <div class="flex flex-col w-full items-center justify-start">
          <div class="tabs flex justify-center items-center gap-4">
            <BtnTab
              @click="store.getFinance({ date: 'today' })"
              v-model="mainTab"
              :content="$t('finance.today')"
              value="0"
            />
            <BtnTab
              @click="store.getFinance({ date: 'this_mounth' })"
              v-model="mainTab"
              :content="$t('finance.thisMounth')"
              value="1"
            />
            <BtnTab
              v-model="mainTab"
              @click="appStore.openSidebar()"
              :content="$t('finance.custom')"
              value="2"
            />
          </div>
          <!-- tabs ends  . . .-->
          <!-- tabs windows  . . . -->
          <div class="mt-8 w-full">
            <VWindow v-model="mainTab">
              <VWindowItem value="0"><Orders :obj="{ date: 'today' }" /></VWindowItem>
              <VWindowItem value="1"
                ><Orders :obj="{ date: 'this_mounth' }"
              /></VWindowItem>
              <VWindowItem value="2"
                ><Orders
                  :obj="{
                    from_date: reformatDate(startDate.value),
                    to_date: reformatDate(endDate.value),
                  }"
                  :is-custom="true"
              /></VWindowItem>
            </VWindow>
          </div>
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.flatpickr-calendar {
  height: 100% !important;
}
.v-input--horizontal {
  display: none !important;
}
.flatpickr-innerContainer {
  width: 100% !important ;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
