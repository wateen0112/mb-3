<script setup lang="ts">
import Page from "@/components/Page.vue";
import RangeInput from "@/components/shared/RangeInput.vue";
import LocationPicker from "@/components/shared/LocationPicker.vue";
import Switch from "@/components/shared/Switch.vue";
import { useTimeSlotsStore } from "@/stores/WorkingTimes";
import { useServiceStore } from "@/stores/Service";
import { time } from "console";
import { useI18n } from "vue-i18n";
import { TimeSlotDto } from "@/api/workingTime/dto";
const workTimePlace = ref("store");
const openCard = ref(false);
const workingDays = ref<string[]>([]);
const store = useTimeSlotsStore();
const { locale, t } = useI18n();
const serviceStore = useServiceStore();
const { servicesList } = storeToRefs(serviceStore);
const weekDays = [
  t("days.sat"),
  t("days.sun"),
  t("days.mon"),
  t("days.tue"),
  t("days.wed"),
  t("days.thu"),
  t("days.fri"),
];
const isCustom = ref(false);
const showCoverageArea = ref(false);
const showTimeSlot = ref(false);

const setWorkTimePlace = (place: string) => {
  workTimePlace.value = place;
};
const removeShift = (id: number, isCustom: boolean = false) => {
  if (isCustom) {
    customTimeSlotsList.value = customTimeSlotsList.value.filter((item: any) => {
      return item.id !== id;
    });
  } else {
    normalTimeSlotsList.value = normalTimeSlotsList.value.filter((item: any) => {
      return item.id != id;
    });
  }
};
const checkDayIsFound = (item: string) =>
  workingDays.value.filter((i: any) => i == item).length > 0;
const checkServiceIsFound = (item: number, index: number) =>
  normalTimeSlotsList.value[index].services_ids.filter((i: any) => i == item).length > 0;

// const addService = (item: string) => {
//   services.value = checkServiceIsFound(item,index)
//     ? services.value.filter((i: any) => {
//         return i !== item;
//       })
//     : [...services.value, item];
// };

const addDay = (item: string) => {
  workingDays.value = checkDayIsFound(item)
    ? workingDays.value.filter((i: any) => {
        return i !== item;
      })
    : [...workingDays.value, item];
};
const { customTimeSlotsList, normalTimeSlotsList, timeSlot } = storeToRefs(store);
onMounted(() => {
  store.getTimeSlotsList();
  timeSlot.value.working_days = normalTimeSlotsList.value[0].working_days;
});
const findWorkDay = (workDay: string) => {
  return (
    timeSlot.value.working_days.filter((wd: string) => {
      return wd === workDay;
    }).length > 0
  );
};

onMounted(() => {
  serviceStore.getServicesList();
});
const addNewShiftEvt = () => {
  if (timeSlot.value === normalTimeSlotsList.value[0]) {
    normalTimeSlotsList.value.push(new TimeSlotDto());
    normalTimeSlotsList.value[normalTimeSlotsList.value.length].working_days =
      normalTimeSlotsList.value[0].working_days;
  } else {
  }
};
const addservice = (id: number, timeslotIndex: number) => {
  if (!checkServiceIsFound(id, timeslotIndex)) {
    normalTimeSlotsList.value[timeslotIndex].services_ids = [
      ...normalTimeSlotsList.value[timeslotIndex].services_ids,
      id,
    ];
  } else {
    normalTimeSlotsList.value[timeslotIndex].services_ids.filter((i: number) => {
      return id !== i;
    });
  }
};
</script>
<template>
  <Page>
    <template #action-button>
      <router-link to="workingtime/shift-calendar">
        <VBtn class="capitalize justify-start items-center gap-8" height="46px">
          <VIcon> mdi-calendar</VIcon>
          <span> {{ $t("workingTimes.shiftCalendar") }} </span>
        </VBtn></router-link
      >
    </template>
    <template #body>
      <div class="lg:px-20 pt-10 gap-8 capitalize grid lg:grid-cols-6 grid-cols-1">
        <div class="col-span-2 relative w-full">
          <div class="">
            <div>
              <p class="text-black">
                {{ $t("workingTimes.normalWorkingHours") }}
              </p>
              <VCard
                @click="
                  () => {
                    isCustom = false;
                    openCard = true;
                    timeSlot = normalTimeSlotsList[0];
                  }
                "
                class="min-w-[300px] lg:w-[400px] my-3"
              >
                <div class="flex justify-between items-center py-5 px-5">
                  <span> {{ $t("workingTimes.normalWorkingDays") }} </span>
                  <Switch
                    @click="store.normalChangeStatus()"
                    v-model="normalTimeSlotsList[0].is_active"
                    color="success"
                  />
                </div>
              </VCard>
            </div>
            <VDivider />
            <div class="mt-5">
              <p class="text-black">{{ $t("workingTimes.customWorkingHours") }}</p>
              <VCard
                @click="
                  () => {
                    isCustom = true;

                    timeSlot = ts;
                    openCard = true;
                  }
                "
                v-for="ts in customTimeSlotsList"
                class="min-w-[300px] lg:w-[400px] my-3"
              >
                <div class="flex justify-between items-center py-5 px-5">
                  <span>{{ ts.title }}</span>
                  <Switch
                    v-model="ts.is_active"
                    @click="store.customChaneStatus(ts.id)"
                    color="success"
                  />
                </div>
              </VCard>
            </div>
            <!-- <div class="flex mt-8 justify-center items-center w-full">
              <VBtn
                @click="showTimeSlot = !showTimeSlot"
                class="capitalize"
                width="240px"
                height="45"
                >Add new time slot
              </VBtn>
            </div> -->
          </div>
        </div>
        <div class="col-span-4" v-if="openCard && timeSlot.is_active">
          <VCard
            class="p-2 relative lg:px-14 w-full h-auto min-h-[300px] rounded-xl pb-5"
          >
            <VBtn @click="openCard = false" variant="text" class="absolute top-3 right-3"
              ><VIcon>mdi-close</VIcon></VBtn
            >
            <div class="main-card">
              <div class="flex justify-center items-center gap-8 mt-5">
                <VBtn
                  @click="setWorkTimePlace('store')"
                  class="capitalize rounded-full"
                  :variant="workTimePlace === 'store' ? 'tonal' : 'outlined'"
                >
                  {{ $t("workingTimes.atStore") }}
                </VBtn>
                <VBtn
                  @click="setWorkTimePlace('home')"
                  class="capitalize rounded-full"
                  :variant="workTimePlace === 'home' ? 'tonal' : 'outlined'"
                >
                  {{ $t("workingTimes.atHome") }}
                </VBtn>
              </div>
              <div>
                <h4>
                  {{ $t("workingTimes.selectWorkingDays") }}
                </h4>

                <div
                  class="mt-5 flex justify-start items-center flex-row flex-wrap gap-3"
                >
                  <VBtn
                    @click="addDay(item)"
                    v-for="item in weekDays"
                    :variant="findWorkDay(item) ? 'tonal' : 'outlined'"
                    class="flex justify-between items-center rounded-full capitalize"
                    >{{ item }}</VBtn
                  >
                </div>
              </div>
              <div></div>
              <!-- col 2 -->
              <div class="mt-5" v-if="timeSlot.title">
                <p class="text-black">
                  {{ $t("workingTimes.timeSlotName") }}
                </p>
                <VTextField v-model="timeSlot.title" class="w-full" />
              </div>
              <div class="grid grid-cols-2 gap-10">
                <div class="mt-5">
                  <p class="text-black">{{ $t("workingTimes.startDate") }}</p>
                  <AppDateTimePicker v-model="timeSlot.starting_date" class="w-full" />
                </div>
                <div class="mt-5">
                  <p class="text-black">{{ $t("workingTimes.endDate") }}</p>
                  <AppDateTimePicker v-model="timeSlot.ending_date" class="w-full" />
                </div>
              </div>
              <div class="mt-5">
                <p class="text-black">
                  {{ $t("workingTimes.selectService") }}
                </p>
              </div>

              <div class="mt-5" v-for="(ts, index) in normalTimeSlotsList">
                <div class="relative">
                  <p v-if="ts.location === workTimePlace">
                    {{ $t("workingTimes.shift") }}
                  </p>
                  <div class="flex justify-start items-center gap-2">
                    <div v-for="item in servicesList">
                      <VBtn
                        @click="addservice(item.id, index)"
                        v-if="ts.location === workTimePlace"
                        :variant="
                          checkServiceIsFound(item.id, index) ? 'tonal' : 'outlined'
                        "
                        class="flex justify-between items-center rounded-full capitalize"
                        >{{ locale === "en" ? item.title.en : item.title.ar }}</VBtn
                      >
                    </div>
                  </div>
                  <div v-if="ts.location === workTimePlace" class="relative">
                    <VBtn
                      @click="removeShift(ts.id, isCustom)"
                      class="absolute z-40 right-[-20px]"
                      variant="text"
                    >
                      <VIcon>mdi-close</VIcon>
                    </VBtn>
                    <RangeInput
                      v-model:max-value="ts.shift_from_time"
                      v-model:min-value="ts.shift_to_time"
                    />
                  </div>
                </div>
              </div>

              <div class="flex justify-end items-center mt-5">
                <VBtn @click="" class="capitalize" variant="text">
                  <VIcon icon="mdi-plus" /> {{ $t("workingTimes.newShift") }}
                </VBtn>
              </div>
              <div
                v-if="workTimePlace === 'home'"
                class="px-5 flex justify-between items-center mt-5"
              >
                <span> {{ $t("workingTimes.setCoverageArea") }} </span>
                <Switch @change="showCoverageArea = !showCoverageArea" />
              </div>

              <div class="lg:px-8" v-if="showCoverageArea && workTimePlace == 'home'">
                <LocationPicker
                  :coverageArea="normalTimeSlotsList[0].coverageArea"
                  :withCoverageArea="true"
                  apiKey="AIzaSyBjhWSDGq5wahkoyCnMVNaln6mowhPZt-A"
                />
                <div class="px-10 pt-10 flex justify-start flex-col gap-3">
                  <p>{{ $t("workingTimes.setCoverageArea") }}</p>
                  <VSlider
                    :min="1"
                    :max="20"
                    :step="1"
                    v-model="normalTimeSlotsList[0].coverageArea"
                  ></VSlider>
                  <p>{{ normalTimeSlotsList[0].coverageArea }}Km</p>
                </div>
              </div>

              <div class="flex justify-center items-center mt-10">
                <VBtn
                  @click="
                    () => {
                      if (isCustom) {
                        store.updateCustomWorkTime();
                      } else {
                        store.updateNormalWorkTime();
                      }
                    }
                  "
                  width="240"
                  class="capitalize"
                >
                  {{ $t("workingTimes.save") }}
                </VBtn>
              </div>
            </div>
          </VCard>
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.main-card ::-webkit-scrollbar {
  display: none !important;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
