<script setup lang="ts">
import {
  ShiftCalendarServiceItemDto,
  ShiftCalendarEmployeeItemDto,
} from "@/api/workingTime/dto";
import Page from "@/components/Page.vue";
import Loading from "@/components/shared/Loading.vue";
import { useDateTime } from "@/composables/useDateTime";
import { useTimeSlotsStore } from "@/stores/WorkingTimes";
import Spa from "@/assets/images/svg/spa-active.svg";
import ShiftCalenderServiceCard from "@/components/timeslots/ShiftCalenderServiceCard.vue";
import ShiftCalendarEmployeeCard from "@/components/timeslots/ShiftCalendarEmployeeCard.vue";
import { useI18n } from "vue-i18n";
const showCard = ref(false);
const { t } = useI18n();
const { reformatDate } = useDateTime();
const store = useTimeSlotsStore();
const { timeSlotsEmployeesList, timeSlotsServicesList } = storeToRefs(store);
const { date } = storeToRefs(store);
const isOpend = ref(false);
watch(date, () => {
  showCard.value = true;
  timeSlotsEmployeesList.value = [];
  timeSlotsServicesList.value = [];
  store.getShiftCaldendarServices({ day: reformatDate(date.value) });
  store.getShiftCaldendarEmployees({ day: reformatDate(date.value) });
});
</script>
<template>
  <Page>
    <template #body>
      <div class="capitalize lg:px-20 pt-14 grid grid-cols-1 lg:grid-cols-6 gap-8">
        <div class="lg:col-span-2 sticky flex justify-start flex-col items-center">
          <div class="sticky">
            <p class="text-[20px] text-black font-normal">
              {{ $t("workingTimes.manageYourWorkingTimes") }}
            </p>
            <div class="sh-date-picker">
              <AppDateTimePicker
                v-model="date"
                label="Inline"
                multiple
                :config="{ inline: true }"
                class="calendar-date-picker w-full"
              />
            </div>
          </div>
        </div>
        <div class="lg:col-span-4 grid">
          <VCard class="p-5 rounded-lg" v-if="showCard">
            <p class="text-[20px] text-black">{{ date }}</p>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div class="">
                <h2>{{ $t("workingTimes.services") }}</h2>
                <div class="relative" v-if="timeSlotsServicesList.length === 0">
                  {{ $t("workingTimes.loading") }}
                </div>
                <ShiftCalenderServiceCard
                  v-else
                  v-for="(service, index) in timeSlotsServicesList"
                  :item="service"
                  :index="index"
                />
              </div>
              <div>
                <h2>{{ $t("workingTimes.employees") }}</h2>

                <div class="relative" v-if="timeSlotsEmployeesList.length === 0">
                  {{ $t("workingTimes.loading") }}
                </div>
                <ShiftCalendarEmployeeCard
                  v-else
                  v-for="(employee, index) in timeSlotsEmployeesList"
                  :index="index"
                  :item="employee"
                />
              </div>
            </div>
          </VCard>
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.sh-date-picker .v-input--horizontal {
  display: none !important;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
