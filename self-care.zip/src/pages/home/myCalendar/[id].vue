<script setup lang="ts">
import Page from "@/components/Page.vue";
import { useServiceStore } from "@/stores/Service";
import { useI18n } from "vue-i18n";
import { requiredValidator, regexValidator } from "@validators";
import CalendarSidebar from "@/components/myCalendar/CalendarSidebar.vue";
import { MainServiceDto } from "@/api/service/dto";
import { useAppStore } from "@/stores/App";
const serviceStore = useServiceStore();
const appStore = useAppStore();
const { locale } = useI18n();
const { servicesList, appointMentDto } = storeToRefs(serviceStore);
const router = useRouter();
const ksaRegex = /^((\+|00)966)?(5)([0-9]{8})$/;
const route = useRoute();
const { t } = useI18n();
const myForm = ref(null);
const id = route.params["id"];
onMounted(() => {
  serviceStore.getServicesList();
});
const errors = ref<Record<string, string | undefined>>({
  mobile: undefined,
  name: undefined,
  date: undefined,
  service_ids: undefined,
  employee_ids: undefined,
});
const serviceId = ref(null);
const empId = ref(null);
const getTimeSlots = (index: number) => {
  if (
    appointMentDto.value.service_ids[index] &&
    appointMentDto.value.employee_ids[index] &&
    appointMentDto.value.date !== ""
  ) {
    serviceStore.getServicesByEmployeeAndTimeSlot(
      appointMentDto.value.service_ids[index],
      appointMentDto.value.employee_ids[index],
      index
    );
  }
};
const addingNewService = () => {
  appointMentDto.value.service_ids = [...appointMentDto.value.service_ids, 0];
  appointMentDto.value.employee_ids = [...appointMentDto.value.employee_ids, 0];
  appointMentDto.value.services.push(new MainServiceDto());
  appointMentDto.value.employees = [...appointMentDto.value.employees, []];
};
const serviceChangEvent = (index: number) => {
  serviceStore.getServiceEmployees(appointMentDto.value.service_ids[index], index);
};
const gender = ref("male");
const submit = () => {
  myForm?.value.validate().then((valid: any) => {
    if (valid.valid) {
      appStore.openSidebar();
    }
  });
};
watch(serviceStore, () => {
  watch(appointMentDto.value.service_ids, () => {
    if (appointMentDto.value.service_ids.length > 0) {
      for (var i = 0; i < appointMentDto.value.service_ids.length; i++) {
        serviceStore.getServiceEmployees(appointMentDto.value.service_ids[i], i);
      }
      watch(appointMentDto.value.employee_ids, () => {
        for (var i = 0; i < appointMentDto.value.service_ids.length; i++) {
          serviceStore.getServicesByEmployeeAndTimeSlot(
            appointMentDto.value.service_ids[i],
            appointMentDto.value.employee_ids[i],
            i
          );
        }
      });
    }
  });
});

const removeServiceItemFromServicesList = (index: number) => {
  appointMentDto.value.service_ids = appointMentDto.value.service_ids.filter((v, i) => {
    return i !== index;
  });
  appointMentDto.value.employee_ids = appointMentDto.value.employee_ids.filter((v, i) => {
    return i !== index;
  });
  appointMentDto.value.services = appointMentDto.value.services.filter((v, i) => {
    return i !== index;
  });
  appointMentDto.value.employees = appointMentDto.value.employees.filter((v, i) => {
    return i !== index;
  });
};
</script>
<template>
  <Page>
    <template #sidebar>
      <CalendarSidebar />
    </template>
    <template #body>
      <VForm ref="myForm" class="lg:px-14 pt-20 capitalize">
        <div class="w-full grid grid-cols-1 gap-10 lg:grid-cols-3">
          <!--- column  1-->
          <div class="lg:px-10 flex justify-start gap-5 flex-col">
            <div>
              <label class="text-lg mb-2" for="">{{
                $t("myCalendar.customerName")
              }}</label>
              <VTextField
                :rules="[requiredValidator]"
                v-model="appointMentDto.customer_name"
                :error-messages="errors.name"
                placeholder="Enter customer name "
              />
            </div>
            <div>
              <label class="text-lg mb-2" for="">{{
                $t("myCalendar.customerPhone")
              }}</label>
              <VTextField
                :rules="[requiredValidator]"
                v-model="appointMentDto.customer_phone"
                :error-messages="errors.mobile"
                placeholder="Enter customer phone "
              />
            </div>
            <label class="text-lg mb-2" for="">{{
              $t("myCalendar.customerGender")
            }}</label>

            <div class="flex justify-start items-center gap-5 mt-5">
              <VBtn
                :variant="gender === 'male' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="gender = 'male'"
                >{{ $t("myCalendar.male") }}</VBtn
              >
              <VBtn
                :variant="gender === 'female' ? 'tonal' : 'outlined'"
                color="primary"
                class="capitalize rounded-full"
                @click="gender = 'female'"
                >{{ t("myCalendar.female") }}</VBtn
              >
            </div>
          </div>
          <!-- column 2-->
          <div class="lg:col-span-2 border-left lg:px-20">
            <VCard class="flex justify-start flex-col gap-5 px-5 py-6">
              <div class="grid lg:grid-cols-2 lg:gap-10 g grid-cols-1">
                <div>
                  <label class="text-lg mb-2" for=""> {{ $t("myCalendar.date") }}</label>
                  <AppDateTimePicker
                    :rules="[requiredValidator]"
                    :error-messages="errors.date"
                    v-model="appointMentDto.date"
                  />
                </div>
              </div>
              <!-- services ....-->
              <div
                v-if="appointMentDto.date !== ''"
                class="services relative"
                v-for="(appointment, index) in appointMentDto.service_ids"
              >
                <VBtn
                  @click="removeServiceItemFromServicesList(index)"
                  variant="text"
                  class="absolute right-0 top-[-14px]"
                  ><VIcon>mdi-close</VIcon></VBtn
                >
                <div class="grid lg:grid-cols-2 gap-5 mb-5 lg:gap-10 grid-cols-1">
                  <div>
                    <label class="text-lg mb-2" for=""> Service</label>
                    <div>
                      <VSelect
                        :rules="[requiredValidator]"
                        :error-messages="errors.service_ids"
                        :items="servicesList"
                        :item-title="locale === 'ar' ? 'title.ar' : 'title.en'"
                        item-value="id"
                        v-model="appointMentDto.service_ids[index]"
                      />
                    </div>
                  </div>
                  <div>
                    <label class="text-lg mb-2" for="">
                      {{ $t("myCalendar.employee") }}</label
                    >
                    <div>
                      <VSelect
                        :rules="[requiredValidator]"
                        :error-messages="errors.employee_ids"
                        v-model="appointMentDto.employee_ids[index]"
                        :items="appointMentDto.employees[index]"
                        :item-title="locale === 'ar' ? 'name__ml.ar' : 'name__ml.en'"
                        item-value="id"
                      />
                    </div>
                  </div>
                </div>
                <!-- <div v-if="appointMentDto.service_ids.length > 0">
                  <div v-if="appointMentDto.timeSlots[index].length > 0">
                    <label class="text-lg mb-2" for="">
                      {{ $t("myCalendar.availableTime") }}</label
                    >
                    <div>
                      <p class="text-gray-400">at store</p>
                      <div
                        class="flex justify-start items-center flex-row flex-wrap gap-4"
                      >
                        <div v-for="timeSlot in appointMentDto.timeSlots[index]">
                          <VBtn
                            v-if="timeSlot.location === 'store'"
                            size="small"
                            @click="
                              () => {
                                appointMentDto.atStore = true;
                                appointMentDto.timeSlots_ext_ids[index] = [timeSlot.id];
                              }
                            "
                            :color="
                              serviceStore.checkIfTimeSlotIsFound(timeSlot.id, index)
                                ? 'primary'
                                : 'success'
                            "
                            >{{ timeSlot.from_time }}</VBtn
                          >
                        </div>
                      </div>
                    </div>
                    <div>
                      <p class="text-gray-400">{{ $t("myCalendar.availableTime") }}</p>
                      <div
                        class="mx-9 flex justify-start items-center flex-row flex-wrap gap-4"
                      >
                        <div v-for="timeSlot in appointMentDto.timeSlots[index]">
                          <VBtn
                            v-if="timeSlot.location === 'home'"
                            size="small"
                            @click="
                              () => {
                                appointMentDto.atStore = true;
                                appointMentDto.timeslot_ids = [timeSlot.id];
                              }
                            "
                            :color="
                              serviceStore.checkIfTimeSlotIsFound(timeSlot.id, index)
                                ? 'primary'
                                : 'success'
                            "
                            >{{ timeSlot.from_time }}</VBtn
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                  <div v-else>
                    <p>{{ $t("myCalendar.noDataAvailable") }}</p>
                  </div>
                </div> -->
              </div>
              <div class="mt-5 w-full flex justify-end items-center">
                <VBtn @click="addingNewService()" class="capitalize" variant="text"
                  ><VIcon>mdi-plus</VIcon> add service</VBtn
                >
              </div>
            </VCard>
          </div>
        </div>
      </VForm>
      <div class="my-10 flex justify-center items-center">
        <VBtn @click="submit()" heigh="46" width="200" class="capitalize"
          >Add Appointment</VBtn
        >
      </div>
    </template>
  </Page>
</template>
<style scoped>
.border-left {
  position: relative;
}
.border-left::before {
  content: "";
  width: 1px;
  background: #000;
  height: 400px;
  position: absolute;
  top: 60px;
  left: 10px;
  display: block;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: false
</route>
