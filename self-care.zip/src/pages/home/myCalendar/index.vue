<script setup lang="ts">
import Page from "@/components/Page.vue";
import CalendarOrder from "@/components/myCalendar/CalenderOrder.vue";
import { useCalnedarStore } from "@/stores/Calendar";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const { appointmentList, date } = storeToRefs(useCalnedarStore());
</script>
<template>
  <Page>
    <template #body>
      <div class="pt-10 lg:px-20 w-full gap-8 capitalize">
        <div class="grid grid-cols-1 lg:grid-cols-3">
          <div class="col-span-1">
            <p class="text-[20px] text-black mt-3">
              {{ $t("myCalendar.manageYourAppointmentsCalendar") }}
            </p>
            <div class="dd-picker flex items-center justify-start md:justify-start">
              <AppDateTimePicker
                v-model="date"
                label="Inline"
                multiple
                :config="{ inline: true }"
                class="calendar-date-picker w-full"
              />
            </div>
          </div>
          <div
            v-if="appointmentList.length > 0"
            class="flex-col col-span-2 border-left flex justify-start px-10"
          >
            <!-- <VCard class="lg:w-[90%] w-full min-h-[400px]"></VCard> -->

            <p class="text-[20px] text-black mt-3">
              {{ $t("myCalendar.allAppointments") }}
            </p>
            <div
              class="calendars-container flex flex-col justify-start gap-3 overflow-y-scroll max-h-[390px]"
            >
              <div class="w-[400px]" v-for="item in appointmentList">
                <CalendarOrder />
              </div>
            </div>
          </div>
        </div>

        <!-- last div-->
      </div>
      <div class="w-full justify-center flex mt-10 items-center">
        <RouterLink to="mycalendar/new">
          <VBtn width="200" height="46" class="capitalize">{{
            $t("myCalendar.addAppointment")
          }}</VBtn>
        </RouterLink>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.border-left {
  border-left: 1px solid #000 !important;
}
.dd-picker .v-input--horizontal {
  display: none !important;
}
::-webkit-scrollbar {
  display: none !important;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
