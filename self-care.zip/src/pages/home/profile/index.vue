<script setup lang="ts">
import Page from "@/components/Page.vue";
import { useProfileStore } from "@/stores/Profile";
import Avatar from "@/assets/images/avatars/avatar-1.png";
import { useFile } from "@/composables";
import { useStoresStore } from "@/stores/Store";
import { useToast } from "vue-toastification";
import { useI18n } from "vue-i18n";

import Loading from "@/components/shared/Loading.vue";
import {
  emailValidator,
  confirmedValidator,
  requiredValidator,
  regexValidator,
} from "@validators";
import FileBtn from "@/components/shared/FileBtn.vue";
const ksaRegex = /^((\+|00)966)?(5)([0-9]{8})$/;
const toast = useToast();
const profileForm = ref(null);
const storeForm = ref(null);

const readonly = ref(true);
const { getFileUrl } = useFile();
const stores = useStoresStore();
const {
  storesList,
  storeDto,
  categoriesList,
  loading,
  selectedStoreId,
  categories_ids,
} = storeToRefs(stores);
const store = useProfileStore();
const { profileDto } = storeToRefs(store);
const { t, locale } = useI18n();
const profileEditMode = ref(false);
const storeEditMode = ref(false);
const profileActionButtonEvent = () => {
  if (categories_ids.value.length === 0) {
    toast.warning(t("profile.oneCatAtLeast"), { timeout: 10000 });
  } else {
    profileForm.value?.validate().then((vv: any) => {
      if (vv.valid) {
        store.updateProfile(true);
      }
    });
    storeForm.value?.validate().then((vv: any) => {
      if (vv.valid) {
        stores.updateStore(true);
      }
    });
  }
};
const selectStoreEvt = (id: any) => {
  stores.getStoreById(id);
};

onMounted(() => {
  stores.getCategoriesList();
  store.showProfile();
  stores.getStoresList();
});

const errors = ref<Record<string, string | undefined>>({
  email: undefined,
  phone: undefined,
  full_name: undefined,
  last_name: undefined,
});
const storeErrors = ref<Record<string, string | undefined>>({
  cr: undefined,
  bank: undefined,
  title_en: undefined,
  bank_name: undefined,
  title_ar: undefined,
  commercial_registeration_file: undefined,
  reciver_name: undefined,
});
function previewProfileImage(event: any, id: string) {
  const input = event.target;
  if (id === "preview") {
  } else {
    storeEditMode.value = true;
  }
  if (input.files && input.files[0]) {
    const reader = new FileReader();

    reader.onload = function (e) {
      const previewImg = document.getElementById(id);
      previewImg.style.display = "block";
      previewImg.src = e.target.result;
    };

    reader.readAsDataURL(input.files[0]);
  }
}

const discareProfileImageChanging = () => {
  const previewImg = document.getElementById("preview");
  profileDto.value.image = profileDto.value.oldImage;
  previewImg.src = getFileUrl(profileDto.value.image);
};
const discareStoreImageChanging = () => {
  const previewImg = document.getElementById("storePreview");
  storeDto.value.logoFile = storeDto.value.oldLogo;
  previewImg.src = getFileUrl(storeDto.value.logo);
  storeEditMode.value = false;
};
const handleIfItIsPublished = (category: any) => {
  console.log(stores.checkIfCategoryIsPublished(category.id));

  if (stores.checkIfCategoryIsPublished(category.id)) {
    if (
      stores.checkIfCategoryIsPublished(category.id) ||
      stores.checkIfCategoryIsFound(category.id)
    ) {
      return true;
    } else {
      return false;
    }
  } else {
    if (stores.checkIfCategoryIsFound(category.id)) {
      return true;
    } else {
      return false;
    }
  }
};
watch(selectedStoreId, () => {
  stores.getStoreById(selectedStoreId.value);
});
</script>

<template>
  <Page>
    <template #action-button>
      <div>
        <VBtn @click="profileActionButtonEvent">{{ $t("workingTimes.save") }}</VBtn>
      </div>
    </template>
    <template #body>
      <div v-if="loading">
        <Loading />
      </div>

      <div v-else>
        <div class="h-full capitalize w-full grid grid-cols-1 lg:grid-cols-2 lg:gap-8">
          <div class="flex h-[600px] flex-col justify-center items-center lg:pl-20">
            <VForm ref="profileForm" class="flex flex-col gap-3 w-[400px]">
              <div class="relative flex justify-center items-center h-full">
                <div v-if="typeof profileDto.image !== 'string'" class="absolute">
                  <VBtn @click="discareProfileImageChanging()" flat variant="text"
                    ><VIcon>mdi-close</VIcon></VBtn
                  >
                </div>
                <img
                  class="w-[120px] h-[120px] object-cover rounded-full"
                  :src="getFileUrl(profileDto?.oldImage ?? '')"
                  alt=""
                  id="preview"
                />

                <div class="f-picker z-10">
                  <FileBtn
                    @change="(e:any) => {
                    
                      profileDto.image=e.target.files[0]
                    previewProfileImage(e,'preview')
                    }"
                    :disabled="readonly"
                    icon="mdi-pen"
                    class="rounded-full absolute w-0 bottom-0 right-16"
                  />
                </div>
              </div>
              <p class="text-xl">{{ $t("profile.ownerInfo") }}</p>
              <VTextField
                v-model="profileDto.first_name"
                :rules="[requiredValidator]"
                :error-messages="errors.first_name"
                :label="$t('profile.first_name')"
              />
              <VTextField
                v-model="profileDto.last_name"
                :rules="[requiredValidator]"
                :error-messages="errors.last_name"
                :label="$t('profile.last_name')"
              />
              <VTextField
                :rules="[requiredValidator, regexValidator(profileDto.mobile, ksaRegex)]"
                :error-messages="errors.phone"
                v-model="profileDto.mobile"
                :label="$t('profile.mobile')"
              />
              <VTextField
                v-model="profileDto.email"
                :rules="[requiredValidator, emailValidator]"
                :error-messages="errors.email"
                :label="$t('profile.email')"
              />
            </VForm>
          </div>
          <div
            class="border-left class grid lg:grid-cols-4 px-5 pb-3 grid-cols-1 justify-start gap-5 lg:px-20"
          >
            <VForm ref="storeForm" class="lg:col-span-2 flex flex-col gap-3 lg:mt-14">
              <div>
                <VSelect
                  v-model="selectedStoreId"
                  :item-title="locale === 'ar' ? 'title.ar' : 'title.en'"
                  item-value="id"
                  :items="storesList"
                  :label="$t('profile.selectStore')"
                >
                </VSelect>
              </div>
              <div class="bg-orange-200 w-full h-[130px] relative overflow-hidden">
                <div v-if="storeDto.logoFile" class="absolute">
                  <VBtn @click="discareStoreImageChanging()" flat variant="text"
                    ><VIcon>mdi-close</VIcon></VBtn
                  >
                </div>
                <img
                  class="w-full h-full object-cover"
                  id="storePreview"
                  :src="getFileUrl(storeDto.logo)"
                  alt=""
                />
                <div class="f-picker z-10">
                  <FileBtn
                    @change="(e:any) =>{
                      storeDto.logoFile=e.target.files[0]
                     storeEditMode=true
                      previewProfileImage(e,'storePreview')}"
                    :disabled="readonly"
                    icon="mdi-pen"
                    class="rounded-full absolute w-0 bottom-0 right-16"
                  />
                </div>
              </div>
              <p class="text-xl">{{ $t("profile.storeInfo") }}</p>
              <VTextField
                :rules="[requiredValidator]"
                :error-messages="storeErrors.title_en"
                v-model="storeDto.title.en"
                :label="$t('profile.title_en')"
              />
              <VTextField
                :rules="[requiredValidator]"
                v-model="storeDto.title.ar"
                :error-messages="storeErrors.title_ar"
                :label="$t('profile.title_ar')"
              />
              <!-- <VSelect
                v-model="storeDto.categories"
                :multiple="true"
                :items="categoriesList"
                :item-title="locale === 'ar' ? 'title__ml.ar' : 'title__ml.en'"
                item-value="id"
                :label="$t('profile.categories')"
              /> -->
              <div class="flex justify-start items-center gap-5">
                <div v-for="category in categoriesList">
                  <VBtn
                    @click="
                      () => {
                        stores.addCategory(category.id);
                        stores.handleCategory(category.id);
                      }
                    "
                    class="h-[80px]"
                    height="110px"
                    width="110px"
                    :variant="handleIfItIsPublished(category) ? 'tonal' : 'outlined'"
                    :color="handleIfItIsPublished(category) ? 'primary' : 'gray-400'"
                  >
                    <div class="flex justify-center items-center flex-col">
                      <img
                        class="w-[60px] h-[30px] object-cover mb-5"
                        :src="getFileUrl(category.icon_path ?? '')"
                        alt=""
                      />
                      <span class="text-wrap capitalize">
                        {{
                          locale === "en" ? category.title__ml.en : category.title__ml.ar
                        }}</span
                      >
                    </div>
                  </VBtn>
                </div>
              </div>
              <VFileInput
                :rules="[requiredValidator]"
                :error-messages="storeErrors.commercial_registeration_file"
                v-model="storeDto.cr_file"
                prepend-icon=""
                max-files="1"
                class="fileUploaderCR"
                append-inner-icon="mdi-document"
                :label="$t('signup.crDoc')"
              />
              <VTextField
                :rules="[requiredValidator]"
                :error-messages="storeErrors.cr"
                v-model="storeDto.commercial_registeration"
                :label="$t('profile.commercial_registeration')"
              />
              <div class="mt-10">
                <p class="">{{ $t("signup.payType") }}</p>
                <VRadioGroup v-model="storeDto.prefered_payment_method">
                  <div class="flex justify-start gap-10">
                    <VRadio value="stc" :label="$t('signup.stc')" />
                    <VRadio value="bank_account" :label="$t('signup.bank')" />
                  </div>
                </VRadioGroup>
              </div>
              <div
                v-if="storeDto.prefered_payment_method === 'stc'"
                class="mt-4 grid grid-cols-1 lg:gap-20"
              >
                <VTextField
                  :rules="[requiredValidator]"
                  :error-messages="storeErrors.bank"
                  v-model="storeDto.stc_phone_number"
                  :label="$t('signup.stcNum')"
                />
              </div>
              <div class="mt-4 grid grid-cols-1 lg:gap-x-20 gap-y-8" v-else>
                <VTextField
                  :rules="[requiredValidator]"
                  :error-messages="storeErrors.bank_name"
                  v-model="storeDto.bank_name"
                  :label="$t('signup.bankName')"
                />
                <VTextField
                  :rules="[requiredValidator]"
                  :error-messages="storeErrors.bank"
                  v-model="storeDto.iban"
                  :label="$t('signup.iban')"
                />

                <VTextField
                  :rules="[requiredValidator]"
                  :error-messages="storeErrors.reciver_name"
                  v-model="storeDto.receiver_name"
                  :label="$t('signup.reciverName')"
                />
              </div>
              <!-- <VTextField v-model="storeDto.status" :label="$t('profile.location')" /> -->
            </VForm>
          </div>
        </div>
      </div>
    </template>
  </Page>
</template>

<style scoped>
.border-left {
  border-left: 1px solid black;
}
.f-picker .v-icon {
  padding: 4px !important;
  border-radius: 100% !important;
  color: white !important;
  background: orange;
  border: 3px solid white;
  display: flex;
  justify-content: center;
  align-items: center;
}
.f-picker .v-field__input {
  display: none !important;
}
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
