<script setup lang="ts">
import Page from "@/components/Page.vue";
import Contact from "@/components/ContactUs.vue";
</script>

<template>
  <Page>
    <template #body>
      <Contact />
    </template>
  </Page>
</template>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: false
</route>
