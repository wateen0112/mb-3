<script setup lang="ts">
import Page from "@/components/Page.vue";
import About from "@/components/About.vue";
</script>
<template>
  <Page>
    <template #body>
      <About />
    </template>
  </Page>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
