<script setup lang="ts">
import Terms from "@/components/Terms.vue";
import Page from "@/components/Page.vue";
</script>
<template>
  <Page>
    <template #body>
      <Terms />
    </template>
  </Page>
</template>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: false
</route>
