<script setup lang="ts">
import Page from "@/components/Page.vue";
import Employee from "@/components/myemployees/Employee.vue";
import { useEmployeeStore } from "@/stores/Employee";
import Loading from "@/components/shared/Loading.vue";
import { useAppStore } from "@/stores/App";
import { useScreen } from "@/composables/useScreen";
import { useI18n } from "vue-i18n";
const appStore = useAppStore();
const { t } = useI18n();
const store = useEmployeeStore();
const { screenSize } = useScreen();
const idToDelete = ref(0);
const deleteItems = ref(false);
const { employeesList, perPage, total, page, AllPages, isLoading } = storeToRefs(store);

onMounted(() => {
  store.getEmployeesList();
});
</script>
<template>
  <Page>
    <template #action-button>
      <VBtn
        v-if="deleteItems && screenSize === 'sm'"
        @click="appStore.openModal()"
        class="capitalize"
        variant="text"
      >
        <VIcon size="30">mdi-delete</VIcon>
      </VBtn>
      <VBtn
        v-if="deleteItems && screenSize !== 'sm'"
        @click="appStore.openModal()"
        class="capitalize"
      >
        {{ $t("myEmployees.deleteEmployee") }}
      </VBtn>
      <div v-if="!deleteItems">
        <RouterLink v-if="screenSize === 'sm'" to="myemployees/new">
          <VBtn variant="text" height="50" width="0" class="capitalize"
            ><VIcon size="30">mdi-plus</VIcon>
          </VBtn></RouterLink
        >
        <RouterLink v-else to="myemployees/new">
          <VBtn class="capitalize"> {{ $t("myEmployees.addEmployee") }}</VBtn></RouterLink
        >
      </div>
    </template>
    <template #modal>
      <div class="p-3 max-w-[400px] flex flex-col gap-8">
        <div class="px-5">
          <p class="text-xl text-center">
            {{ $t("myEmployees.confirmDelete") }}
          </p>
        </div>
        <div class="flex flex-col justify-center items-center gap-5 my-3 w-full">
          <VBtn
            :loading="isLoading"
            @click="
              store.deleteEmployee(idToDelete).then(() => {
                appStore.closeModal();
              })
            "
            class="capitalize"
            width="350"
            height="46"
          >
            {{ $t("myEmployees.delete") }}
          </VBtn>
          <VBtn
            @click="appStore.closeModal()"
            variant="outlined"
            class="capitalize"
            width="350"
            height="46"
          >
            {{ $t("myEmployees.cancel") }}
          </VBtn>
        </div>
      </div>
    </template>

    <template #body>
      <div class="overflow-hidden pt-10 sub-accounts px-5">
        <div
          class="lg:px-20 max-h-[560px] pt-20 pb-2 gap-y-8 overflow-y-scroll grid lg:grid-cols-5 gap-x-8 grid-cols-1"
        >
          <div v-if="employeesList.length === 0">
            <Loading />
          </div>
          <div
            v-else
            class="col-span-2 flex justify-center lg:gap-8 items-center"
            v-for="item in employeesList"
          >
            <VCheckbox
              v-if="deleteItems"
              :value="item.id"
              :multiple="false"
              v-model="idToDelete"
            />
            <Employee @click="store.getEmployeeById(item.id)" :user="item" />
          </div>
        </div>
        <div @click="deleteItems = !deleteItems" class="w-full flex justify-end pt-2">
          <VBtn variant="text"
            ><span class="z-40 text-md capitalize text-error"
              >{{
                deleteItems ? $t("myEmployees.cancel") : $t("myEmployees.deleteEmployee")
              }}
            </span></VBtn
          >
        </div>
        <div class="pt-5 fixed bottom-5 left-0 w-full flex justify-center items-center">
          <VPagination
            v-if="total > perPage"
            v-model="page"
            :total-visible="6"
            :length="AllPages"
          />
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.sub-accounts ::-webkit-scrollbar {
  display: none !important;
}
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
