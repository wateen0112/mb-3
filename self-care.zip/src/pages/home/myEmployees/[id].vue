<script setup lang="ts">
import Page from "@/components/Page.vue";
import Service from "@/components/myemployees/Service.vue";
import Permission from "@/components/subAccount/PermissionItem.vue";
import { useEmployeeStore } from "@/stores/Employee";
import { useSubAccountStore } from "@/stores/SubAccount";
import { useServiceStore } from "@/stores/Service";
import { requiredValidator, regexValidator } from "@validators";
import Loading from "@/components/shared/Loading.vue";
import RangeInput from "@/components/shared/RangeInput.vue";
import router from "@/router";
import { usePermissionStore } from "@/stores/Permission";
import { EmployeeDto, Workinghour } from "@/api/employee/dto";
import { useI18n } from "vue-i18n";
const ksaRegex = /^((\+|00)966)?(5)([0-9]{8})$/;
const props = defineProps(["id"]);
const errors = ref<Record<string, string | undefined>>({
  mobile: undefined,
  ar: undefined,
  en: undefined,
});
const store = useEmployeeStore();
const permissionsStore = useSubAccountStore();
const { employeeDto, servicesList, location } = storeToRefs(store);
const { permissionsList, permissiontsLoading, isLoading } = storeToRefs(permissionsStore);
const myForm = ref(null);
const { t } = useI18n();
const { persmissionsIds } = storeToRefs(usePermissionStore());
const actionButtonClickEvent = () => {
  myForm.value.validate().then((valid: any) => {
    if (valid.valid) {
      if (props.id === "new") {
        store.createEmployee();
      } else {
        store.updateEmployee();
      }
    }
  });
};
onMounted(() => {
  store.getPermissionsAndServices();
  if (props.id !== "new") {
    if (props.id === 0) {
      router.go(-1);
    }
    
  } else {
    employeeDto.value = new EmployeeDto();
    persmissionsIds.value = [];
  }
});
</script>
<template>
  <Page>
    <template #action-button>
      <VBtn :loading="isLoading" class="capitalize" @click="actionButtonClickEvent()"
        >{{ id === "new" ? $t("myEmployees.add") : $t("myEmployees.saveAndUpdate") }}
      </VBtn>
    </template>
    <template #body>
      <div class="pt-20 lg:px-20 capitalize">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <VForm ref="myForm">
            <div class="px-5">
              <p>{{ $t("myEmployees.empNameEn") }}</p>
              <VTextField
                :rules="[requiredValidator]"
                :error-messages="errors.en"
                v-model="employeeDto.name.en"
                class="w-[400px]"
                placeholder="name"
              />
            </div>
            <div class="px-5 mt-5">
              <p>{{ $t("myEmployees.empNameAr") }}</p>
              <VTextField
                :rules="[requiredValidator]"
                :error-messages="errors.ar"
                v-model="employeeDto.name.ar"
                class="w-[400px]"
                placeholder="name"
              />
            </div>
            <div class="px-5 mt-5">
              <p>{{ $t("myEmployees.phone") }}</p>
              <VTextField
                :rules="[requiredValidator, regexValidator(employeeDto.mobile, ksaRegex)]"
                :error-messages="errors.mobile"
                v-model="employeeDto.mobile"
                class="w-[400px]"
                placeholder="+966 - "
              />
            </div>
          </VForm>
          <!--second colummn -->
          <div>
            <h3 class="font-normal mb-3">{{ $t("myEmployees.workingHours") }}</h3>
            <RangeInput
              :id="index"
              v-for="(shift, index) in employeeDto.working_hours"
              v-model:max-value="employeeDto.working_hours[index].to"
              v-model:min-value="employeeDto.working_hours[index].from"
              class="px-20"
            />
            <div class="flex justify-end items-center mt-5">
              <VBtn
                @click="
                  employeeDto.working_hours = [
                    ...employeeDto.working_hours,
                    new Workinghour(),
                  ]
                "
                class="capitalize"
                variant="text"
                ><VIcon>mdi-plus</VIcon>{{ $t("myEmployees.addShift") }}</VBtn
              >
            </div>
          </div>
        </div>
        <!-- work place container -->
        <div class="px-5 mt-5">
          <p>{{ $t("myEmployees.selectServiceLocation") }}</p>

          <div class="flex justify-start items-center gap-8">
            <VBtn
              @click="employeeDto.location[0].home = !employeeDto.location[0].home"
              :variant="employeeDto.location[0].home ? 'tonal' : 'outlined'"
              class="capitalize rounded-full"
            >
              {{ $t("myEmployees.atHome") }}
              <VIcon size="24" icon="tabler:home" />
            </VBtn>

            <VBtn
              @click="employeeDto.location[1].store = !employeeDto.location[1].store"
              :variant="employeeDto.location[1].store ? 'tonal' : 'outlined'"
              class="capitalize rounded-full"
            >
              {{ $t("myEmployees.atStore") }}<VIcon size="24" icon="mdi-store" />
            </VBtn>
          </div>
        </div>
        <!-- serveices container -->
        <div class="px-5">
          <p class="my-5">{{ $t("myEmployees.selectService") }}</p>
          <div class="flex justify-start items-center gap-8">
            <Service v-for="service in servicesList" :service="service" />
          </div>
        </div>
        <div class="px-5 mt-5">
          <VCheckbox
            v-model="employeeDto.is_sub_account"
            :label="$t('myEmployees.addAsSubAccount')"
          />
        </div>
        <div class="px-5 mb-5" v-if="employeeDto.is_sub_account">
          <p class="my-5">{{ $t("myEmployees.permissions") }}</p>
          <div class="flex min-h-[400px] w-full" v-if="permissiontsLoading">
            <Loading />
          </div>
          <div
            v-else
            class="flex justify-start flex-wrap lg:flex-row flex-col lg:items-center gap-8"
          >
            <Permission v-for="permission in permissionsList" :permission="permission" />
          </div>
        </div>
      </div>
    </template>
  </Page>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
