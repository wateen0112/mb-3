<script setup lang="ts">
import Orders from "@/components/profile/myOrders/Orders.vue";
import BtnTab from "@/components/shared/BtnTab.vue";
import Page from "@/components/Page.vue";
import Warning from "@/assets/images/svg/warning.svg";
import { useOrderStore } from "@/stores/Order";
import { requiredValidator } from "@validators";
import { useServiceStore } from "@/stores/Service";
import { MainServiceDto, Service } from "@/api/service/dto";
import { useAppStore } from "@/stores/App";
import OrderSidebar from "@/components/profile/myOrders/OrderSidebar.vue";
import { OREDER_STATUS } from "@/enums/OrderStatus";
import { useI18n } from "vue-i18n";
const appStore = useAppStore();
const { locale } = useI18n();
const service_ids = ref<MainServiceDto[]>([]);
const serviceStore = useServiceStore();
const { servicesList } = storeToRefs(serviceStore);
const { sidebarOpend } = storeToRefs(appStore);
const store = useOrderStore();
const {
  changeOrderDto,
  servicesToBeAdded,
  editMode,
  order,
  ordersList,
  confirm,
} = storeToRefs(store);
const tab = ref("all");
const errors = ref<Record<string, string | undefined>>({
  reason: undefined,
});
const servicePlaceAthome = ref("true");
const modalForm = ref(null);
const modalSubmit = () => {
  modalForm.value.validate().then((valid: any) => {
    if (valid.valid) {
      changeOrderDto.value.status = OREDER_STATUS.NOSHOW;
      store.changeStatus().then(() => {
        appStore.closeModal();
      });
    }
  });
};
const addServicesEvent = () => {
  servicesToBeAdded.value.forEach((service: MainServiceDto) => {
    order.value.total_price =
      order.value.total_price +
      parseInt(service.location[0].male_price ?? service.location[1].male_price ?? 0);
  });
  appStore.closeModal();
  appStore.openSidebar();
};
const discareChanges = () => {
  servicesToBeAdded.value = [];
  editMode.value = false;
  appStore.closeModal();
};
watch(tab, () => {
  ordersList.value = [];
  store.getOrdersList(tab.value);
});
onMounted(() => {
  store.getOrdersList(tab.value);
});
</script>
<template>
  <Page :inner="true">
    <template #modal>
      <div class="p-5 w-[400px]" v-if="confirm && editMode">
        <div class="w-full flex flex-col justify-center items-center">
          <img :src="Warning" alt="" />
          <h2 class="text-center mt-10 px-5">
            by going back all changes will be discarded
          </h2>
          <div class="flex justify-center gap-8 items-center">
            <VBtn
              width="160"
              variant="outlined"
              @click="
                () => {
                  appStore.closeModal();
                  appStore.openModal();
                }
              "
              class="capitalize"
            >
              cancel</VBtn
            >
            <VBtn width="160" class="capitalize" @click="discareChanges"> discare</VBtn>
          </div>
        </div>
      </div>
      <div v-else-if="editMode" class="w-[400px] lg:px-5 py-5">
        <div
          class="flex justify-center overflow-hidden gap-3 rounded-full border-[1px] border-solid border-[#FF9E59]"
        >
          <VBtn
            :class="{ 'pl-[150px] rounded-full': servicePlaceAthome === 'true' }"
            @click="servicePlaceAthome = 'true'"
            :variant="servicePlaceAthome ? 'elevated' : 'text'"
            >At home</VBtn
          >
          <VBtn
            :class="{ 'pr-[150px] rounded-full': servicePlaceAthome === 'false' }"
            @click="servicePlaceAthome = 'false'"
            :variant="!servicePlaceAthome ? 'elevated' : 'text'"
            >At store</VBtn
          >
        </div>
        <div v-for="service in servicesList">
          <VCard
            v-if="service.location[0].home === servicePlaceAthome"
            class="px-5 py-3 my-3"
          >
            <div class="w-full flex justify-between items-center">
              <span> {{ locale === "en" ? service.title.en : service.title.ar }}</span>
              <VCheckbox :value="service" v-model="servicesToBeAdded" :multiple="true" />
            </div>
          </VCard>
        </div>
        <div class="flex justify-center items-center mt-10">
          <VBtn
            @click="addServicesEvent()"
            height="46
          "
            width="200"
            >Done</VBtn
          >
        </div>
      </div>
      <div v-else class="lg:px-12 pb-5 capitalize">
        <div class="px-5">
          <p class="text-center text-lg">
            this message will be sent to customer for approval
          </p>
          <div class="pb-5">
            <VForm ref="modalForm">
              <VTextarea
                v-model="changeOrderDto.reason"
                :rules="[requiredValidator]"
                :error-messages="errors.reason"
                label="type here the reason for the cancelation"
                class="h-[160px]"
                :no-resize="true"
              />
            </VForm>
          </div>
          <VBtn @click="modalSubmit" class="capitalize w-full"> send </VBtn>
        </div>
      </div>
    </template>

    <template #sidebar>
      <OrderSidebar />
    </template>
    <template #body>
      <div class="lg:pt-10">
        <div class="flex justify-center items-center flex-col">
          <div :transition="false" class="order-tabs gap-3 flex flex-row">
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.all')"
              value="all"
              v-model="tab"
            />
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.accepted')"
              value="accepted"
              v-model="tab"
            />
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.running')"
              value="running"
              v-model="tab"
            />
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.complited')"
              value="complited"
              v-model="tab"
            />
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.no_show')"
              value="no_show"
              v-model="tab"
            />
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.gifts')"
              value="gifts"
              v-model="tab"
            />
            <BtnTab
              :rounded="true"
              variant="tonal"
              :content="$t('myOrders.canceled')"
              value="canceled"
              v-model="tab"
            />
          </div>
          <v-window v-model="tab" class="min-w-full">
            <v-window-item value="all"><Orders title="all" /></v-window-item>
            <v-window-item value="accepted"><Orders title="accepted" /></v-window-item>
            <v-window-item value="running"><Orders title="running" /></v-window-item>
            <v-window-item value="complited"><Orders title="complited" /></v-window-item>
            <v-window-item value="no_show"><Orders title="no_show" /></v-window-item>
            <v-window-item value="gifts"><Orders title="gifts" /></v-window-item>
            <v-window-item value="canceled"><Orders title="canceled" /></v-window-item>
          </v-window>
        </div>
      </div>
    </template>
  </Page>
</template>
<style scoped>
.order-tabs {
  display: flex;
}
.order-tabs .v-tab {
  border: 1px solid;
  margin-inline: 10px;
  border-radius: 20px !important;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
