<script setup lang="ts">
import Terms from "@/components/Terms.vue";
import Outside from "@/components/Outside.vue";
</script>
<template>
  <Outside active="terms">
    <template #body>
      <Terms />
    </template>
  </Outside>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
