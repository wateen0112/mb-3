<script setup lang="ts">
import { VNodeRenderer } from "@layouts/components/VNodeRenderer";
import { themeConfig } from "@themeConfig";
import Logo from "@/assets/images/svg/logo.svg";
import { useAuthorization } from "@/stores/Auth";
import { useAuth } from "@/composables";
import { useI18n } from "vue-i18n";
import { useLayouts } from "@/@layouts/composable/useLayouts";
const minutes = ref("03");
const seconds = ref("00");
let timer = ref(0);

const { locale, t } = useI18n();
const authStore = useAuthorization();
const router = useRouter();
const { userDto } = storeToRefs(authStore);
const { isAppRtl } = useLayouts();
const { VertifyOtp } = useAuth();
const startTimer = () => {
  const duration = 180; // 3 minutes in seconds
  timer.value = duration;

  setInterval(() => {
    if (--timer.value >= 0) {
      minutes.value = Math.floor(timer.value / 60)
        .toString()
        .padStart(2, "0");
      seconds.value = (timer.value % 60).toString().padStart(2, "0");
    }
  }, 1000);
};
const toggleLang = (lang: string) => {
  localStorage.setItem("lang", lang);
  locale.value = lang;
  isAppRtl.value = lang === "ar";
  console.log("click event", locale.value);
};
const { phone, otp } = storeToRefs(authStore);
const submit = () => {
  VertifyOtp({
    mobile: phone.value,
    otp: otp.value,
  }).then((res) => {
    userDto.value = res?.data.data;
    if (userDto.value.has_completed_profile === false) {
      router.push("signup");
    } else {
      router.push({ path: "/" });
    }
  });
};
watch(timer, () => {
  console.log(timer.value);

  if (timer.value <= 0) {
    clearInterval(timer.value);
  }
});

const resendOtp = () => {
  authStore.resendOtp().then(() => {
    startTimer();
  });
};

onMounted(() => {
  startTimer();
});

onUnmounted(() => {
  clearInterval(timer.value);
});
</script>

<template>
  <div>
    <nav class="w-full bg-primary lg:px-20 h-[50px] flex justify-end">
      <VBtn
        @click="toggleLang('ar')"
        variant="text"
        color="on-surface"
        v-if="locale == 'en'"
      >
        <VIcon class="ml-2" icon="tabler:language-katakana"></VIcon> العربية</VBtn
      >
      <VBtn variant="text" @click="toggleLang('en')" v-else color="on-surface">
        <VIcon icon="tabler:language-katakana" class="ml-2"></VIcon>Engilsh</VBtn
      >
    </nav>
    <div class="auth-wrapper d-flex align-center justify-center pa-4">
      <div class="position-relative my-sm-1 text-primary">
        <div class="auth-card pa-4 max-w-[448px]">
          <VCardItem class="justify-center">
            <template #prepend>
              <div class="d-flex"></div>
            </template>
            <img :src="Logo" alt="" />
          </VCardItem>

          <VCardText class="pt-2 text-center">
            <h5 class="text-h5 font-weight-semibold mb-1 text-primary capitalize">
              {{ $t("login.vertificationCode") }}
            </h5>
            <p class="mb-2 text-primary capitalize">
              {{ $t("login.4digits") }}
            </p>
            <h6 class="text-base font-weight-semibold text-primary">
              {{ phone }}
              <RouterLink to="/login"
                ><VBtn icon="tabler:edit" color="primary" variant="text"
              /></RouterLink>
            </h6>
          </VCardText>

          <VCardText>
            <VForm @submit.prevent="() => {}">
              <VRow>
                <VCol cols="12" justify="center" align="center">
                  <AppOtpInput v-model="otp" :total-input="4" class="" />
                </VCol>

                <VCol cols="12">
                  <VBtn block @click="submit" color="primary" type="submit" height="50px">
                    {{ $t("login.continue") }}
                  </VBtn>
                </VCol>

                <VCol cols="12">
                  <div class="d-flex justify-center align-center flex-wrap">
                    <span class="me-1"> {{ $t("login.notRecived") }}</span>

                    <p>
                      {{ minutes }}:{{ seconds }}

                      <VBtn
                        class="capitalize"
                        variant="text"
                        @click="resendOtp"
                        :disabled="timer > 0"
                      >
                        {{ $t("login.resend") }}</VBtn
                      >
                    </p>
                  </div>
                </VCol>
              </VRow>
            </VForm>
          </VCardText>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@use "@core/scss/template/pages/page-auth.scss";
</style>

<route lang="yaml">
meta:
  layout: blank
</route>
