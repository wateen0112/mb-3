<script setup lang="ts">
import Logo from "@/assets/images/svg/logo.svg";
import OrdersRequests from "@/assets/images/svg/orders-requests.svg";
import MyOrders from "@/assets/images/svg/my-orders.svg";
import Finance from "@/assets/images/svg/finance.svg";
import Mycalender from "@/assets/images/svg/my-calender.svg";
import { useI18n } from "vue-i18n";
import { useOrderStore } from "@/stores/Order";
const { t } = useI18n();
const store = useOrderStore();
const { unreadCount } = storeToRefs(store);
onMounted(() => {
  store.getUnreadCount();
});
</script>

<template>
  <div>
    <div class="rounded-none w-full">
      <div
        class="flex flex-col lg:px-20 px-5 gap-10 lg:pt-10 w-full justify-start items-center"
      >
        <img class="w-[170px] h-[170px]" :src="Logo" alt="" />
        <div class="grid lg:grid-cols-4 gap-24 grid-cols-2">
          <router-link to="home/ordersRequests">
            <div class="relative flex flex-col justify-center items-center">
              <span
                v-if="unreadCount > 0"
                class="z-40 absolute w-[30px] flex justify-center items-center rounded-full top-8 right-10 text-white h-[30px] bg-red-500"
                >{{ unreadCount }}</span
              >
              <img class="w-[170px] h-[170px]" :src="OrdersRequests" alt="" />
              <p class="text-md lg:text-xl capitalize">
                {{ $t("profile.ordersRequests") }}
              </p>
            </div>
          </router-link>
          <router-link to="home/myOrders">
            <div class="flex flex-col justify-center items-center">
              <img class="w-[170px] h-[170px]" :src="MyOrders" alt="" />
              <p class="text-md lg:text-xl capitalize">{{ $t("profile.myOrders") }}</p>
            </div>
          </router-link>
          <router-link to="home/finance">
            <div class="flex flex-col justify-center items-center">
              <img class="w-[170px] h-[170px]" :src="Finance" alt="" />
              <p class="text-md lg:text-xl capitalize">{{ $t("profile.finance") }}</p>
            </div>
          </router-link>
          <router-link to="home/myCalendar">
            <div class="flex flex-col justify-center items-center">
              <img class="w-[170px] h-[170px]" :src="Mycalender" alt="" />
              <p class="text-md lg:text-xl capitalize">{{ $t("profile.calender") }}</p>
            </div>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>
