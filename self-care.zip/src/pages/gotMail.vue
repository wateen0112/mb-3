<script setup lang="ts">
import { VForm } from 'vuetify/components';
import { useAuthorization } from '@/stores/Auth';
import NavBarI18n from '@/layouts/components/NavBarI18n.vue';

const route = useRouter();
const store = useAuthorization();
const auth = computed(() => store.authDto);
const isLoading = ref(false);
const gotMail = ref<InstanceType<typeof VForm>>();

function onSubmit() {
  if (gotMail.value) {
    gotMail.value.validate().then(result => {
      if (result.valid) {
        isLoading.value = true;
        store
          .confirmMail({ email: auth.value.email, code: auth.value.code })
          .then(() => {
            isLoading.value = false;
            route.push('./resetPassword');
          })
          .catch(() => (isLoading.value = false));
      }
    });
  }
}
</script>

<template>
  <div class="relative">
    <img
      class="absolute top-0 -left-0 d-none d-lg-flex h-100"
      src="../assets/images/svg/mail.svg"
    >
    <div class="absolute top-5 right-0">
      <NavBarI18n class="mx-3" />
    </div>
    <VRow no-gutters class="auth-wrapper">
      <VCol cols="12" lg="12" class="d-flex align-center justify-center">
        <VCard flat :max-width="500" class="pa-4 lg:shadow-xl">
          <VCardText>
            <h5 class="text-h5 font-weight-semibold mb-1">
              {{ $t("mail.title") }}
            </h5>
            <p class="my-3">
              {{ $t("mail.description") }}
            </p>
          </VCardText>
          <VCardText>
            <VForm ref="gotMail">
              <VRow>
                <!-- code -->
                <VCol cols="12">
                  <p>{{ $t("mail.security") }}</p>
                  <div class="d-flex d-flex-row my-2 gap-x-2">
                    <VTextField v-model="auth.code" variant="outlined" type="number" />
                  </div>
                  <VBtn block :loading="isLoading" @click="onSubmit">
                    {{ $t("mail.check") }}
                  </VBtn>
                </VCol>
              </VRow>
            </VForm>
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </div>
</template>

<style lang="scss">
@use "@core/scss/template/pages/page-auth.scss";
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
