<script setup lang="ts">
import { useAuthorization } from "@/stores/Auth";
import Loading from "@/components/shared/Loading.vue";
onMounted(() => {
  useAuthorization().logout();
});
</script>
<template>
  <div>
    <Loading />
  </div>
</template>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: false
</route>
