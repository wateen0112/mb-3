<script setup lang="ts">
import { VForm } from 'vuetify/components';
import { useAuthorization } from '@/stores/Auth';
import NavBarI18n from '@/layouts/components/NavBarI18n.vue';
import { passwordValidator, confirmedValidator } from '@validators';

const route = useRouter();
const store = useAuthorization();
const auth = computed(() => store.authDto);
const isLoading = ref(false);
const resetPassword = ref<InstanceType<typeof VForm>>();
const confirm = ref('')
const isPasswordVisible = ref(false);
const isPasswordConfirmVisible = ref(false);

function onSubmit() {
  if (resetPassword.value) {
    resetPassword.value.validate().then(result => {
      if (result.valid) {
        isLoading.value = true;
        store
          .resetPassword({
            email: store.authDto.email,
            code: store.authDto.code,
            newPassword: store.authDto.newPassword,
          })
          .then(() => {
            isLoading.value = false;
            route.push('./');
          })
          .catch(() => (isLoading.value = false));
      }
    });
  }
}
</script>

<template>
  <div class="relative">
    <img
      class="absolute top-0 -left-0 d-none d-lg-flex h-100"
      src="../assets/images/svg/password-new.svg"
    >
    <div class="absolute top-5 right-0">
      <NavBarI18n class="mx-3" />
    </div>
    <VRow class="auth-wrapper" no-gutters>
      <VCol cols="12" lg="12" class="d-flex align-center justify-center">
        <VCard flat :max-width="500" class="mt-12 mt-sm-0 pa-4 lg:shadow-xl">
          <VCardText>
            <h5 class="text-h5 font-weight-semibold mb-1">
              {{ $t("resetPass.title") }}
            </h5>
            <p> {{ $t("resetPass.description") }}</p>
          </VCardText>

          <VCardText>
            <VForm ref="resetPassword">
              <VRow>
                <!-- email -->
                <VCol cols="12">
                  <VTextField
                    v-model="auth.newPassword"
                    :label="$t('resetPass.newPass')"
                    :type="isPasswordVisible ? 'text' : 'password'"
                    :append-inner-icon="
                      isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'
                    "
                    @click:append-inner="isPasswordVisible = !isPasswordVisible"                    :rules="[passwordValidator]"
                  />
                </VCol>
                <VCol cols="12">
                  <VTextField
                  v-model="confirm"
                    :label="$t('resetPass.confirmPass')"
                    :type="isPasswordConfirmVisible ? 'text' : 'password'"
                    :append-inner-icon="
                      isPasswordConfirmVisible ? 'tabler-eye-off' : 'tabler-eye'
                    "
                    @click:append-inner="isPasswordConfirmVisible = !isPasswordConfirmVisible"                    :rules="[passwordValidator, confirmedValidator(confirm, auth.newPassword)]"
                  />
                </VCol>

                <!-- Reset link -->
                <VCol cols="12" class="d-flex align-center justify-center">
                  <VBtn
                    color="primary"
                    class="tw-mt-5 text-white tw-px-10 tw-py-3 rounded-pill"
                    :loading="isLoading"
                    @click="onSubmit"
                  >
                    {{ $t("resetPass.rePass") }}
                  </VBtn>
                </VCol>

                <!-- back to login -->
                <VCol cols="12">
                  <RouterLink
                    class="d-flex align-center justify-center"
                    :to="{ name: 'login' }"
                  >
                    <VIcon icon="tabler-chevron-left" class="flip-in-rtl" />
                    <span>{{ $t("resetPass.back") }}</span>
                  </RouterLink>
                </VCol>
              </VRow>
            </VForm>
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </div>
</template>

<style lang="scss">
@use "@core/scss/template/pages/page-auth.scss";
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
