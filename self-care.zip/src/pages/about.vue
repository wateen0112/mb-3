abpt<script setup lang="ts">
import Outside from "@/components/Outside.vue";
import About from "@/components/About.vue";
</script>
<template>
  <Outside active="about">
    <template #body>
      <About />
    </template>
  </Outside>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
