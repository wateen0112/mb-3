<script setup lang="ts">
import Outside from "@/components/Outside.vue";
import Contact from "@/assets/images/svg/contact-us.svg";
import Web from "@/assets/images/svg/web.svg";
import Whatsapp from "@/assets/images/svg/whatsapp.svg";
import Gmail from "@/assets/images/svg/gmail.svg";
import ContactUs from "@/components/ContactUs.vue";
</script>
<template>
  <Outside active="contact">
    <template #body>
      <ContactUs />
    </template>
  </Outside>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
