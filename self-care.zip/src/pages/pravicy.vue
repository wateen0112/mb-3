<script setup lang="ts">
import Pravicy from "@/components/Pravicy.vue";
import Outside from "@/components/Outside.vue";
</script>
<template>
  <Outside active="pravicy">
    <template #body>
      <Pravicy />
    </template>
  </Outside>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
