<script setup lang="ts">
import Logo from "@/assets/images/svg/logo.svg";
import ksa from "@/assets/images/countries/ksa.png";
import { useI18n } from "vue-i18n";
import { useAuthorization } from "@/stores/Auth";
import PhoneInput from "@/components/shared/PhoneInput.vue";
import { useLayouts } from "@/@layouts/composable/useLayouts";
import { useAuth } from "@/composables";
import { emailValidator, requiredValidator, regexValidator } from "@validators";

const { locale, t } = useI18n();
const router = useRouter();
const authStore = useAuthorization();
const loginType = ref(1); //1=login by phone  2= login by email
const auth = useAuthorization();
const showPassword = ref(false);
const { phone } = storeToRefs(authStore);
const { isAppRtl } = useLayouts();
const { Login } = useAuth();

const emailForm = ref(null);
const test = (e: any) => {
  console.log("this is a test", e.raw);
};
const ksaRegex = /^((\+|00)966)?(5)([0-9]{8})$/;

const selectedCountry = ref({
  image: ksa,
  value: "+966",
});
const email = ref();
const password = ref();

//error validators  . .. .
const emailErrors = ref<Record<string, string | undefined>>({
  email: undefined,
  password: undefined,
});
const phoneIsValid = ref(false);
const countries = [
  {
    image: ksa,
    value: "+966",
  },
];
const login = () => {
  if (loginType.value === 1) {
    Login({ mobile: phone.value }).then(() => {
      // router.push('codeVertify')
    });
  } else {
    emailForm?.value.validate().then((valid: any) => {
      if (valid.valid) {
        Login(
          {
            email: email.value,
            password: password.value,
          },
          2
        );
      }
    });
  }
};
const toggleLang = (lang: string) => {
  localStorage.setItem("lang", lang);
  locale.value = lang;
  isAppRtl.value = lang === "ar";
 
};
onMounted(() => {
  localStorage.setItem("no-intro", "sdsd");
  if (!localStorage.getItem("no-intro")) {
    router.push("/intro");
  }
});
</script>
<template>
  <div class="capitalize">
    <nav class="w-full bg-primary lg:px-20 h-[50px] flex justify-end">
      <VBtn
        @click="toggleLang('ar')"
        variant="text"
        color="on-surface"
        v-if="locale == 'en'"
      >
        <VIcon class="ml-2" icon="tabler:language-katakana"></VIcon> العربية</VBtn
      >
      <VBtn variant="text" @click="toggleLang('en')" v-else color="on-surface">
        <VIcon icon="tabler:language-katakana" class="ml-2"></VIcon>Engilsh</VBtn
      >
    </nav>
    <div class="flex flex-col gap-y-0 justify-center items-center pt-20">
      <!--image container -->
      <div class="relative w-[180px] h-[180px]">
        <img class="absolute top-0 left-0 w-full h-full" :src="Logo" alt="" />
      </div>
      <!-- main form containers-->
      <div class="px-5 py-3 w-[400px]">
        <h2 class="text-primary capitalize">
          {{ $t("login.welcome") }}
        </h2>
        <div v-if="loginType === 1" class="mt-4">
          <VForm>
            <h3 class="text-primary font-normal text-xl">{{ $t("login.phone") }}</h3>

            <PhoneInput
              v-model:validation="phoneIsValid"
              :regex="ksaRegex"
              :countries="countries"
              v-model="phone"
            />
          </VForm>
        </div>
        <div v-else class="mt-4 flex flex-col gap-5">
          <VForm ref="emailForm">
            <div class="mt-4 w-full flex flex-col justify-center items-center gap-5">
              <VTextField
                class="w-full"
                :rules="[requiredValidator, emailValidator]"
                :error-messages="emailErrors.email"
                v-model="email"
                :label="t('login.email')"
                type="email"
              />
              <VTextField
                class="w-full"
                :rules="[requiredValidator]"
                :error-messages="emailErrors.password"
                v-model="password"
                :label="$t('login.password')"
                :type="showPassword ? 'text' : 'password'"
              />
              <VCheckbox
                class="w-full"
                v-model="showPassword"
                :label="$t('login.showPassword')"
              />
            </div>
          </VForm>
          <!--- here we have to addd a form-->
        </div>
        <div class="mt-4 flex flex-col justify-center items-center gap-5">
          <VBtn @click="login" class="capitalize w-full" height="46" color="primary">
            {{ $t("login.continue") }}
          </VBtn>
          <VBtn
            v-if="loginType == 2"
            class="w-full capitalize"
            @click="loginType = 1"
            height="46"
            variant="outlined"
            >{{ $t("login.phoneSignin") }}</VBtn
          >
          <VBtn
            v-else
            class="w-full capitalize"
            @click="loginType = 2"
            height="46"
            variant="outlined"
            >{{ $t("login.emailSignin") }}</VBtn
          >
        </div>
      </div>

      <p class="text-primary text-lg">
        {{ $t("login.agree") }} <br />
        <router-link to="terms" class="hover:underline"
          >{{ $t("login.terms") }} </router-link
        >&
        <router-link to="pravicy" class="hover:underline">{{
          $t("login.pravicy")
        }}</router-link>
      </p>
    </div>
  </div>
</template>

<style>
.international .v-select {
  border: none !important;
  border-right: none !important;
}
select {
  width: 100px;
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
