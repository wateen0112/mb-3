<script setup lang="ts">
import Screen1 from "@/components/signup/Screen1.vue";
import Screen2 from "@/components/signup/Screen2.vue";

const router = useRouter();

const curr = ref(0);
const carouselBtnClickEvent = () => {
  if (curr.value === 0) {
    curr.value = 1;
  } else if (curr.value === 1) {
    localStorage.setItem("no-intro", "s");
    router.push("/login");
  }
};
const skip = () => {
  localStorage.setItem("no-intro", "s");
};
</script>
<template>
  <div>
    <nav
      class="w-full h-[55px] bg-primary flex justify-between lg:pr-32 flex-row items-center"
      :class="{ 'justify-end': curr === 0 }"
    >
      <VBtn
        @click="curr = 0"
        v-if="curr === 1"
        variant="text"
        color="white"
        icon="mdi-chevron-left"
      ></VBtn>
      <RouterLink v-if="curr === 0" to="login"
        ><VBtn @click="skip" variant="text" class="capitalize" color="white"
          >Skip</VBtn
        ></RouterLink
      >
    </nav>

    <VCarousel
      v-model="curr"
      height="580"
      :continuous="false"
      :show-arrows="false"
      :hide-delimiters="true"
      class="intro-carousel relative"
      hide-delimiter-background
    >
      <VCarouselItem class="h-auto"><Screen1 /></VCarouselItem>
      <VCarouselItem><Screen2 /></VCarouselItem>
    </VCarousel>
    <div class="flex justify-center items-center gap-2 mb-5">
      <span
        @click="curr = 0"
        class="p-[6px] opacity-60 bg-primary rounded-full cursor-pointer"
        :class="{ 'px-5 py-[5px] opacity-100': curr === 0 }"
      ></span>
      <span
        @click="curr = 1"
        class="p-[7px] opacity-60 bg-primary rounded-full"
        :class="{ 'px-5 py-[5px] opacity-100': curr === 1 }"
      ></span>
    </div>
    <div class="flex justify-center items-center">
      <VBtn
        variant="flat"
        size="40"
        color="primary"
        class="carousel-btn relative"
        @click="carouselBtnClickEvent()"
        icon="mdi-chevron-right"
      >
      </VBtn>
    </div>
  </div>
</template>
<style scoped>
.intro-carousel .v-window__left {
  display: none;
}
.carousel-btn {
  box-shadow: 0px 0px 0px 8px rgba(255, 159, 67, 0.5);
  -webkit-box-shadow: 0px 0px 0px 8px rgba(255, 159, 67, 0.5);
  -moz-box-shadow: 0px 0px 0px 8px rgba(255, 159, 67, 0.5);
}
</style>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
