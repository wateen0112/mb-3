<script setup lang="ts">
import { useI18n } from "vue-i18n";
import { useProfileStore } from "@/stores/Profile";

import {
  emailValidator,
  confirmedValidator,
  requiredValidator,
  regexValidator,
} from "@validators";
const props = defineProps(["modelValue"]);
const emit = defineEmits(["update:modelValue"]);
const store = useProfileStore();
const { profileDto } = storeToRefs(store);
const re_password = ref("");
const { t, locale } = useI18n();
const errors = ref<Record<string, string | undefined>>({
  language: undefined,
  email: undefined,
  password: undefined,
  first_name: undefined,
  last_name: undefined,
  gender: undefined,
  image: undefined,
  c_password: undefined,
});
const myForm = ref(null);
defineExpose({
  myForm,
});
</script>
<template>
  <VForm ref="myForm" class="capitalize">
    <h2 class="pt-10 capitalize font-normal text-primary">{{ $t("signup.complete") }}</h2>

    <p class="text-on-surface">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque quibusdam in quaerat
      voluptatum, maxime dicta quos consequuntur modi expedita dignissimos dolores at
      assumenda officiis, iure velit unde magnam a dolorum repellat facilis commodi
      eveniet. Blanditiis magni doloremque expedita voluptas! Eligendi eaque ducimus
      molestias odio excepturi laboriosam dignissimos cupiditate laborum ipsam esse
      nostrum deserunt mollitia molestiae, in quia nam dolores ea voluptates dolor,
      adipisci quisquam omnis enim perspiciatis illum? Fuga cumque sapiente ex ipsam. Quae
      iste, itaque possimus sint officiis non, accusantium nemo amet molestiae, doloribus
      voluptas nobis praesentium aut porro.
    </p>
    <VTimeline
      class="lg:px-32 capitalize timeline1"
      color="primary"
      direction="horizontal"
    >
      <VTimelineItem content="" id="one" dot-color="grey-50">
        <template v-slot:opposite>
          <p class="text-xl">{{ $t("signup.step1") }}</p>
        </template></VTimelineItem
      >
      <VTimelineItem id="tow" dot-color="grey-300">
        <p class="text-xl">
          {{ $t("signup.step2") }}
        </p></VTimelineItem
      >
      <VTimelineItem id="three" dot-color="grey-300">
        <template v-slot:opposite>
          <p class="text-xl">{{ $t("signup.step3") }}</p>
        </template></VTimelineItem
      >
    </VTimeline>
    <div class="grid gap-20 grid-cols-1 lg:grid-cols-3 mt-16">
      <div class="flex flex-col justify-center gap-5">
        <VTextField
          :rules="[requiredValidator]"
          :error-messages="errors.first_name"
          v-model="profileDto.first_name"
          :label="$t('signup.fname')"
        />

        <VTextField
          :rules="[requiredValidator]"
          :error-messages="errors.email"
          v-model="profileDto.email"
          :label="$t('login.email')"
        />

        <VRadioGroup label="gander" v-model="profileDto.gender">
          <div class="flex justify-start gap-8 items-center flex-row">
            <VRadio value="male" label="male" />
            <VRadio value="fimale" label="fimale" />
          </div>
        </VRadioGroup>
      </div>

      <div class="flex flex-col justify-center gap-5">
        <VTextField
          :rules="[requiredValidator]"
          :error-messages="errors.last_name"
          v-model="profileDto.last_name"
          :label="$t('signup.lname')"
        />
        <VTextField
          :rules="[requiredValidator]"
          :error-messages="errors.password"
          v-model="profileDto.password"
          :label="$t('signup.password')"
        />
        <VTextField
          :error-messages="errors.c_password"
          :rules="[
            requiredValidator,
            confirmedValidator(re_password, profileDto.password),
          ]"
          v-model="re_password"
          :label="$t('signup.retypePassword')"
        />
        <VFileInput
          :rules="[requiredValidator]"
          :error-messages="errors.image"
          v-model="profileDto.image"
          class="fileUploaderCR"
          append-inner-icon="mdi-link"
          prepend-icon=""
          :label="t('signup.profileImage')"
        />
      </div>
      <div></div>
    </div>
  </VForm>
</template>
<style lang="scss" scoped>
//matching the desing  . . .
.timeline1 #one .v-timeline-divider__before,
.timeline1 #three .v-timeline-divider__after {
  display: none;
}
.timeline1 .v-timeline-divider__inner-dot {
  position: relative;
  transform: scale(1.8);
}
.timeline1 #one .v-timeline-divider__inner-dot {
  border: 1px solid #ff9f43;
}
.fileUploaderCR .v-field__append-inner {
  color: #ff9f43;
}
.timeline1 #one .v-timeline-divider__inner-dot::after {
  content: "1";
  position: absolute;
  color: #ff9f43;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}
.timeline1 #tow .v-timeline-divider__inner-dot::after {
  content: "2";
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}

.timeline1 #three .v-timeline-divider__inner-dot::after {
  content: "3";
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}
</style>
