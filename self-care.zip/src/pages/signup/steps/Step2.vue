<script setup lang="ts">
import { useStoresStore } from "@/stores/Store";
import { requiredValidator } from "@/@core/utils/validators";

import { useFile } from "@/composables";
import { useI18n } from "vue-i18n";
const store = useStoresStore();

const { getFileUrl } = useFile();
const { storeDto, categoriesList } = storeToRefs(store);
const checIfCatFound = (item: number) => {
  return (
    storeDto.value.categories_ids.filter((i: number) => {
      return i === item;
    }).length > 0
  );
};
const { t, locale } = useI18n();
const myForm = ref(null);
const errors = ref<Record<string, string | undefined>>({
  title_en: undefined,
  title_ar: undefined,
  commercial_registeration: undefined,
  prefered_payment_method: undefined,
  category_title: undefined,
  categories_ids: undefined,
  bank_name: undefined,
  iban: undefined,
  receiver_name: undefined,
  stc_phone_number: undefined,
  commercial_registeration_file: undefined,
  logo: undefined,
});

const router = useRouter();
const payType = ref(1); //temp just for testing design
defineExpose({
  myForm,
});
onMounted(() => {
  store.getCategoriesList();
});
</script>
<template>
  <VForm ref="myForm" class="mt-8 px-32">
    <VTimeline class="capitalize timeline2" color="primary" direction="horizontal">
      <VTimelineItem id="one" dot-color="primary">
        <template v-slot:opposite>
          <p class="text-xl text-primary">{{ $t("signup.step1") }}</p>
        </template></VTimelineItem
      >
      <VTimelineItem id="tow" dot-color="grey-50">
        <p class="text-xl">
          {{ $t("signup.step2") }}
        </p></VTimelineItem
      >
      <VTimelineItem id="three" dot-color="grey-300">
        <template v-slot:opposite>
          <p class="text-xl">{{ $t("signup.step3") }}</p>
        </template></VTimelineItem
      >
    </VTimeline>
    <div class="grid grid-cols-7">
      <div class="col-span-7 lg:col-span-5">
        <div class="my-3 grid lg:grid-cols-2 grid-cols-1 gap-20">
          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.title_en"
            v-model="storeDto.title_en"
            :label="$t('signup.storeInEnglish')"
          />
          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.title_ar"
            v-model="storeDto.title_ar"
            :label="$t('signup.storeInArabic')"
          />
        </div>
        <div class="mt-5 flex justify-start items-center gap-6">
          <!-- <Service
            @service-event="addItemToCatList(1)"
            :active-icon="SalonActive"
            :icon="Salon"
            :content="$t('signup.service.salon')"
          />
          <Service
            @service-event="addItemToCatList(2)"
            :active-icon="SpaActive"
            :icon="Spa"
            content="SPA"
          />
          <Service
            @service-event="addItemToCatList(3)"
            :active-icon="MassageActive"
            :icon="Massage"
            :content="$t('signup.service.massage')"
          />
          <Service
            @service-event="addItemToCatList(4)"
            :active-icon="BathActive"
            :icon="Bath"
            :content="$t('signup.service.bath')"
          /> -->

          <div v-for="category in categoriesList">
            <VBtn
              @click="store.addCategoryId(category.id)"
              class="h-[80px]"
              height="110px"
              width="110px"
              :variant="
                store.checkIfCategoryIdIsFound(category.id) ? 'tonal' : 'outlined'
              "
              :color="
                store.checkIfCategoryIdIsFound(category.id) ? 'primary' : 'gray-400'
              "
            >
              <div class="flex justify-center items-center flex-col">
                <img
                  class="w-[60px] h-[30px] object-cover mb-5"
                  :src="getFileUrl(category.icon_path ?? '')"
                  alt=""
                />
                <span class="text-wrap capitalize">
                  {{
                    locale === "en" ? category.title__ml.en : category.title__ml.ar
                  }}</span
                >
              </div>
            </VBtn>
          </div>
          <RouterLink to="home/myservices/new">
            <VBtn
              class="h-[80px] capitalize"
              height="110px"
              width="110px"
              variant="outlined"
            >
              <div class="flex justify-center items-center gap-3 flex-col">
                <span
                  class="bg-primary p-2 rounded-full flex justify-center items-center"
                >
                  <VIcon size="20">mdi-plus</VIcon>
                </span>
                <span>{{ $t("signup.service.addNew") }} </span>
              </div>
            </VBtn>
          </RouterLink>
        </div>
        <div class="mt-5 grid lg:grid-cols-2 grid-cols-1 gap-5">
          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.commercial_registeration"
            v-model="storeDto.commercial_registeration"
            :label="$t('signup.cr')"
          />
          <VFileInput
            :rules="[requiredValidator]"
            :error-messages="errors.commercial_registeration_file"
            v-model="storeDto.commercial_registeration_file"
            prepend-icon=""
            max-files="1"
            class="fileUploaderCR"
            append-inner-icon="mdi-document"
            :label="$t('signup.crDoc')"
          />
          <VFileInput
            single
            :rules="[requiredValidator]"
            :error-messages="errors.logo"
            v-model="storeDto.logoFile"
            prepend-icon=""
            class="fileUploaderCR"
            append-inner-icon="mdi-document"
            :label="$t('signup.logo')"
          />
        </div>
        <!-- payment methods-->
        <div class="mt-10">
          <p class="">{{ $t("signup.payType") }}</p>
          <VRadioGroup v-model="storeDto.prefered_payment_method">
            <div class="flex justify-start gap-10">
              <VRadio value="bank_account" :label="$t('signup.stc')" />
              <VRadio value="stc_pay" :label="$t('signup.bank')" />
            </div>
          </VRadioGroup>
        </div>
        <!--  stc  payment -->

        <div
          v-if="storeDto.prefered_payment_method === 'bank_account'"
          class="mt-4 grid grid-cols-1 lg:grid-cols-2 lg:gap-20"
        >
          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.stc_phone_number"
            v-model="storeDto.stc_phone_number"
            :label="$t('signup.stcNum')"
          />
        </div>
        <div class="mt-4 grid grid-cols-1 lg:grid-cols-2 lg:gap-x-20 gap-y-8" v-else>
          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.bank_name"
            v-model="storeDto.bank_name"
            :label="$t('signup.bankName')"
          />
          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.iban"
            v-model="storeDto.iban"
            :label="$t('signup.iban')"
          />

          <VTextField
            :rules="[requiredValidator]"
            :error-messages="errors.receiver_name"
            v-model="storeDto.receiver_name"
            :label="$t('signup.reciverName')"
          />
        </div>
      </div>
    </div>
  </VForm>
</template>
<style lang="scss" scoped>
//matching the desing  .
.timeline2 #one .v-timeline-divider__before,
.timeline2 #three .v-timeline-divider__after {
  display: none;
}
.timeline2 .v-timeline-divider__inner-dot {
  position: relative;
  transform: scale(1.8);
}
.timeline2 #tow .v-timeline-divider__inner-dot {
  border: 1px solid #ff9f43;
}
.timeline2 #one .v-timeline-divider__inner-dot::after {
  content: "1";
  position: absolute;

  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}

.timeline2 #one .v-timeline-divider__after,
.timeline2 #tow .v-timeline-divider__before {
  background-color: #ff9f43;
}
.timeline2 #tow .v-timeline-divider__inner-dot::after {
  content: "2";
  position: absolute;
  color: #ff9f43;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}

.timeline2 #three .v-timeline-divider__inner-dot::after {
  content: "3";
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}
.fileUploaderCR .v-field__append-inner {
  color: #ff9f43;
}
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
