<script setup lang="ts">
import { useI18n } from "vue-i18n";
import { useProfileStore } from "@/stores/Profile";
import LocationPicker from "@/components/shared/LocationPicker.vue";
const store = useProfileStore();
const { locationDto } = storeToRefs(store);

const router = useRouter();
const { t } = useI18n();
const onLocationSelected = (latlng: any) => {
  console.log(latlng);
  locationDto.value.latitude = latlng.lat;
  locationDto.value.longitude = latlng.lng;
};
</script>
<template>
  <div class="mt-8">
    <VTimeline
      class="lg:px-32 capitalize timeline3"
      color="primary"
      direction="horizontal"
    >
      <VTimelineItem id="one" dot-color="primary">
        <template v-slot:opposite>
          <p class="text-xl text-primary">{{ $t("signup.step1") }}</p>
        </template></VTimelineItem
      >
      <VTimelineItem id="tow" dot-color="primary">
        <p class="text-xl text-primary">
          {{ $t("signup.step2") }}
        </p></VTimelineItem
      >
      <VTimelineItem id="three" dot-color="grey-50">
        <template v-slot:opposite>
          <p class="text-xl text-primary">{{ $t("signup.step3") }}</p>
        </template></VTimelineItem
      >
    </VTimeline>
    <LocationPicker
      @location-selected="onLocationSelected"
      apiKey="AIzaSyBjhWSDGq5wahkoyCnMVNaln6mowhPZt-A"
    />

    <!-- next btn-->
  </div>
</template>
<style lang="scss" scoped>
//matching the desing  .
.timeline3 #one .v-timeline-divider__before,
.timeline3 #three .v-timeline-divider__after {
  display: none;
}
.timeline3 .v-timeline-divider__inner-dot {
  position: relative;
  transform: scale(1.8);
}
.timeline3 #three .v-timeline-divider__inner-dot {
  border: 1px solid #ff9f43;
}
.timeline3 #one .v-timeline-divider__inner-dot::after {
  content: "1";
  position: absolute;

  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}

.timeline3 .v-timeline-divider__after,
.timeline3 .v-timeline-divider__before {
  background-color: #ff9f43;
}
.timeline3 #tow .v-timeline-divider__inner-dot::after {
  content: "2";
  position: absolute;

  top: 50%;
  transform: translate(-50%, -50%);
  left: 50%;
}

.timeline3 #three .v-timeline-divider__inner-dot::after {
  content: "3";
  position: absolute;
  top: 50%;
  color: #ff9f43;
  transform: translate(-50%, -50%);
  left: 50%;
}
</style>
