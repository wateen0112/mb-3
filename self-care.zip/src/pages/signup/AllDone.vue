<script setup lang="ts">
import AllDone from "@/assets/images/svg/all-done.svg";
import { useAuthorization } from "@/stores/Auth";
</script>
<template>
  <div>
    <nav class="w-full bg-primary items-center h-[50px] lg:px-20 flex justify-end">
      <RouterLink to="/"
        ><VBtn class="capitalize" variant="text" color="white">Home</VBtn></RouterLink
      >
      <VBtn
        class="capitalize"
        color="white"
        variant="text"
        @click="useAuthorization().logout()"
        >log out</VBtn
      >
    </nav>
    <div class="flex flex-col justify-center items-center pt-8">
      <img class="h-[300px]" :src="AllDone" alt="" />
      <h2 class="font-normal text-primary capitalize">We recived your information</h2>
      <p class="text-lg text-center mt-3">
        We will contact you soon for <br />
        profile activation .
      </p>
    </div>
    <div class="mt-12 flex flex-col items-center justify-center gap-5">
      <RouterLink to="/about">
        <VBtn class="capitalize w-[400px]" height="50"> about Us</VBtn></RouterLink
      >
      <RouterLink to="/contactUs ">
        <VBtn variant="outlined" class="w-[400px] capitalize" height="50"
          >Contact Us</VBtn
        ></RouterLink
      >
    </div>
  </div>
</template>
<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
