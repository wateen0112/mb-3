<script setup lang="ts">
import { useI18n } from "vue-i18n";
import Step1 from "./steps/Step1.vue";
import Step2 from "./steps/Step2.vue";
import Step3 from "./steps/Step3.vue";
import { useProfileStore } from "@/stores/Profile";
import { useAuthorization } from "@/stores/Auth";
import { useStoresStore } from "@/stores/Store";
import { useAuth } from "@/composables";
import router from "@/router";
const route = useRouter();
const { t } = useI18n();
const curr = ref(0);
const loading = ref(false);
const form1 = ref(null);
const form2 = ref(null);
const authStore = useAuthorization();
const { userDto } = storeToRefs(authStore);
const { GetAccessToken } = useAuth();
const clckEvent = () => {
  switch (curr.value) {
    case 0:
      {
        form1.value.myForm.validate().then((v: any) => {
          if (v.valid) {
            loading.value = true;
            useProfileStore()
              .updateProfile()
              .then(() => {
                loading.value = false;
                curr.value = curr.value + 1;
              });
          }
        });
      }
      break;
    case 1:
      {
        form2.value.myForm.validate().then((v: any) => {
          if (v.valid) {
            loading.value = true;

            useStoresStore()
              .createStore()
              .then(() => {
                loading.value = false;
                curr.value = curr.value + 1;
              });
          }
        });
        // useStoresStore().damnFunciton();
      }
      break;
    case 2: {
      useProfileStore()
        .addLocation()
        .then(() => {
          useAuth().GetUserData();
          router.push("signup/alldone");
        });
    }
  }
  // if (curr.value < 2) {
  //   curr.value += 1;
  // }
};
onMounted(() => {
  authStore.getUserData();
  if (GetAccessToken()) {
  
    if (userDto.value.has_completed_profile && userDto.value.is_active) {
      router.push("/");
    } else if (!userDto.value.is_active && userDto.value.has_completed_profile) {
      router.push("signup/alldone");
    }
  }
});
</script>
<template>
  <div>
    <!-- navbar-->
    <nav class="w-full bg-primary h-[50px]">
      <VBtn
        v-if="curr > 0"
        variant="text"
        icon="mdi-chevron-left"
        @click="curr -= 1"
        color="white"
      />
    </nav>
    <div class="lg:px-20">
      <VCarousel
        v-model="curr"
        height="auto"
        :continuous="false"
        :show-arrows="false"
        :hide-delimiters="true"
        class="intro-carousel relative"
        :hide-delimiter="true"
      >
        <VCarouselItem><Step1 ref="form1" /></VCarouselItem>
        <VCarouselItem><Step2 ref="form2" /></VCarouselItem>
        <VCarouselItem><Step3 /></VCarouselItem>
      </VCarousel>
    </div>
    <!-- next btn-->
    <div class="flex p-5 justify-end w-full mt-10">
      <VBtn :loading="loading" @click="clckEvent" height="46" width="200">{{
        curr === 2 ? $t("signup.send") : $t("signup.next")
      }}</VBtn>
    </div>
  </div>
</template>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: false
</route>
